"""
Phase 2 — build-up sequences, outcome labels, player subsets, negative sampling
(tasks 2.1 .. 2.4).
"""

from __future__ import annotations

import pandas as pd

from tactical_ilp.config import (
    BUILD_UP_START_MAX_X,
    MAX_SEQUENCE_LENGTH,
    MIN_SEQUENCE_LENGTH,
    NEG_SAMPLES_PER_POSITIVE,
    MAX_GLOBAL_MATCH_SHARE,
)
from tactical_ilp.sequences.outcome_labeler import (
    _label_one,
    _opponent_control_evidence,
)


# --------------------------------------------------------------------------
# Task 2.1 — sequence segmentation
# --------------------------------------------------------------------------
def test_sequence_length_reasonable(sample_sequences):
    assert len(sample_sequences) > 0
    lengths = [len(seq) for seq in sample_sequences]
    assert all(MIN_SEQUENCE_LENGTH <= l <= MAX_SEQUENCE_LENGTH for l in lengths)


def test_sequences_found_in_every_match(sequences_df, barca_match_ids):
    assert sequences_df.match_id.nunique() == len(barca_match_ids)
    per_match = sequences_df.groupby("match_id").size()
    assert per_match.min() >= 5, "a match with almost no build-up is suspicious"


def test_sequences_start_in_own_half(sequences_df):
    assert (sequences_df.start_x <= BUILD_UP_START_MAX_X + 1e-6).all()


def test_sequence_membership_is_consistent(sequences_df, sequence_actions_df):
    counted = sequence_actions_df.groupby("sequence_id").size()
    declared = sequences_df.set_index("sequence_id")["n_actions"]
    joined = declared.to_frame("declared").join(counted.rename("counted"))
    assert joined["counted"].notna().all()
    assert (joined["declared"] == joined["counted"]).all()


def test_sequence_ids_are_unique(sequences_df):
    assert sequences_df.sequence_id.is_unique


# --------------------------------------------------------------------------
# Task 2.2 — negative outcome definition and labels
# --------------------------------------------------------------------------
def test_label_balance(labeled_sequences_df):
    trainable = labeled_sequences_df[
        labeled_sequences_df.label.isin(["negative", "non_negative"])
    ]
    ratio = trainable["label"].value_counts(normalize=True)
    assert ratio.min() >= 0.10, f"trainable-label balance too skewed: {ratio.to_dict()}"


def test_every_sequence_has_exactly_one_label(labeled_sequences_df, sequences_df):
    assert len(labeled_sequences_df) == len(sequences_df)
    assert labeled_sequences_df["label"].notna().all()
    assert set(labeled_sequences_df["label"]) <= {
        "negative", "non_negative", "inconclusive"
    }


def test_negative_outcome_definition_documented(outcome_definition_doc):
    assert outcome_definition_doc["exists"] is True
    assert outcome_definition_doc["has_explicit_criteria"] is True
    assert outcome_definition_doc["mismatches"] == []


def test_negative_labels_follow_one_of_the_three_documented_paths(labeled_sequences_df):
    """Every negative follows one of the active three-zone criteria."""
    neg = labeled_sequences_df[labeled_sequences_df.label == "negative"]
    defensive_third = neg[neg.turnover_zone == "defensive_third"]
    midfield = neg[neg.turnover_zone == "own_half_midfield"]
    advanced = neg[neg.turnover_zone == "advanced_opponent_middle"]
    assert defensive_third.lost_possession.all()
    assert defensive_third.turnover_x.le(35.0).all()
    own_goals = defensive_third.negative_reason == "defensive_third_own_goal"
    assert (
        own_goals
        | (
            defensive_third.final_action_failed
            & defensive_third.opponent_success_after
            & ~defensive_third.regained_within_5s
        )
    ).all()
    assert midfield.lost_possession.all()
    assert midfield.turnover_x.gt(35.0).all()
    assert midfield.turnover_x.le(52.5).all()
    assert (~midfield.regained_within_5s).all()
    assert midfield.two_consecutive_opponent_successes.all()
    assert advanced.lost_possession.all()
    assert advanced.turnover_x.gt(52.5).all()
    assert advanced.turnover_x.lt(70.0).all()
    assert advanced.opponent_direct_transition.all()
    assert (~advanced.regained_within_5s).all()


def test_advanced_transition_ignores_small_progress_and_accepts_five_metres():
    def transition(start_x, end_x):
        after = pd.DataFrame(
            [{
                "row": 10,
                "time_seconds": 11.0,
                "is_barca": False,
                "result_name": "success",
                "type_name": "pass",
                "start_x": start_x,
                "end_x": end_x,
            }]
        )
        return _opponent_control_evidence(after, turnover_row=10, turnover_time=10.0)[4]

    assert not transition(60.0, 55.1)
    assert transition(60.0, 55.0)
    # Crossing the defensive-third line is meaningful even when that final
    # action itself travels fewer than five metres.
    assert transition(36.0, 34.5)


def test_half_space_entry_names_follow_y_zero_right_convention():
    from tactical_ilp.sequences.sequence_builder import _entry_regions

    right = _entry_regions(75.0, 20.0)
    left = _entry_regions(75.0, 48.0)
    assert "right_deep_half_space" in right
    assert "left_deep_half_space" not in right
    assert "left_deep_half_space" in left
    assert "right_deep_half_space" not in left


def test_completed_build_up_endings_cannot_be_negative():
    for end_reason in ("shot", "attacking_zone_entry"):
        terminal_type = "shot" if end_reason == "shot" else "dribble"
        seq = pd.Series(
            {"sequence_id": "s_completed", "period_id": 1,
             "last_action_row": 1, "end_reason": end_reason}
        )
        actions = pd.DataFrame(
            [
                {"row": 1, "period_id": 1, "is_barca": True,
                 "result_name": "success", "type_name": terminal_type,
                 "start_x": 80.0, "end_x": 90.0, "time_seconds": 1.0},
                {"row": 2, "period_id": 1, "is_barca": False,
                 "result_name": "success", "type_name": "pass",
                 "start_x": 50.0, "end_x": 49.0, "time_seconds": 2.0},
                {"row": 3, "period_id": 1, "is_barca": False,
                 "result_name": "success", "type_name": "pass",
                 "start_x": 49.0, "end_x": 48.0, "time_seconds": 3.0},
            ]
        )
        label = _label_one(seq, actions)
        assert label["build_up_completed"] is True
        assert label["label"] == "non_negative"

    # Completion takes precedence over an otherwise inconclusive foul boundary.
    seq = pd.Series(
        {"sequence_id": "s_shot_foul", "period_id": 1,
         "last_action_row": 1, "end_reason": "shot"}
    )
    actions = pd.DataFrame(
        [
            {"row": 1, "period_id": 1, "is_barca": True,
             "result_name": "success", "type_name": "shot",
             "start_x": 80.0, "end_x": 90.0, "time_seconds": 1.0},
            {"row": 2, "period_id": 1, "is_barca": False,
             "result_name": "success", "type_name": "foul",
             "start_x": 50.0, "end_x": 50.0, "time_seconds": 2.0},
        ]
    )
    assert _label_one(seq, actions)["label"] == "non_negative"


def test_only_controlled_barcelona_action_counts_as_regain():
    after = pd.DataFrame(
        [
            {"row": 10, "time_seconds": 10.0, "is_barca": False,
             "result_name": "fail", "type_name": "pass", "start_x": 45.0, "end_x": 44.0},
            {"row": 11, "time_seconds": 11.0, "is_barca": True,
             "result_name": "success", "type_name": "tackle", "start_x": 44.0, "end_x": 44.0},
            {"row": 12, "time_seconds": 12.0, "is_barca": False,
             "result_name": "success", "type_name": "pass", "start_x": 44.0, "end_x": 43.0},
        ]
    )
    evidence = _opponent_control_evidence(after, turnover_row=10, turnover_time=10.0)
    assert evidence[0] is False

    after.loc[1, "type_name"] = "pass"
    evidence = _opponent_control_evidence(after, turnover_row=10, turnover_time=10.0)
    assert evidence[0] is True


def test_single_midfield_penetration_or_shot_is_immediate_negative():
    for opponent_action in (
        {"type_name": "pass", "result_name": "success", "start_x": 50.0, "end_x": 34.0},
        {"type_name": "shot", "result_name": "fail", "start_x": 50.0, "end_x": 50.0},
    ):
        seq = pd.Series(
            {"sequence_id": "s_midfield", "period_id": 1,
             "last_action_row": 1, "end_reason": "failed_action"}
        )
        actions = pd.DataFrame(
            [
                {"row": 1, "period_id": 1, "is_barca": True,
                 "result_name": "fail", "type_name": "pass",
                 "start_x": 50.0, "end_x": 50.0, "time_seconds": 1.0},
                {"row": 2, "period_id": 1, "is_barca": False,
                 **opponent_action, "time_seconds": 2.0},
            ]
        )
        label = _label_one(seq, actions)
        assert label["label"] == "negative"
        assert label["opponent_immediate_threat"] is True
        assert label["negative_reason"] == "own_half_midfield_immediate_threat"


def test_global_fallback_is_limited_to_five_percent_of_final_negatives():
    from tactical_ilp.sequences.negative_sampling import _global_fallback_budget

    assert _global_fallback_budget(18) == 0
    assert _global_fallback_budget(19) == 1
    assert _global_fallback_budget(95) == 5
    assert MAX_GLOBAL_MATCH_SHARE == 0.05


def test_first_opponent_foul_is_inconclusive_not_a_turnover():
    seq = pd.Series({"sequence_id": "s1", "period_id": 1, "last_action_row": 1})
    actions = pd.DataFrame(
        [
            {"row": 1, "period_id": 1, "is_barca": True, "result_name": "success", "type_name": "pass", "start_x": 20.0, "end_x": 25.0, "time_seconds": 1.0},
            {"row": 2, "period_id": 1, "is_barca": False, "result_name": "success", "type_name": "foul", "start_x": 25.0, "end_x": 25.0, "time_seconds": 2.0},
        ]
    )
    label = _label_one(seq, actions)
    assert label["lost_possession"] is False
    assert label["label"] == "inconclusive"
    assert label["turnover_zone"] == "none"


def test_advanced_failed_pass_is_inconclusive():
    seq = pd.Series({"sequence_id": "s2", "period_id": 1, "last_action_row": 1})
    actions = pd.DataFrame(
        [
            {"row": 1, "period_id": 1, "is_barca": True, "result_name": "fail", "type_name": "pass", "start_x": 65.0, "end_x": 72.0, "time_seconds": 1.0},
        ]
    )
    label = _label_one(seq, actions)
    assert label["lost_possession"] is True
    assert label["label"] == "inconclusive"
    assert label["negative_reason"] == "advanced_failed_pass_endpoint_uncertain"


# --------------------------------------------------------------------------
# Task 2.3 — multi-player subsets
# --------------------------------------------------------------------------
def test_multi_player_subsets_extracted(sequences_with_subsets):
    has_subset = sequences_with_subsets["player_pairs"].apply(lambda x: len(x) > 0)
    assert has_subset.mean() >= 0.50


def test_pairs_reference_two_distinct_players(sequences_with_subsets):
    for pairs in sequences_with_subsets["player_pairs"]:
        for pair in pairs:
            a, b = pair.split(">")
            assert a != b


def test_triples_have_three_distinct_players():
    from tactical_ilp.sequences.player_subsets import TRIPLES_PATH

    triples = pd.read_parquet(TRIPLES_PATH)
    if len(triples) == 0:
        return
    assert (triples.p1 != triples.p2).all()
    assert (triples.p2 != triples.p3).all()
    assert (triples.p1 != triples.p3).all()


# --------------------------------------------------------------------------
# Task 2.4 — negative sampling
# --------------------------------------------------------------------------
def test_negative_samples_context_comparable(pos_examples_df, neg_examples_df):
    pos_zone_dist = pos_examples_df["zone"].value_counts(normalize=True)
    neg_zone_dist = neg_examples_df["zone"].value_counts(normalize=True)
    total_overlap = sum(
        min(pos_zone_dist.get(z, 0), neg_zone_dist.get(z, 0))
        for z in set(pos_zone_dist.index) | set(neg_zone_dist.index)
    )
    assert total_overlap >= 0.4


def test_negative_sampling_ratio_respected(pos_examples_df, neg_examples_df):
    expected = len(pos_examples_df) * NEG_SAMPLES_PER_POSITIVE
    # The target is 2:1, but the context-preservation cap can lower the ratio.
    assert len(neg_examples_df) <= expected


def test_no_sequence_is_both_positive_and_negative(ilp_examples_df):
    assert ilp_examples_df.sequence_id.is_unique


def test_examples_classes_match_labels(ilp_examples_df):
    pos = ilp_examples_df[ilp_examples_df.example_class == "pos"]
    neg = ilp_examples_df[ilp_examples_df.example_class == "neg"]
    assert (pos.label == "negative").all()
    assert (neg.label == "non_negative").all()


def test_most_negatives_come_from_the_exact_stratum(neg_examples_df):
    exact = (neg_examples_df.match_level == 3).mean()
    assert exact >= 0.80, f"only {exact:.1%} of negatives matched the exact stratum"


def test_global_fallback_share_never_exceeds_five_percent(neg_examples_df):
    if len(neg_examples_df):
        assert (neg_examples_df.match_level == 0).mean() <= MAX_GLOBAL_MATCH_SHARE


def test_sampling_strategy_documented(sampling_strategy_doc):
    assert sampling_strategy_doc["exists"] is True
    assert sampling_strategy_doc["has_explicit_criteria"] is True
    assert sampling_strategy_doc["mismatches"] == []


def test_negative_sampling_is_deterministic():
    """Same seed -> same example set (needed for reproducible phase 5 runs)."""
    from tactical_ilp.sequences.negative_sampling import sample_examples

    a = sample_examples()
    b = sample_examples(force=True)
    assert set(a.sequence_id) == set(b.sequence_id)
