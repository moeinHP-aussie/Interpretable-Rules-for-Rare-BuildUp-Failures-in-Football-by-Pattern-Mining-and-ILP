# فاز ۵ — یادگیری قواعد تاکتیکی با Popper و الگوهای ترتیبی

## هدف و جایگاه در خط لوله

فاز ۵ از توالی‌ها و برچسب‌های فاز ۲، فکت‌های پایه‌ی فاز ۳ و فکت‌ها/قواعد تاکتیکی فاز ۴ استفاده می‌کند تا فرضیه‌های منطقی قابل‌خواندن بسازد. هدف head در هر دو بازوی فعال چنین است:

```prolog
negative_outcome(Sequence)
```

مثبت برای Popper یعنی sequence با label برابر `negative`؛ منفی یعنی `non_negative`. پس «مثبت» در فایل `exs.pl` معادل outcome نامطلوب build-up است. این فاز تعریف label را تغییر نمی‌دهد و قواعد آموخته‌شده را علت‌ومعلول اثبات‌شده نمی‌داند؛ خروجی، فرضیه‌ی اکتشافی برای ارزیابی روی matchهای جدا و بازبینی تاکتیکی است.

```text
Phase 1: SPADL + 360 + timing
 → Phase 2: sequences + outcomes + context-matched examples
 → Phase 3: ground facts + Phase 4: tactical facts/BK
 → Phase 5: ILP inputs → Popper search → match-held-out evaluation
```

## دو بازوی فعال

`compare_phase5_methods.py` دو گزارش مستقل را با کلیدهای `full_tactical` و `hybrid_sequential` مقایسه می‌کند. بازوی اول همان baseline با نام فایل تاریخی `legacy_43` است؛ شناسهٔ مقایسه‌ای آن `full_tactical` شده تا دامنهٔ کامل vocabulary را نشان دهد. بازوی دوم mining ترتیبی را با ویژگی‌های تاکتیکی ساختاری ترکیب می‌کند.

| نام مقایسه | ماهیت | ورودی Popper |
|---|---|---|
| `full_tactical` (`legacy_43` در نام فایل‌ها) | واژگان تاکتیکی کاملِ بازبینی‌شده، بدون pattern mining | wrapperهای action-level، predicateهای sequence-level و wrapperهای player-sequence |
| `hybrid_sequential` (`sequential` در نام runner) | patternهای ترتیبی به‌اضافهٔ واژگان کامل تاکتیکی | patternهای منتخب به‌صورت اتمی و تمام predicateهای full-tactical |

پسوند `_43` در نام ماژول baseline تاریخی است و تعداد فعال را بیان نمی‌کند. `fast_sequence` در واژگان فعال است و نرخ اکشن‌های صدک ۹۰ به بالا را نشان می‌دهد. بازسازی Phase 4 آستانهٔ عددی محاسبه‌شده را در manifest ثبت می‌کند.

## قرارداد ورودی مشترک

- `labeled_sequences.parquet` مرجع label و match هر sequence است.
- `ilp_examples.parquet` نمونه‌های انتخاب‌شده‌ی فاز ۲ را تعیین می‌کند؛ negative controls از کل label table بدون قید انتخاب نمی‌شوند.
- sequenceهای انتخاب‌شده به `pos(negative_outcome(S)).` یا `neg(negative_outcome(S)).` تبدیل می‌شوند. `pos/1`, `neg/1` syntax مثال Popper است.
- sampling فاز ۲ حداکثر نسبت هدف ۲ کنترل به ۱ positive دارد و ابتدا contextهای همسان سطح ۳→۱ را مصرف می‌کند. fallback سراسری level 0 با `MAX_GLOBAL_MATCH_SHARE=0.05` سقف می‌خورد؛ کمبود کنترل مناسب باعث نسبت کمتر می‌شود، نه تزریق بی‌قید نمونه‌ی جهانی.
- مفهوم‌های action-level با wrapper existential به sequence-level تبدیل می‌شوند، مانند:

```prolog
seq_triangulation_opponent_trapped(S) :- in_sequence(A,S), triangulation_opponent_trapped(A).
```

معنا «وجود دست‌کم یک اکشن واجدشرط» است، نه تعداد وقوع‌ها یا ترتیب رخدادها. این wrapperها متغیرهای Action و Player را از بدنه‌ی قاعده دور نگه می‌دارند و فضای جست‌وجو را کوچک‌تر می‌کنند.

## روش اول: baseline `legacy_43`

### تولید فایل‌های Popper

`legacy_43_inputs.py` فایل‌های `exs.pl`, `bias.pl`, `bk.pl` را می‌سازد. BK تولیدی به‌جای کپی‌کردن فایل بزرگ، با مسیر نسبی `facts_all.pl`, `facts_tactical.pl`, `bk.pl` دستی را consult می‌کند و wrapperهای لازم را تعریف می‌کند. مسیرهای نسبی امکان جابه‌جایی پروژه را حفظ می‌کنند.

Vocabulary فعال در `phase5_vocabulary.py` نگه‌داری می‌شود:

- **۳۱ action-level برای استخراج فکت و ماینر ترتیبی:** `line_breaking_pass`, `diagonal_pass`, `switch_to_right`, `switch_to_left`, `aerial_pass`, `long_pass`, `pass_in_behind`, `line_pass`, `connecting_pass`, `dropped_between_lines`, `first_time_play`, `dwelt_long`, `supported_action`, `dead_end_support`, `triangulation_opponent_trapped`, `rondo_cage`, `press_resistance`, `counter_pressed`, `rest_defence_exposed`, `under_pressure`, `flank_line_carry`, `flank_cut_inside`, `flank_dribble`, `central_long_carry`, `central_take_on`, `central_backward_pass`, `flank_backward_carry`, `flank_to_center_progression`, `central_switch`, `recycle_to_same_flank`, `center_cycling`؛ `pressured_cage` حذف شده است؛
- **۶ ویژگی sequence-level در Popper:** `opponent_visible_majority`, `slow_sequence`, `fast_sequence`, `keeper_played_open_play`, `seq_pass_exchange` و `seq_flank_to_center`. Aliasهای `seq_open_support` / `seq_no_open_support` در BK تولید می‌شوند، اما در bias فعال این تنظیم نیستند.
- **۱ player-sequence:** `persistent_half_space_occupier`. Wrapper می‌پرسد آیا دست‌کم یک بازیکن در همان توالی predicate را ارضا می‌کند.

`hesitated`, `give_and_continue` و `no_successful_forward_pass_10m` در کد BK/فکت‌ساز باقی می‌مانند، اما در bias فعال ارائه نمی‌شوند. مکث فشارمحور به‌علت آستانه‌های وابسته به فشار و حساسیت زمانی کنار گذاشته شده و `dwelt_long` با مرز ثابت ۲٫۵ ثانیه حفظ شده است؛ `under_pressure` ویژگی مستقلی است تا Popper بتواند آن را با مکث طولانی ترکیب کند. `give_and_continue` به حداقل سه لمس وابسته است و ممکن است به طول/میزان مشارکت سکانس حساس باشد. `no_successful_forward_pass_10m` قاعده‌ی نفی وجودی و outcome-proximal است؛ ادعای اینکه دقیقاً همان برچسب را تعریف می‌کند بیش از حد قوی است، اما حذفش از واژگان از shortcut مبتنی بر فقدان فرصت پیشروی جلوگیری می‌کند.

سه ویژگی flank از اکشن‌های SPADL نوع `dribble` و مختصات شروع/پایان ساخته می‌شوند: `flank_dribble` با شروع از `left_wing` یا `right_wing`؛ `flank_line_carry` با شروع و پایان در همان wing و پیشروی طولی حداقل ۵ متر؛ و `flank_cut_inside` با پایان در هر نیم‌فضا یا `central_channel`. این‌ها فکت ground هستند و به وجود فریم ۳۶۰ نیاز ندارند.

برای جلوگیری از ترکیب افزونه در یک بند Popper، Bias ترکیب `seq_rondo_cage` با `seq_triangulation_opponent_trapped` و ترکیب `seq_flank_dribble` با هر یک از `seq_flank_line_carry` و `seq_flank_cut_inside` را منع می‌کند. این قیود در سطح بند هستند؛ استفاده از این مفاهیم در بندهای جداگانه مجاز است.

`pass_in_behind` علاوه بر پایان پشت خط دفاعی تخمینی، باید در یک‌سوم هجومی (x>70m) یا محوطهٔ جریمهٔ حریف پایان یابد. مختصات محوطه از ابعاد استاندارد زمین SPADL (عمق ۱۶٫۵m و عرض ۴۰٫۳۲m) گرفته می‌شود. چون محوطه در یک‌سوم هجومی قرار دارد، شرط محوطه صریح و مستند است اما از نظر مجموعهٔ نقاط زیرمجموعهٔ شرط یک‌سوم هجومی است. این مرز انتهایی `pass_in_behind` را از `line_breaking_pass` متمایز می‌کند؛ پاس خط‌شکن می‌تواند پیش از رسیدن به یک‌سوم هجومی هم رخ دهد.

`central_switch`, `recycle_to_same_flank`, و `center_cycling` قواعد Prolog روی دو پاس موفقِ پیاپی در ترتیب اکشن‌های پاس هستند؛ اکشن‌های غیرپاس میان آن دو مجازند، اما پاس دیگری نباید میانجی شود. مرکز همان `central_channel` در قرارداد پنج lane پروژه است. این‌ها پروکسی فضایی‌اند: ورودی جاری شناسه‌ی عمومی گیرنده‌ی پاس ندارد، بنابراین نمی‌توان اثبات کرد که همان هافبک پاس اول را دریافت و پاس دوم را ارسال کرده است. تعویض جناح جهت‌دار دو مفهوم مستقل `switch_to_right` و `switch_to_left` دارد: هر دو به موفقیت، تغییر lane و جابه‌جایی عرضی حداقل ۲۵ متر نیاز دارند؛ مقصد اولی باید در `right_half_space` یا `right_wing` و دومی در `left_half_space` یا `left_wing` باشد. هر دو با `central_switch` متفاوت‌اند: آن مفهوم مسیر دوپاسه از مرکز را می‌سنجد.

`aerial_pass` از برچسب صریح StatsBomb به‌صورت `High Pass` در رویداد اصلی ساخته می‌شود. چون جدول استاندارد SPADL این برچسب را حفظ نمی‌کند، فاز ۱ اکنون `pass_height_name` را از metadata رویداد نگه می‌دارد؛ برای اکشن مصنوعیِ بدون `original_event_id` ارتفاع ناشناخته می‌ماند. `long_pass` مستقل از ارتفاع است و طول اقلیدسی ابتدا تا انتهای پاس را می‌سنجد؛ آستانه `>=30m` است.

`costly_hesitation/1` در BK برای تحلیل تشخیصی حفظ شده، اما outcome-proximal است: مکث را به شکست اکشن بعدی (`failed(B)`) متصل می‌کند. در `OUTCOME_PROXIMAL_ACTION_PREDS` علامت خورده و عمداً به واژگان Popper وارد نمی‌شود. Predicateهای وابسته به `sequence_label/2` نیز با guard نشت اطلاعات رد می‌شوند. `action_result/2` و aliasهای `successful/1`, `failed/1` برای تعریف مفاهیم تاکتیکی در BK به کار می‌روند، اما result predicate خام در bias عرضه نمی‌شود.

Wrapperهای action-level و player-sequence به مفهوم sequence-level تبدیل می‌شوند؛ predicateهای sequence-level مستقیم عرضه می‌شوند. `seq_open_support/1` و `seq_no_open_support/1` ممکن است در BK wrapper تعریف شوند، اما اگر در فهرست body نباشند Popper آن‌ها را جست‌وجو نمی‌کند.

### Bias و محدودیت جست‌وجو

Bias با `head_pred`, `body_pred`, `type`, `direction` نوع و جایگاه آرگومان‌ها را مشخص می‌کند. پیش‌فرض‌های واژگان مشترک:

- `max_vars(2)`؛
- `max_body(3)`؛
- `max_clauses(4)`.

قیدهای same-clause mutual exclusion از فهرست مرکزی تولید می‌شوند (در نسخه‌ی جاری این فهرست خالی است). کوچک نگه‌داشتن فضای فرضیه برای کنترل ترکیب‌های منطقی و grounding است؛ به Popper مختصات خام نمی‌دهیم، بلکه مفاهیم Boolean یا کوچک‌دامنه عرضه می‌کنیم.

### اجرای Popper

`scripts/run_phase5.py` ابتدا وجود facts و manifest جاری فاز ۴ را بررسی می‌کند، ورودی‌ها را می‌سازد و با SWI-Prolog بارگذاری/پاسخ‌گویی پایه را اعتبارسنجی می‌کند. اجرای Popper از محیط `uv` جداگانه و Python حداقل 3.14 با `janus_swi` انجام می‌شود؛ `POPPER_DIR` لازم است و SWI-Prolog باید حداقل 9.1.12 باشد.

Popper در حالت noisy اجرا می‌شود و می‌تواند خطای طبقه‌بندی را تحمل کند. worker پروژه `max_clauses` را از bias می‌خواند و سقف را به noisy combiner و greedy upper-bound نیز اعمال می‌کند. جست‌وجوی اصلی ۹۰۰ ثانیه و hard stop بیرونی ۹۶۰ ثانیه است. MDL در noisy setting هزینه‌ی اندازه‌ی برنامه و خطاهای مثبت/منفی را موازنه می‌کند؛ به‌طور شهودی، قاعده‌ی کوتاه با خطای کمتر ترجیح دارد. این بهینه‌سازی تضمین نمی‌کند که قاعده از نظر تاکتیکی علّی باشد.

خروجی در `data/prolog/popper/` و log در `data/reports/phase5_popper_output.txt` نوشته می‌شود. incumbent چاپ‌شده پیش از خاتمه provisional است؛ timeout، `NO SOLUTION` یا خطای اجرا نتیجه‌ی یادگیری موفق محسوب نمی‌شود. فرمان امتیازدهی روی holdout پس از run نمایش داده می‌شود.

## بازوی دوم: `hybrid_sequential`، patternهای ترتیبی در bias ترکیبی

### ساخت itemsetها

`sequential_patterns.py` برای هر sequence فهرستی مرتب از eventها می‌سازد. Runner آموزشی/CV از `vocabulary="tactical"` استفاده می‌کند: مفاهیم action-level مجاز را با اجرای SWI-Prolog روی همان facts و BK استخراج می‌کند تا تعریف تاکتیکی جداگانه‌ای در Python کپی نشود. هر رویداد تاکتیکی با نوع SPADL و محل شروع (lane و یک‌سوم طولی) به یک اتم تبدیل می‌شود؛ برای نمونه `tactical:line_pass@pass@left_wing@middle_third`. ساخت اتم مرکب، همراهی مفهوم/مکان/نوع را حتی با سقف `max_items_per_event=1` حفظ می‌کند. مختصات مفقود به مقدار `unknown` تبدیل می‌شوند.

مفاهیم هندسی جدید نیز از مختصات SPADL ساخته می‌شوند: `central_long_carry` (طول مسیر ≥۳٫۵ متر در هر یک از سه lane غیرکناری)، `central_take_on` (اکشن take-on در همین laneها)، `central_backward_pass` (طول ≥۷ و Δx≤−۵ متر)، `flank_backward_carry` (همان بال و Δx≤−۴ متر)، و `flank_to_center_progression` (پاس از wing به half-space/مرکز، طول ≥۱۰ و Δx≥۵ متر). ماینر سمت را از lane مبدأ حفظ می‌کند؛ Popper فقط alias متقارن `seq_flank_to_center` را می‌بیند تا دو نام هم‌معنا وارد فضای جست‌وجو نشوند. گزارهٔ `seq_pass_exchange` فقط وجود تبادل موفقِ دوطرفه میان دو بازیکن متفاوت را ثبت می‌کند؛ شناسهٔ گیرنده فقط در محاسبهٔ گذرای فکت به کار می‌رود و در فایل Prolog ذخیره نمی‌شود.

سازنده علاوه بر آن modeهای `core` و `combined` دارد. core vocabulary شامل ۲۰ نماد بولی است: هفت action family (pass/cross/carry/defensive/shot/restart/other)، دو result، سه pressure bucket، سه جهت، progressive، diagonal، switch و timingهای hesitation/one-touch. این دو mode برای تحلیل/ابزارهای تشخیصی‌اند؛ arm تولیدی از tactical mode استفاده می‌کند.

### مرز زمانی و نشت

پیش‌فرض `excluded_suffix_actions=1` اکشن پایانی را پیش از ساخت pattern sequence حذف می‌کند. predicateهایی که به اکشن بعدی یا dwell وابسته‌اند روی آخرین action نگه‌داشته‌شده نیز suppression می‌شوند؛ فهرست شامل `line_pass`, `hesitated`, `first_time_play`, `dwelt_long`, `quick_line_break` است. `layoff` بازنشسته شده است، چون دادهٔ فریزفریم دوبعدی جهت بدن و قصد پاس را نشان نمی‌دهد. برچسب outcome به نماد تبدیل نمی‌شود و mining به اکشن‌های حریف پس از مرز دسترسی نمی‌گیرد.

### الگوریتم mining و رتبه‌بندی

`GapConstrainedClosedMiner` یک prefix-projection محلی و bounded است؛ گزارش‌ها آن را canonical Gap-BIDE معرفی نمی‌کنند. دو بسط دارد: I-extension برای افزودن item به همان event و S-extension برای event بعدی با gap محدود. Closure با برابری دقیق مجموعه‌ی sequenceهای پشتیبان بررسی می‌شود و patternهای زیرساختار از pattern بزرگ‌تر با همان support حذف می‌شوند.

Mining فقط روی target/negative sequences از matchهای train انجام می‌شود تا جست‌وجو روی control-only motifها هدر نرود؛ سپس هر pattern روی کنترل‌ها نیز match و نرخ‌ها مقایسه می‌شوند. strata زمینه از `start_zone`, `pressure_bucket`, `length_bucket` است. growth به‌صورت نرخ target تقسیم بر نرخ control محاسبه می‌شود و هموارسازی `0.5` مانع نرخ صفر می‌شود. فقط patternهایی با target support و growth حداقل تعیین‌شده باقی می‌مانند.

| تنظیم پیش‌فرض | مقدار | نقش |
|---|---:|---|
| `max_gap` | 2 | حداکثر دو event میانی؛ فاصله‌ی index حداکثر 3 |
| `min_support` | 5 | حداقل حمایت برای رشد pattern |
| `min_target_support` | 5 | کف حمایت target برای پذیرش |
| `min_growth_rate` | 1.5 | کف نرخ target/control |
| `smoothing` | 0.5 | هموارسازی نرخ‌ها |
| `min_pattern_events` / `max_pattern_events` | 2 / 3 | طول pattern بر حسب event |
| `max_items_per_event` | 1 | سقف item در هر event |
| `max_selected_patterns` | 8 | سقف patternهای نهایی |
| `excluded_suffix_actions` | 1 | action انتهایی حذف‌شده |
| `max_candidates` | 50,000 | توقف سخت برای کنترل رشد جست‌وجو |

Patternها با growth، حمایت و ترتیب قطعی مرتب می‌شوند. پیش‌فرض سقف انتخاب ۸ است؛ بنابراین حداکثر هشت candidate برتر وارد گزینش/فشرده‌سازی و فایل facts می‌شوند. ارزیابی زمینه‌ای روی strata مشترک انجام می‌شود و نرخ‌ها بر اساس توزیع target وزن می‌گیرند.

### Bias ترکیبی و محدودیت مهم نام‌گذاری

`select_compressing_patterns()` بخش predicate را از اتم مکانی مرکب جدا می‌کند و فقط candidateی را می‌پذیرد که دست‌کم یک action predicate تاکتیکیِ هنوز موجود را مصرف کند. هر predicate پایه‌ای که در pattern انتخاب‌شده ظاهر شده از واژگان مستقل حذف می‌شود؛ sequence/player summary و base predicateهای مصرف‌نشده باقی می‌مانند. `write_pattern_facts()` patternها را به `seq_pattern_01(S)` و مانند آن به شکل ground fact projection می‌کند. متادیتای گزارش برای هر pattern، زنجیره‌ی کامل گام‌ها (predicate، نوع SPADL، lane، third)، قید فاصله‌ی مجاز، و شمارش فاصله‌های مشاهده‌شده‌ی embeddingها را نگه می‌دارد. فاصله‌ی مجاز از `max_gap` می‌آید؛ توزیع فاصله‌ی مشاهده‌شده فقط از sequenceهایی محاسبه می‌شود که در `candidate.support_ids` متعلق به داده‌ی train هستند، تا آمار holdout وارد متادیتای توصیفی pattern نشود. شمار پوشش فکت‌ها جداگانه روی frame ورودی projection گزارش می‌شود.

`patterns_only_inputs.py` دو builder دارد: bias واقعاً patterns-only، با `max_body=1`, `max_vars=1` و فقط pattern atoms؛ و bias ترکیبی، با pattern atoms و همهٔ predicateهای پایه. `run_phase5_sequential.py` از `build_hybrid_bias()` استفاده می‌کند، نه builder خالص. سقف مشترک `max_vars=2`, `max_body=3`, `max_clauses=4` است.

در runner آموزشی، مثال‌های context-matched با seed `202021` در سطح match به ۷۵٪ آموزش و ۲۵٪ holdout تقسیم می‌شوند. pattern mining فقط روی labelled sequenceهای matchهای آموزش fit می‌شود؛ pattern features انتخاب‌شده سپس روی frame سکانس‌ها projection می‌شوند و Popper با `exs.pl` آموزش می‌بیند. `exs_holdout.pl` از matchهای جداگانه ساخته می‌شود. در CV، mining در هر fold فقط روی matchهای training همان fold fit و بازسازی می‌شود؛ pattern features برای task همان fold projection می‌شوند. بنابراین انتخاب pattern در هیچ‌یک از این دو ارزیابی به labelهای holdout وابسته نیست.

## صورت‌بندی Popper و خروجی قواعد

فایل‌های استاندارد task:

| فایل | محتوا |
|---|---|
| `exs.pl` | مثال‌های `pos/1` و `neg/1` sequence-level |
| `bias.pl` | head/body، نوع و جهت آرگومان، سقف متغیر/literal/clause |
| `bk.pl` | قواعد و wrapperها به‌همراه consult فایل facts |
| `facts_patterns.pl` | فکت‌های pattern برای arm ترتیبی |
| log | trace، incumbentها و نتیجه‌ی جست‌وجو |

قاعده‌ی فرضی:

```prolog
negative_outcome(S) :- seq_dead_end_support(S), opponent_visible_majority(S).
```

بدنه conjunction است؛ چند clause برای head، OR منطقی می‌سازند. Popper در bias محدودشده candidate programs را می‌سازد و در حالت noisy اجازه‌ی خطای داده را می‌دهد. محدودیت `max_clauses` در worker علاوه بر bias به combiner اعمال شده تا برنامه‌ی ترکیبی هم از سقف عبور نکند. نتیجه‌ی `New best hypothesis` یک incumbent است؛ فقط وجود پایان موفق `SOLUTION` آن را فرضیه‌ی نهایی آن run می‌کند.

## ارزیابی دو بازو و تفسیر معیارها

`phase5_cv_common.py` matchها را بین foldها توزیع می‌کند تا هیچ match در train و test مشترک نباشد. seed پیش‌فرض `202021` است. Popper با نمونه‌های context-matched از matchهای train آموزش می‌بیند؛ ارزیابی هر fold روی **تمام labelled sequences** از matchهای test و در prevalence طبیعی انجام می‌شود. روش ترتیبی، pattern mining را در هر fold دوباره فقط با training matches انجام می‌دهد.

- `support = TP + FP`: تعداد مثال‌های پیش‌بینی‌شده به‌عنوان negative؛
- `precision = TP/(TP+FP)`: خلوص پیش‌بینی‌های negative؛
- `recall = TP/تعداد positiveهای واقعی`: پوشش outcomeهای منفی؛
- `lift = precision/base_rate`: precision نسبت به شیوع پایه؛
- `rule_stability`: در چند fold بدنه‌ی قاعده‌ی canonical دوباره کشف شده است.

`compare_phase5_methods.py` هیچ Popper search یا feature generation انجام نمی‌دهد. دو CV JSON را می‌خواند و revision پروتکل، تعداد clause، foldها، seed، matchها، sequenceها، base rate و partition دقیق matchها را کنترل می‌کند؛ سپس جدول مشترک می‌سازد. اگر CV reportها از revisionهای مختلف باشند یا split/base rate فرق کند، مقایسه را رد می‌کند.

CV runner incumbentهای میانی را هم امتیاز می‌دهد تا فهرست اکتشافی بسازد؛ چون این فرضیه‌ها با نگاه به چندین snapshot و همان holdout رتبه‌بندی می‌شوند، معیار آن shortlist برآورد بی‌طرف نیست. برای انتخاب نهایی rule به holdout تازه یا nested evaluation نیاز است. هیچ‌یک از precision/lift به تنهایی علیت را ثابت نمی‌کند.

## اجرا و فایل‌های خروجی

از ریشه‌ی پروژه، با داده و محیط Popper آماده:

```powershell
uv run python scripts/run_phase5.py
uv run python scripts/run_phase5_eval.py --rule "seq_dead_end_support,opponent_visible_majority"
uv run python scripts/run_phase5_cv.py
uv run python scripts/run_phase5_sequential.py
uv run python scripts/run_phase5_sequential_cv.py
uv run python scripts/compare_phase5_methods.py
```

CV پیش‌فرض سه fold دارد؛ sequential runner پارامترهای gap، support، growth، طول الگو، تعداد patternها، سقف candidate و تعداد suffix حذف‌شده را می‌پذیرد. `POPPER_DIR` باید مسیر checkout Popper باشد. مسیرهای متداول:

- `data/prolog/popper/` و `data/prolog/popper_sequential/`؛
- `data/prolog/popper_*_cv_fold_NN/` برای taskهای fold؛
- `data/reports/phase5_*training*.json` و logها؛
- `data/reports/phase5_*cv.json` و Markdownها؛
- `data/reports/phase5_two_method_comparison.json/.md`.

ورودی baseline manifest `phase4_feature_version` را با کد جاری تطبیق می‌دهند. پس از تغییر واژگان، مقصد پاس پشت خط و قیود هم‌پوشانی، `PATTERN_INPUT_VERSION=10` و `COMPARISON_PROTOCOL_REVISION=phase5-full-tactical-hybrid-sequential-two-arm-v8-final-third-pass-antiredundancy` هستند تا cacheها و گزارش‌های ناسازگار reuse نشوند. نسخه‌های ورودی داده نیز `PHASE1_VERSION=phase1-v5-pass-recipient-metadata`, `PHASE3_FEATURE_VERSION=active-popper-vocabulary-v6-crossed-pass-end-lanes` و `PHASE4_FEATURE_VERSION=phase4-v8-pass-exchange-helper-predicate` هستند. باید فازهای مشتق‌شده را به‌ترتیب دوباره اجرا کرد؛ شناسه‌ها جای hash کامل داده/facts نیستند.

## محدودیت‌ها و تفسیر مسئولانه

1. Label فاز ۲ تعریف عملیاتی از outcome build-up است، نه سنجه‌ی کامل ارزش مالکیت یا کیفیت همه‌ی تصمیم‌ها.
2. Training controls context-matched هستند؛ توزیعشان مثل جمعیت کامل نیست. به همین علت ارزیابی روی همه‌ی sequenceهای held-out و نرخ طبیعی گزارش می‌شود.
3. Predicateهای existential وقوع را می‌سنجند، نه تعداد یا ترتیب؛ تنها patternهای ترتیبی ترتیب را نمایش می‌دهند.
4. `action_result/2` و label factها body predicate نیستند، اما بعضی مفهوم‌های تاکتیکی از موفقیت اکشن مشتق می‌شوند. چون label عملیاتی به رخدادهای پایانی هم وابسته است، این ویژگی‌ها می‌توانند outcome-proximal باشند؛ CV گروه‌بندی‌شده بر اساس match، این وابستگی درون sequence را حذف نمی‌کند. تفسیر را به «بدون دسترسی مستقیم به label/result خام» محدود کنید، نه ادعای حذف تمام target association.
5. Pattern arm به‌طور مستقل یک suffix action را پیش از mining حذف می‌کند و سیگنال‌های look-ahead مرزی را suppress می‌کند؛ این حفاظت فقط به ورودی mining همان arm محدود است.
6. هر association می‌تواند از وضعیت بازی، حریف یا انتخاب نمونه اثر گرفته باشد؛ pattern mining رابطه‌ی علّی اثبات نمی‌کند.
7. Timeout، `NO SOLUTION` و provisional incumbent را از نتیجه‌ی نهایی جدا نگه دارید.
8. precision، recall، lift، support، ثبات بین foldها، false positives، زمان جست‌وجو و پرسش پژوهشی را با هم بخوانید.

## فایل‌های منبع

| بخش | کد |
|---|---|
| vocabulary و محدودیت‌ها و wrapper BK | [`phase5_vocabulary.py`](../src/tactical_ilp/prolog/phase5_vocabulary.py) |
| baseline examples/bias | [`legacy_43_inputs.py`](../src/tactical_ilp/prolog/legacy_43_inputs.py) |
| itemset، mining، scoring و pattern facts | [`sequential_patterns.py`](../src/tactical_ilp/sequences/sequential_patterns.py) |
| pure/hybrid bias و pattern compression | [`patterns_only_inputs.py`](../src/tactical_ilp/prolog/patterns_only_inputs.py) |
| اجرای Popper، validation و noisy clause cap | [`run_phase5.py`](../scripts/run_phase5.py) |
| آموزش بازوی ترتیبی | [`run_phase5_sequential.py`](../scripts/run_phase5_sequential.py) |
| fold، scoring و ابزارهای مشترک | [`phase5_cv_common.py`](../scripts/phase5_cv_common.py) |
| CV دو بازو و مقایسه | [`run_phase5_cv.py`](../scripts/run_phase5_cv.py), [`run_phase5_sequential_cv.py`](../scripts/run_phase5_sequential_cv.py), [`compare_phase5_methods.py`](../scripts/compare_phase5_methods.py) |
| تعریف outcome و نمونه‌گیری منفی | [`outcome_labeler.py`](../src/tactical_ilp/sequences/outcome_labeler.py), [`negative_sampling.py`](../src/tactical_ilp/sequences/negative_sampling.py) |
| facts و قواعد تاکتیکی مصرفی | [`prolog_facts.py`](../src/tactical_ilp/prolog/prolog_facts.py), [`tactical_facts.py`](../src/tactical_ilp/prolog/tactical_facts.py), [`bk.pl`](../src/tactical_ilp/prolog/bk.pl) |
