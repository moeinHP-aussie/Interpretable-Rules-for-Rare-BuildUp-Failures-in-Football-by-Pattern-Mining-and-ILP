# فاز ۶: ارزیابی قواعد و آماده‌سازی فرم بازبینی مربی

## هدف و جایگاه در خط لوله

فاز ۶ قواعدی را که Popper در فاز ۵ آموخته است از نظر پشتیبانی داده‌ای می‌سنجد و برای بازبینی انسانی آماده می‌کند. این فاز ادعای تاکتیکی را تأیید نمی‌کند و به‌تنهایی قانون را برای گزارش نهایی مجاز نمی‌سازد. تصمیم فوتبالیِ تأیید یا رد در فایل YAML و به دست مربی ثبت می‌شود؛ فاز ۷ فقط همان تصمیم‌ها را گزارش می‌کند.

ورودی‌های اصلی عبارت‌اند از فایل `SOLUTION` اجرای Popper، `bk.pl` و فایل‌های مثال آموزش و کنترل همان بازو. فایل‌های parquet فازهای قبل نیز باید آماده باشند. runner در [`scripts/run_phase6.py`](../scripts/run_phase6.py) است، محاسبات در [`src/tactical_ilp/evaluation/rule_metrics.py`](../src/tactical_ilp/evaluation/rule_metrics.py)، ساخت فرم در [`src/tactical_ilp/evaluation/coach_validation.py`](../src/tactical_ilp/evaluation/coach_validation.py)، و رجیستری قواعد بررسی‌شده در [`src/tactical_ilp/evaluation/rule_registry.py`](../src/tactical_ilp/evaluation/rule_registry.py) قرار دارد.

## بازوی پیش‌فرض برای فرم مربی

انتخاب جاری در [`src/tactical_ilp/reporting/method_config.py`](../src/tactical_ilp/reporting/method_config.py) تعریف شده است: `DEFAULT_COACH_METHOD = "hybrid_sequential"`. بنابراین به‌طور پیش‌فرض، فاز ۶ از بازوی دوم استفاده می‌کند؛ یعنی الگوهای ترتیبیِ استخراج‌شده از داده‌ی آموزش به‌اضافه‌ی predicateهای تاکتیکیِ پایه‌ای که در آن الگوها مصرف نشده‌اند.

تنظیم فعال از متغیر محیطی `TACTICAL_ILP_COACH_METHOD` خوانده می‌شود. مقدارهای پذیرفته‌شده `hybrid_sequential` و `full_tactical` هستند. مقدار دوم فقط برای بازبینی آگاهانه‌ی baseline واژگان تاکتیکی کامل است. اگر فایل‌های بازوی انتخاب‌شده موجود نباشند، runner با پیام خطا متوقف می‌شود؛ از فایل بازوی دیگر به‌عنوان جایگزین خاموش استفاده نمی‌کند.

مسیرهای بازو در `method_config.py` متمرکز شده‌اند:

| بازو | پوشه‌ی Prolog | log نهایی Popper |
|---|---|---|
| `hybrid_sequential`، پیش‌فرض | `data/prolog/popper_sequential/` | `data/reports/phase5_sequential_training_popper_output.txt` |
| `full_tactical` | `data/prolog/popper/` | `data/reports/phase5_popper_output.txt` |

## جداسازی آموزش و کنترل در بازوی ترتیبی

runner [`scripts/run_phase5_sequential.py`](../scripts/run_phase5_sequential.py) داده‌های نمونه‌برداری‌شده‌ی فاز ۲ را در سطح مسابقه تقسیم می‌کند. seed تقسیم `202021`، سهم holdout برابر ۲۵٪ مسابقه‌ها، و قاعده‌ی حداقل یک مسابقه‌ی holdout است؛ ترتیب مسابقه‌ها پیش از تقسیم به‌صورت قطعی shuffle می‌شود. شناسه‌ی مسابقه‌ها، تعداد مثال‌های دو بخش و تنظیم تقسیم در گزارش JSON اجرای ترتیبی ثبت می‌شوند.

الگوهای ترتیبی فقط با مسابقه‌های بخش آموزش fit و انتخاب می‌شوند. این نکته مهم است چون الگوی برگزیده نباید با دیدن برچسب‌های مسابقه‌های holdout انتخاب شود. پس از انتخاب، predicateهای الگو روی سکانس‌های موجود در frame فکت می‌گیرند تا Popper و ارزیابی فاز ۷ بتوانند آن‌ها را روی مثال‌های مربوطه query کنند؛ این projection سراسری، انتخاب الگو را به holdout وابسته نمی‌کند.

فایل‌های `exs.pl` و `exs_holdout.pl` در همان پوشه‌ی task نوشته می‌شوند. هر دو از نمونه‌های context-matched فاز ۲ ساخته شده‌اند و در سطح match از هم جدا هستند. در فایل‌ها، `pos(negative_outcome(S))` به معنی سکانس با برچسب `negative` و `neg(negative_outcome(S))` به معنی سکانس `non_negative` است. `bk.pl` بازوی ترتیبی، قواعد پس‌زمینه‌ی مشترک و facts مربوط به `seq_pattern_XX/1` را بارگذاری می‌کند.

تقسیم ثابت ۲۵درصدی یک ارزیابی تشخیصی برای امتیازدهی قواعد منتخب است، نه برآورد نهایی مستقل. ارزیابی اصلی تعمیم در cross-validation گروه‌بندی‌شده‌ی مسابقه‌ای فاز ۵ قرار دارد؛ برای روش دوم runner آن [`scripts/run_phase5_sequential_cv.py`](../scripts/run_phase5_sequential_cv.py) است. هر fold الگوها را فقط از مسابقه‌های آموزش همان fold استخراج می‌کند و کیفیت را روی سکانس‌های تمام مسابقه‌های کنارگذاشته‌شده با شیوع طبیعی برچسب ارزیابی می‌کند.

## انتخاب قواعدی که امتیاز می‌گیرند

تابع `current_popper_rules()` در `run_phase6.py` فقط بخش نهایی `SOLUTION` را از log بازوی فعال می‌خواند. «New best hypothesis»های میانی پیام‌های پیشرفت جست‌وجو هستند و به‌عنوان قواعد نهایی فرم مربی وارد نمی‌شوند. اگر بخش نهایی پیدا نشود، فاز ۶ قواعدی از log حدس نمی‌زند. قاعده‌هایی که در رجیستری `ALL_RULES` وجود داشته باشند دوباره تکرار نمی‌شوند؛ رجیستری فعلی عمداً خالی است تا فرضیه‌های مبتنی بر vocabulary بازنشسته دوباره وارد ارزیابی نشوند.

بدنه‌ی هر قاعده از literalهای تک‌آرگومانی با متغیر سکانس `S` خوانده می‌شود. هر predicate باید در `concept_dictionary.py` عبارت بازبینی‌شده داشته باشد. predicate ناشناخته به‌عنوان diagnostic ثبت می‌شود؛ فاز ۶ متن فوتبالی برای آن جعل نمی‌کند. در بازوی ترتیبی، `seq_pattern_XX` فقط وقتی شناخته می‌شود که metadata همان اجرای موفق در `phase5_sequential_training.json` موجود باشد.

## سنجه‌ها و روش محاسبه

منطق امتیازدهی در `rule_metrics.py` برای هر قاعده دو بار اجرا می‌شود: یک بار با `exs.pl` و یک بار با `exs_holdout.pl`. ارزیابی در SWI-Prolog روی همان `bk.pl` بازویی انجام می‌شود که قاعده از آن آمده است؛ سپس نتیجه‌ی query با شمارنده‌های زیر محاسبه می‌شود:

- **Support:** تعداد کل مثال‌هایی که بدنه‌ی قاعده روی آن‌ها برقرار است؛ یعنی `TP + FP`. support نسبت نیست و یک قانون با یک یا دو مشاهده پشتوانه‌ی ضعیفی دارد، حتی اگر confidence آن بالا باشد.
- **Confidence:** سهم سکانس‌های منفی در میان موارد منطبق، `TP / (TP + FP)`. چون `negative_outcome/1` هدف مثبت یادگیری است، این مقدار احتمال تجربی منفی‌بودن در گروه منطبق است.
- **Base rate:** سهم منفی‌ها در کل همان split، `n_positive / (n_positive + n_negative)` با قرارداد کلاس‌های Prolog بالا.
- **Lift:** `confidence / base_rate`. lift بزرگ‌تر از ۱ یعنی confidence قانون از نرخ پایه بیشتر است؛ lift نزدیک ۱ می‌تواند فقط بازتاب فراوانی یک رفتار معمول باشد و شاهد خطر تاکتیکی نیست.

فیلتر کمینه‌ی اجرا در `MIN_SUPPORT = 3` است. این فیلتر قانون کم‌پشتوانه را حذف نمی‌کند؛ فلگ `low_support` می‌گذارد تا مربی و گزارش نهایی آن را ببینند. اگر confidence از آموزش به holdout بیش از ۵۰٪ افت کند، `holdout_confidence_collapsed` روشن می‌شود. افت به شکل `(train_confidence - holdout_confidence) / train_confidence` محاسبه می‌شود؛ اگر confidence آموزش صفر باشد، نسبت افت تعریف نمی‌شود و فلگ روشن نخواهد شد. آستانه‌ها در `rule_metrics.py` ثابت‌اند: `MIN_SUPPORT=3` و `HOLDOUT_DROP_FLAG_RATIO=0.5`.

در ابتدای runner دو sanity check هم وجود دارد:

1. آزمون مصنوعی کنترل می‌کند که اگر confidence برابر base rate باشد، lift تقریباً ۱ شود.
2. `seq_supported_action` به‌عنوان الگوی شناخته‌شده‌ی سالم امتیاز می‌گیرد. این بررسی باید از تفسیر اشتباه «ویژگی رایج» به‌عنوان «عامل خطر» جلوگیری کند؛ نتیجه‌ی آن diagnostic است و قواعد دیگر را خودکار تأیید/رد نمی‌کند.

این سنجه‌ها همبستگی را اندازه می‌گیرند؛ نه علیت، کیفیت تصمیم بازیکن یا اثر مداخله‌ی مربی را.

## فرم بازبینی مربی

خروجی اصلی `data/reports/phase6_coach_validation.yaml` است. `write_coach_validation_file()` برای هر قانون بدنه‌ی Prolog، منبع بازو، عبارت فارسی ساخته‌شده از واژه‌نامه، سنجه‌های train/holdout، نسبت افت و فلگ‌های کم‌پشتیبانی/افت را ثبت می‌کند. مقدار `source_method` در ریشه‌ی YAML تعیین می‌کند فرم از کدام بازو آمده است؛ `source_fingerprint` نیز BK، bias، splitهای مثال، log نهایی و metadata آموزش روش ترتیبی را اثرانگشت می‌زند. اگر مدل/metadata پس از بازبینی تغییر کند، phase 7 فرم قدیمی را نمی‌پذیرد و ساخت مجدد فرم و بازبینی را لازم می‌کند.

مربی باید `validation_status` را به `approved` یا `rejected` تغییر دهد؛ یادداشت در `validation_note` اختیاری است. `pending` به معنی بازبینی‌نشده است. `validate_coach_file()` status معتبر را کنترل می‌کند. فرم بازوی فعال باید با `TACTICAL_ILP_COACH_METHOD` هماهنگ باشد؛ در صورت mismatch، ساخت گزارش فاز ۷ متوقف می‌شود تا فرم تازه‌ی فاز ۶ ساخته و بررسی شود.

برای فرم تعاملی راست‌به‌چپ، پس از اجرای فاز ۶ اجرا کنید:

```bash
uv run python scripts/generate_coach_review_ui.py --serve
```

نشانی محلی چاپ‌شده را در مرورگر باز کنید. شرح فارسی هر قاعده با `concept_dictionary.lookup` ساخته می‌شود. افت ۱۰۰درصدی اطمینان holdout، وضعیت اولیه‌ی «رد» می‌گیرد؛ همه‌ی قانون‌ها نیازمند انتخاب صریح مربی‌اند. دکمه‌ی ذخیره از حالت server فایل YAML استاندارد را در `data/reports/phase6_coach_validation.yaml` می‌نویسد؛ اگر HTML به‌شکل فایل ایستا باز شود، همان YAML را برای دانلود ارائه می‌کند.

رفتار دو CV runner یکسان نیست و نباید گزارش‌هایشان را با هم جابه‌جا کرد. `run_phase5_sequential_cv.py` برای بازوی دوم گزارش foldها و عملکرد خارج از آموزش را می‌سازد؛ status YAML را خودکار تغییر نمی‌دهد، پس در مسیر پیش‌فرض `hybrid_sequential` تصمیم‌ها دستی می‌مانند. `run_phase5_cv.py` فقط متعلق به baseline `full_tactical` است و در صورت تطابق `source_method` و fingerprint همان baseline، rules را بر اساس gateهای CV غربال می‌کند و ممکن است موارد پایدار را خودکار pre-approve کند. guard جدید آن اجازه نمی‌دهد YAML بازوی ترتیبی یا مدل قدیمی را بازنویسی کند. برای گزارش پیش‌فرضِ روش دوم، مربی باید statusها را خودش بررسی و ثبت کند.

### ترتیب اجرا

1. ساخت/به‌روزرسانی داده و facts فازهای پیشین.
2. اجرای `scripts/run_phase5_sequential.py` برای مدل پیش‌فرض ترتیبی؛ تنظیم `POPPER_DIR` به checkout Popper لازم است.
3. اجرای `scripts/run_phase5_sequential_cv.py` و بازبینی گزارش کیفیت foldها.
4. اجرای `scripts/run_phase6.py` برای ساخت فرم YAML از بازوی فعال.
5. بازبینی انسانی و ثبت status و دلیل هر قانون.
6. اجرای فاز ۷ پس از تکمیل فرم.

اگر عمداً baseline می‌خواهید، پیش از ساخت فرم فاز ۶ و گزارش فاز ۷ مقدار `TACTICAL_ILP_COACH_METHOD=full_tactical` را برای فرایندها تنظیم کنید و فرم آن بازو را جداگانه بررسی کنید. CV baseline ممکن است پس از آن غربال خودکار را روی همان فرم انجام دهد. CV بازوی دوم فقط معیار پایداری خود `hybrid_sequential` است و با فرم split ثابت فاز ۶ یکی نیست.

## خروجی‌های مهم و محدودیت‌ها

- `data/prolog/popper_sequential/exs.pl`, `exs_holdout.pl`, `bk.pl`, `bias.pl`, `facts_patterns.pl`: task و split بازوی دوم.
- `data/reports/phase5_sequential_training.json`: تنظیم‌ها و metadata الگوهای منتخب، زنجیره‌ی هر الگو و فاصله‌ی رخدادها.
- `data/reports/phase5_sequential_training_popper_output.txt`: log شامل نتیجه‌ی جست‌وجوی Popper.
- `data/reports/phase6_coach_validation.yaml`: فرم تصمیم انسانی.
- `data/reports/phase6_summary.json`: شمار قواعد، فلگ‌ها، sanity checkها و بازوی منبع.

فایل holdout ثابت برای انتخاب آستانه یا مقایسه‌ی مکرر مناسب نیست؛ پس از مشاهده‌ی آن، دیگر کاملاً مستقل نیست. قواعد ترتیبی نیز خلاصه‌ی روابط مکانی/زمانی بر اساس proxyهای پروژه‌اند. تفسیر نهایی باید metadata، نرخ رشد و حمایت الگو را کنار معیار CV و شواهد بازی بخواند.
