"""Create a resilient Phase 5 comparison, including an explicit NO SOLUTION result.

Available method reports are used as the source of truth. If the clean package
does not include the user's completed-run reports, the supplied run summary is
carried through with ``source=user_provided_summary`` so it is not confused
with a result recomputed from local artifacts.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tactical_ilp.config import REPORTS_DIR  # noqa: E402

BASELINE_PATH = REPORTS_DIR / "phase5_cross_validation.json"
SEQUENTIAL_CV_PATH = REPORTS_DIR / "phase5_sequential_cv.json"
SEQUENTIAL_TRAINING_PATH = REPORTS_DIR / "phase5_sequential_training.json"
OUTPUT_JSON = REPORTS_DIR / "phase5_two_method_comparison.json"
OUTPUT_MD = REPORTS_DIR / "phase5_two_method_comparison.md"


def _clause_body(clause: object) -> list[str]:
    """Return body predicates from either CV list clauses or report mappings."""
    if isinstance(clause, dict):
        body = clause.get("body", [])
    elif isinstance(clause, (list, tuple)):
        body = clause
    else:
        return []
    if not isinstance(body, (list, tuple)):
        return []
    return [str(predicate) for predicate in body]

# These are the user's reported results for the run reviewed in this task.
# They are used only when a corresponding local report is absent.
USER_REPORTED = {
    "full_tactical": {
        "status": "no_stable_program",
        "display": "No stable tactical program found (MDL prune / NO SOLUTION)",
        "metrics": None,
    },
    "hybrid_sequential": {
        "status": "successful_sequential_program",
        "display": "3-clause sequential program (Precision: 86%, Holdout Lift: 1.65x)",
        "metrics": {
            "training_precision": 18 / 21,
            "training_tp": 18,
            "training_fp": 3,
            "holdout_lift": 1.65,
            "held_out_sequences": 1881,
            "clauses": 3,
            "patterns": ["seq_pattern_01", "seq_pattern_03", "seq_pattern_04"],
        },
    },
}


def _read_report(path: Path) -> dict | None:
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"_read_error": str(exc)}
    return value if isinstance(value, dict) else {"_read_error": "report root is not an object"}


def _baseline_result(report: dict | None) -> dict:
    if report is None:
        return {**USER_REPORTED["full_tactical"], "source": "user_provided_summary", "report": str(BASELINE_PATH)}
    if report.get("_read_error"):
        return {**USER_REPORTED["full_tactical"], "source": "user_provided_summary", "report": str(BASELINE_PATH), "report_error": report["_read_error"]}

    folds = report.get("fold_results", [])
    rule_folds: dict[str, int] = {}
    folds = report.get("fold_results", [])
    for fold in folds:
        complete = not (
            fold.get("no_solution")
            or fold.get("used_provisional_hypothesis")
            or fold.get("hard_timed_out")
        )
        if not complete:
            continue
        for clause in fold.get("clauses", []):
            metrics = clause.get("test_metrics", {})
            canonical = clause.get("canonical") or ",".join(sorted(clause.get("body", [])))
            if canonical and float(metrics.get("lift", 0)) > 1.0 and int(metrics.get("support", 0)) > 0:
                rule_folds[canonical] = rule_folds.get(canonical, 0) + 1
    stable_rules = [body for body, count in rule_folds.items() if count >= 2]
    if not folds:
        for rule in report.get("rule_stability", []):
            metrics = rule.get("out_of_fold_metrics_on_folds_where_discovered", {})
            if int(rule.get("folds_found", 0)) >= 2 and float(metrics.get("lift", 0)) > 1.0 and int(metrics.get("support", 0)) > 0:
                stable_rules.append(rule)
    no_solution = bool(folds) and all(
        fold.get("no_solution") or fold.get("used_provisional_hypothesis") or fold.get("hard_timed_out")
        for fold in folds
    )
    if not stable_rules or no_solution:
        return {
            "status": "no_stable_program",
            "display": "No stable tactical program found (MDL prune / NO SOLUTION)",
            "source": "phase5_cross_validation.json",
            "report": str(BASELINE_PATH),
            "metrics": report.get("out_of_fold_metrics"),
            "stable_rule_count": len(stable_rules),
            "no_solution_or_provisional_folds": sum(
                bool(fold.get("no_solution") or fold.get("used_provisional_hypothesis") or fold.get("hard_timed_out"))
                for fold in folds
            ),
        }
    metrics = report.get("out_of_fold_metrics", {})
    return {
        "status": "stable_rules_found",
        "display": f"Stable tactical rules found (Precision: {float(metrics.get('precision', 0)):.0%}, Lift: {float(metrics.get('lift', 0)):.2f}x)",
        "source": "phase5_cross_validation.json",
        "report": str(BASELINE_PATH),
        "metrics": metrics,
        "stable_rule_count": len(stable_rules),
    }


def _sequential_result(cv_report: dict | None, training_report: dict | None) -> dict:
    if cv_report is None:
        fallback = dict(USER_REPORTED["hybrid_sequential"])
        fallback["source"] = "user_provided_summary"
        fallback["cv_report"] = str(SEQUENTIAL_CV_PATH)
        if training_report and isinstance(training_report.get("learned_clauses"), list):
            clauses = training_report["learned_clauses"]
            fallback["metrics"] = {**(fallback.get("metrics") or {}), "clauses": len(clauses)}
            fallback["learned_clauses"] = clauses
        return fallback
    if cv_report.get("_read_error"):
        fallback = dict(USER_REPORTED["hybrid_sequential"])
        fallback.update(source="user_provided_summary", cv_report=str(SEQUENTIAL_CV_PATH), report_error=cv_report["_read_error"])
        return fallback

    metrics = cv_report.get("out_of_fold_metrics", {})
    fold_results = cv_report.get("fold_results", [])
    max_clauses = max((len(fold.get("clauses", [])) for fold in fold_results), default=0)
    clauses = (training_report or {}).get("learned_clauses", [])
    clause_count = len(clauses) or max_clauses
    precision = float(metrics.get("precision", 0.0))
    lift = float(metrics.get("lift", 0.0))
    return {
        "status": "successful_sequential_program" if clause_count else "no_stable_program",
        "display": (
            f"{clause_count}-clause sequential program (OOF Precision: {precision:.0%}, OOF Lift: {lift:.2f}x)"
            if clause_count else "No sequential program found in the available CV folds"
        ),
        "source": "phase5_sequential_cv.json",
        "cv_report": str(SEQUENTIAL_CV_PATH),
        "training_report": str(SEQUENTIAL_TRAINING_PATH) if training_report else None,
        "metrics": metrics,
        "clauses": clause_count,
        "patterns": sorted({
            name for fold in fold_results for clause in fold.get("clauses", [])
            for name in _clause_body(clause) if name.startswith("seq_pattern_")
        }),
        "held_out_sequences": cv_report.get("n_labelled_sequences"),
    }


def run() -> dict:
    baseline = _baseline_result(_read_report(BASELINE_PATH))
    sequential = _sequential_result(_read_report(SEQUENTIAL_CV_PATH), _read_report(SEQUENTIAL_TRAINING_PATH))
    result = {
        "methods": {"full_tactical": baseline, "hybrid_sequential": sequential},
        "comparison_basis": "available JSON reports; missing-run summaries are explicitly labeled user_provided_summary",
    }
    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_JSON.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    rows = [
        "# مقایسهٔ دو بازوی فاز ۵",
        "",
        "| بازو | نتیجه | منبع |",
        "|---|---|---|",
        f"| `full_tactical` | {baseline['display']} | `{baseline['source']}` |",
        f"| `hybrid_sequential` | {sequential['display']} | `{sequential['source']}` |",
        "",
    ]
    if baseline["source"] == "user_provided_summary" or sequential["source"] == "user_provided_summary":
        rows.append("اعداد روش‌هایی که فایل گزارش محلی نداشتند، از خلاصهٔ ارائه‌شده توسط کاربر وارد شده‌اند و این اجرا آن‌ها را از داده بازتولید نکرده است.")
    if sequential.get("metrics", {}).get("patterns"):
        rows += ["", "الگوهای گزارش‌شده: " + ", ".join(f"`{name}`" for name in sequential["metrics"]["patterns"]) + "."]
    OUTPUT_MD.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"Comparison report -> {OUTPUT_MD}")
    print(f"Machine-readable comparison -> {OUTPUT_JSON}")
    print("\n".join(rows[4:6]))
    return result


if __name__ == "__main__":
    run()
