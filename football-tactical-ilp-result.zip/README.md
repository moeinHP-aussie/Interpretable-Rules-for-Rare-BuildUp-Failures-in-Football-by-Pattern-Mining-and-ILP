# Symbolic Tactical Analysis — FC Barcelona Build-up (Research prototype)

کشف الگوهای رفتاری تکرارشونده و ناخودآگاه در فاز بازیسازی (Build-up) با
ترکیب استخراج ویژگی‌های فوتبالیِ قاعده‌محور و **Inductive Logic Programming**
(Popper). این نسخه شبکهٔ عصبی آموزش نمی‌دهد؛ بنابراین «neuro-symbolic» توصیف
دقیقی برای پیاده‌سازی فعلی نیست.

* **دیتاست:** StatsBomb Open Data — La Liga 2020/21، FC Barcelona
  (`competition_id=11`, `season_id=90`)، ۳۵ بازی، همگی با داده ۳۶۰
* **زنجیره:** StatsBomb → SPADL → سکانس Build-up → Prolog Facts → Popper → گزارش مربی
* **وضعیت:** اسکریپت‌های فازهای ۰ تا ۷ آماده‌اند. نوت‌بوک Colab آن‌ها را به
  ترتیب اجرا می‌کند، خروجی Popper را ثبت می‌کند، قوانین را روی holdout
  ارزیابی می‌کند، بازبینی مربی را می‌گیرد و گزارش HTML و بستهٔ خروجی را
  دانلود می‌کند. تولید گزارش نهایی به تصمیم انسانی دربارهٔ هر قانون نیاز دارد.

> تعریف سکانس و پیامد منفی در نسخهٔ جاری تغییر کرده است. هر عدد یا مثال داده‌ای
> پایین‌تر که از اجرای قبلی آمده، snapshot تاریخی است؛ شمار سکانس‌ها، برچسب‌ها،
> نمونه‌های Popper و گزارش مربی پس از اجرای پاک Colab دوباره تولید می‌شوند.

فاز ۵ اکنون دو بازوی پژوهشی مقایسه‌پذیر دارد: واژگان تاکتیکی کاملِ بازبینی‌شده
(`full_tactical`, با شناسهٔ مسیر تاریخی `legacy_43`) و مدل ترکیبی
`hybrid_sequential`. واژگان پایه شامل ۲۰ مفهوم اکشنی، ۵ مفهوم سکانسی و ۲
مفهوم بازیکن-سکانس است. `costly_hesitation` به دلیل اتصال مستقیم مکث به شکست
اکشن بعدی همچنان از bias حذف می‌شود. هر دو بازو از محدودیت‌های
`max_vars=2`, `max_body=3`, `max_clauses=3` استفاده می‌کنند. پوشهٔ `data/`
عمداً در بستهٔ تمیز نیست؛ مراحل Colab آن را از داده و کد جاری بازسازی می‌کنند.

> داده از StatsBomb Open Data است. هنگام انتشار هر نتیجه‌ای، منبع را ذکر کنید.

---

## اجرای سریع

```bash
uv sync --extra dev
# Point this to the Popper checkout used by the dedicated runtime.
export POPPER_DIR=/path/to/Popper
uv run python scripts/run_phase0_check.py
uv run python scripts/run_phase1.py
uv run python scripts/run_phase2.py
uv run python scripts/run_phase3.py
uv run python scripts/run_phase4.py

# Full-tactical arm, then its match-grouped CV
uv run python scripts/run_phase5.py
uv run python scripts/run_phase5_cv.py --folds 3

# Hybrid arm: prepare ordered-pattern inputs first, then run Popper separately
uv run python scripts/run_phase5_sequential.py --prepare-only
uv run python scripts/run_phase5_sequential.py --popper-only
uv run python scripts/run_phase5_sequential_cv.py --folds 3
uv run python scripts/compare_phase5_methods.py

# Coach form/report after choosing the method and reviewing its CV
uv run python scripts/run_phase6.py
uv run python scripts/run_phase7.py
```

```bash
uv run python scripts/run_phase5.py
uv run python scripts/run_phase5_eval.py --rule "seq_dropped_between_lines,not_seq_first_time_play,seq_dead_end_support"
```

اجرای استاندارد فاز ۵، Popper را با سقف جست‌وجوی ۱۵ دقیقه و توقف سخت ۱۶ دقیقه
اجرا می‌کند. محدودیت `max_clauses(3)` در خروجی noisy هم به‌صورت صریح در مرحلهٔ
ترکیب قواعد اعمال می‌شود؛ اجرای مستقیم `popper.py` این محدودیت ترکیب را اعمال نمی‌کند.
این منطق در خود `scripts/run_phase5.py` قرار دارد و فایل کمکی جداگانه‌ای نیاز نیست.

> **کش داده:** اگر snapshotهای پردازش‌شده در `data/processed/` وجود داشته باشند،
> فازها از آن‌ها استفاده می‌کنند؛ در نبودشان داده‌ها را از ورودی خام می‌سازند.
> اگر سه خروجی اصلی فاز ۱ (`spadl_all_matches.parquet`,
> `spadl_with_360_all_matches.parquet`, `players_reference.parquet`) موجود باشند،
> `run_phase1.py` بدون تماس شبکه از آن‌ها استفاده می‌کند. `--force` بازسازی از
> دادهٔ خام StatsBomb را درخواست می‌کند؛ در این حالت فایل‌های خام باید موجود باشند
> یا دوباره دانلود شوند. خروجی‌های فازهای بعد هم برای ادامه/بازبینی سریع در بسته
> هستند، اما اجرای اسکریپت‌های آن فازها مطابق کد فعلی می‌تواند آن‌ها را بازسازی کند.

**ویندوز:** راهنمای کامل گام‌به‌گام در [`history_docs/SETUP_WINDOWS.md`](history_docs/SETUP_WINDOWS.md).

**اگر اینترنت/حجم دیسک محدود دارید:** به‌جای نصب لوکال، از
[`football_tactical_ilp_colab_setup.ipynb`](football_tactical_ilp_colab_setup.ipynb)
روی Google Colab استفاده کنید — هیچ نصبی روی سیستم خودتان انجام نمی‌شود.
راهنما: [`history_docs/COLAB_GUIDE.md`](history_docs/COLAB_GUIDE.md). نوت‌بوک در پایان
`data/reports/coach_report.html` و بستهٔ کامل نتایج را دانلود می‌کند.

> **چرا این گزینه لازم شد؟** Popper به `janus_swi` نیاز دارد، و `janus_swi`
> روی PyPI برای ویندوز فقط تا Python 3.13 wheel آماده دارد، در حالی که Popper
> صراحتاً Python ≥ 3.14 می‌خواهد. نتیجه: روی ویندوز باید از سورس build شود که
> به یک کامپایلر C (Visual Studio Build Tools) نیاز دارد. روی Colab (لینوکس)
> این کامپایلر از قبل نصب است.

---

## پیش‌نیازها

| ابزار | نسخه | چرا |
|---|---|---|
| Python | ۳.۱۱ یا ۳.۱۲ | `socceraction` روی ۳.۱۳+ کار نمی‌کند |
| uv | هر نسخه اخیر | مدیریت پکیج و محیط |
| SWI-Prolog | **≥ ۹.۱.۱۲** | `janus_swi` (وابسته Popper) نسخه پایین‌تر را رد می‌کند |
| Popper | 5.x | موتور ILP — در محیط پایتون ۳.۱۴ **مجزای خودش** اجرا می‌شود |

---

## خروجی اصلی

### نمونهٔ تاریخی فاز ۵ — نیازمند ارزیابی دوباره با Cross-validation

```prolog
negative_outcome(S) :-
    seq_dropped_between_lines(S),   % حامل توپ بین دو خط حریف افتاده
    not_seq_first_time_play(S),     % در سکانس اکشن با مکث ≤۰٫۵ ثانیه ثبت نشده
    seq_dead_end_support(S).        % گیرنده گزینه پیشرو نداشته
```

| مجموعه | نرخ پایه | دقت | بازیابی | **lift** |
|---|---|---|---|---|
| train (۲۶ بازی) | ۰.۳۲ | ۰.۶۷ | ۰.۳۵ | ۲.۰۸ |
| **holdout (۹ بازی، هرگز دیده‌نشده)** | ۰.۳۶ | ۰.۵۸ | ۰.۳۳ | **۱.۶۳** |

این اعداد مربوط به یک Holdout قدیمی‌اند و پس از مقایسهٔ چندباره دیگر آزمون
نهایی مستقل محسوب نمی‌شوند. برای برآورد فعلی از اسکریپت ارزیابی چندبخشی
پایین استفاده کنید. مسیر رسیدن به این قانون و ایرادهای روش‌شناختی اصلاح‌شده در
[`history_docs/phase5_review_findings.md`](history_docs/phase5_review_findings.md).

ارزیابی چندبخشی، Popper را در هر fold فقط روی نمونه‌های هم‌زمینهٔ بازی‌های
آموزشی اجرا می‌کند و روی تمام سکانس‌های برچسب‌خوردهٔ بازی‌های کنارگذاشته‌شده
می‌سنجد. معیار تجمیعی out-of-fold در
`data/reports/phase5_cross_validation.json` گزارش می‌شود؛ قوانین متفاوت
بین foldها و تعداد دفعات تکرار هر قانون نیز ثبت می‌شوند.

بودجهٔ پیش‌فرض جست‌وجو ۶۰۰ ثانیه برای هر fold است (hard-stop پس از ۶۳۰ ثانیه).
CV قوانین دارای شواهد قوی در دست‌کم دو fold کامل را در فایل فرم مربی
پیش‌فرض تأیید می‌کند؛ نامزدهای تک‌fold امیدوارکننده pending می‌مانند و قوانین
ضعیف یا فاقد شواهد کافی از فرم حذف می‌شوند. مربی می‌تواند تأیید پیش‌فرض را
تغییر دهد؛ دلایل حذف در گزارش JSON می‌ماند.

### فایل‌های داده تولیدشده

> اعداد زیر snapshot پیش از تعریف جاری‌اند و برای نتیجه‌گیری دربارهٔ نسخهٔ
> جدید استفاده نشوند.

```
data/prolog/facts_all.pl               96,609 fact هندسی/زمینه‌ای (فاز ۳)
data/prolog/facts_tactical.pl          25,988 fact تاکتیکی (فاز ۴)
data/prolog/bk.pl                      قوانین دست‌نویس Prolog (فاز ۴)
src/tactical_ilp/prolog/bk.pl          نسخهٔ منبع قوانین؛ فاز ۴ در صورت نبودن آن را کپی می‌کند
data/prolog/popper/
    bias.pl                            واژگان تاکتیکی کامل؛ arm دوم در هر fold الگوها را دوباره استخراج می‌کند
    bk.pl                              لفاف consult نسبی + wrapper سکانسی
    exs.pl                             ۱۰۰ مثال مثبت + ۲۰۹ منفی (train، هم‌زمینه)
    exs_holdout.pl                     ۴۳ مثبت + ۷۷ منفی (۹ بازی کنارگذاشته‌شده)
```

نمونهٔ شماتیک از factهای نسخهٔ جاری فاز ۳ است. شناسه‌ها و مقادیر صرفاً برای
نمایش قالب‌اند؛ برچسب هدف در `facts_all.pl` صادر نمی‌شود و در `exs.pl` قرار دارد:

```prolog
sequence(s_3773377_0002).
sequence_length(s_3773377_0002,5).

actor(a_3773377_00326,p_5203).
action_type(a_3773377_00326,dribble).
at_third(a_3773377_00326,defensive_third).
under_pressure(a_3773377_00326).
pressure_level(a_3773377_00326,light_pressure).
visible_player_count(a_3773377_00326,9).
action_result(a_3773377_00326,success).
```

**مهم:** هر predicate در `facts_all.pl` و `facts_tactical.pl` یک **Fact ثابت
از پیش محاسبه‌شده** است، نه یک rule زنده Prolog — هندسه در پایتون محاسبه و
اینجا فریز می‌شود. قوانین زنده Prolog فقط در `bk.pl` (فاز ۴) هستند.

---

## چارچوب مرجع

کل پروژه در یک چارچوب واحد کار می‌کند:

```
x ∈ [0, 105]   x=0 دروازه بارسا،  x=105 دروازه حریف   (بارسا همیشه به +x حمله می‌کند)
y ∈ [0, 68]    y=0 خط طولی سمت راست از دید جهت حمله بارسا
```

اکشن‌های حریف هم به همین چارچوب آینه می‌شوند.

---

## مستندات

| سند | محتوا |
|---|---|
| [`report.md`](report.md) | گزارش کامل کارهای انجام‌شده، تصمیم‌ها، مشکلات و انحراف‌ها |
| [`DOCs/project_workflow_dataflow_research_report_fa.md`](DOCs/project_workflow_dataflow_research_report_fa.md) | جریان کار/داده و گزارش پژوهشی فارسی |
| [`history_docs/SETUP_WINDOWS.md`](history_docs/SETUP_WINDOWS.md) | نصب و تست روی ویندوز |
| [`history_docs/COLAB_GUIDE.md`](history_docs/COLAB_GUIDE.md) | نصب و اجرا روی Google Colab (بدون نیاز به نصب لوکال) |
| [`history_docs/negative_outcome_definition.md`](history_docs/negative_outcome_definition.md) | تعریف عملیاتی «پیامد منفی» (تسک ۲.۲) |
| [`history_docs/negative_sampling_strategy.md`](history_docs/negative_sampling_strategy.md) | استراتژی نمونه‌گیری منفی (تسک ۲.۴) |
| [`history_docs/tactical_concepts_glossary.md`](history_docs/tactical_concepts_glossary.md) | واژه‌نامه جامع ۷۱ مفهوم تاکتیکی (نسخه ۳، تأییدشده) |
| [`history_docs/phase4_concept_disposition.md`](history_docs/phase4_concept_disposition.md) | تصمیم نهایی برای هرکدام از ۷۱ مفهوم (ساخته شد / رد شد / چرا) |
| [`history_docs/phase5_review_findings.md`](history_docs/phase5_review_findings.md) | یافته‌های تاریخی و اصلاحات قبلی فاز ۵؛ شمارها snapshot همان نسخه‌اند |
| [`history_docs/external_audit_verification.md`](history_docs/external_audit_verification.md) | راستی‌آزمایی ادعاهای گزارش بیرونی و تصمیم هر پیشنهاد اصلاحی |
