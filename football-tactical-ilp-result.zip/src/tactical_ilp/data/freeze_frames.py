"""
Task 1.3 — Link StatsBomb 360 freeze-frames to SPADL actions.

The 360 file gives, for (almost) every event, the position of the players that
were inside the broadcast camera frame at that exact instant.  That is the only
off-the-ball information available in the MVP (technical document §2.4): a
snapshot, not a continuous trajectory.

For every SPADL action we derive a small set of *context features* from the
freeze frame; phase 3 turns these numbers into Prolog facts.

Coordinate handling
-------------------
Freeze-frame coordinates are raw StatsBomb (120 x 80) and are expressed from the
point of view of the team that performed the event.  We therefore

    1. rescale   ->  SPADL 105 x 68 with the y axis flipped
                     (identical formula to socceraction's event conversion)
    2. mirror    ->  if the acting team is not Barcelona, so that the whole
                     project lives in one reference frame (Barcelona -> +x).

``teammate`` in the raw file is relative to the acting player, which is exactly
the notion of "opponent" we need for a pressure model.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from tactical_ilp.config import (
    PHASE1_VERSION,
    PITCH_LENGTH,
    PITCH_WIDTH,
    PRESSURE_RADIUS_M,
    PROCESSED_DIR,
    TIGHT_PRESSURE_RADIUS_M,
    cache_path,
)
from tactical_ilp.data.load_raw_data import barca_match_ids, load_frames
from tactical_ilp.data.spadl_converter import build_spadl, read_if_current

MERGED_ALL_PATH = PROCESSED_DIR / "spadl_with_360_all_matches.parquet"

CONTEXT_COLUMNS = [
    "ff_n_visible",
    "ff_opponents_5m",
    "ff_opponents_3m",
]


def frames_to_spadl_coordinates(frames: pd.DataFrame) -> pd.DataFrame:
    """Rescale raw 120x80 StatsBomb coordinates to SPADL 105x68."""
    out = frames.copy()
    out["fx"] = out["x"] / 120.0 * PITCH_LENGTH
    out["fy"] = PITCH_WIDTH - (out["y"] / 80.0 * PITCH_WIDTH)
    return out


def compute_context_features(actions: pd.DataFrame, frames: pd.DataFrame) -> pd.DataFrame:
    """Aggregate each 360 frame once, keyed by its StatsBomb event id."""
    if len(frames) == 0:
        return pd.DataFrame(columns=CONTEXT_COLUMNS, dtype=float)

    frames = frames_to_spadl_coordinates(frames)

    ref = (
        actions[["original_event_id", "start_x", "start_y", "is_barca"]]
        .dropna(subset=["original_event_id"])
        .rename(columns={"original_event_id": "event_id"})
    )
    ref["event_id"] = ref["event_id"].astype(str)
    # Some events (notably pass/interception splits) back multiple SPADL rows.
    # Joining both copies to the frame doubles every visible-player count.
    ref = ref.drop_duplicates("event_id", keep="first")

    ff = frames.merge(ref, on="event_id", how="inner")
    if len(ff) == 0:
        return pd.DataFrame(columns=CONTEXT_COLUMNS, dtype=float)

    # mirror opponent-team frames into Barcelona's reference frame
    flip = ~ff["is_barca"].to_numpy()
    ff.loc[flip, "fx"] = PITCH_LENGTH - ff.loc[flip, "fx"]
    ff.loc[flip, "fy"] = PITCH_WIDTH - ff.loc[flip, "fy"]

    ff["dist"] = np.hypot(ff["fx"] - ff["start_x"], ff["fy"] - ff["start_y"])
    is_opp = ~ff["teammate"].to_numpy()

    grp = ff.groupby("event_id")
    agg = pd.DataFrame(
        {
            "ff_n_visible": grp.size(),
            "ff_opponents_5m": ff[is_opp & (ff["dist"] <= PRESSURE_RADIUS_M)]
            .groupby("event_id")
            .size(),
            "ff_opponents_3m": ff[is_opp & (ff["dist"] <= TIGHT_PRESSURE_RADIUS_M)]
            .groupby("event_id")
            .size(),
        }
    )
    agg[list(agg.columns)] = agg[list(agg.columns)].fillna(0)
    return agg


def build_merged(match_id: int, force: bool = False) -> pd.DataFrame:
    """SPADL actions of one match plus their 360 context features."""
    path = cache_path("merged", match_id)
    if not force:
        cached = read_if_current(path)
        if cached is not None:
            return cached

    actions = build_spadl(match_id).copy()
    frames = load_frames(match_id)
    agg = compute_context_features(actions, frames)

    actions = actions.drop(
        columns=[c for c in CONTEXT_COLUMNS + ["has_freeze_frame", "freeze_frame"] if c in actions]
    )
    key = actions["original_event_id"].astype(str).rename("event_id")
    actions = actions.join(agg, on=key.rename("event_id"))
    for col in CONTEXT_COLUMNS:
        if col not in actions:
            actions[col] = np.nan
    actions["has_freeze_frame"] = actions["ff_n_visible"].notna()
    actions["freeze_frame"] = actions["ff_n_visible"]  # alias used by the phase-1 test
    actions["phase1_version"] = PHASE1_VERSION

    actions.to_parquet(path, index=False)
    return actions


def build_all(match_ids: list[int] | None = None, force: bool = False) -> pd.DataFrame:
    ids = match_ids if match_ids is not None else barca_match_ids()
    if not force:
        cached = read_if_current(MERGED_ALL_PATH, ids)
        if cached is not None:
            return cached
    out = []
    for i, mid in enumerate(ids, 1):
        df = build_merged(mid, force=force)
        cov = df[df.type_name.isin(["pass", "dribble"])]["has_freeze_frame"].mean()
        out.append(df)
        print(f"[{i:>2}/{len(ids)}] match {mid}: build-up 360 coverage {cov:.1%}")
    merged = pd.concat(out, ignore_index=True)
    merged.to_parquet(MERGED_ALL_PATH, index=False)
    return merged


if __name__ == "__main__":
    merged = build_all()
    build_up = merged[merged.type_name.isin(["pass", "dribble"])]
    print()
    print(f"total actions          : {len(merged)}")
    print(f"build-up actions       : {len(build_up)}")
    print(f"360 coverage (build-up): {build_up['has_freeze_frame'].mean():.2%}")
    print(f"360 coverage (all)     : {merged['has_freeze_frame'].mean():.2%}")
