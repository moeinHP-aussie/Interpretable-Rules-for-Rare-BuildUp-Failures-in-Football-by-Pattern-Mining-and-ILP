"""Assign build-up outcomes using the three-zone operational definition.

The active definition is documented in ``docs/negative_outcome_definition.md``.
It distinguishes immediate losses in Barcelona's defensive third from losses
 through defensive, own-half midfield, and advanced-opponent-half loss zones.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from tactical_ilp.config import (
    DEFENSIVE_THIRD_MAX_X,
    MIDFIELD_REGAIN_WINDOW_S,
    MIDFIELD_OPPONENT_SUCCESSIVE_ACTIONS,
    MIN_OPPONENT_DIRECT_PROGRESS_M,
    OWN_HALF_MAX_X,
    BUILD_UP_ZONE_ENTRY_X,
    PROCESSED_DIR,
)
from tactical_ilp.data.freeze_frames import build_all as build_merged_all
from tactical_ilp.sequences.sequence_builder import build_all as build_sequences

LABELED_PATH = PROCESSED_DIR / "labeled_sequences.parquet"
LABEL_CACHE_VERSION = "completed-build-up-controlled-regain-midfield-threat-v4"
LABEL_CACHE_VERSION_PATH = PROCESSED_DIR / "label_cache_version.txt"

# Machine-readable definition consumed by docs_sync.
DEFINITION = {
    "defensive_third_max_x": DEFENSIVE_THIRD_MAX_X,
    "own_half_max_x": OWN_HALF_MAX_X,
    "advanced_opponent_middle_max_x": BUILD_UP_ZONE_ENTRY_X,
    "midfield_regain_window_s": MIDFIELD_REGAIN_WINDOW_S,
    "opponent_successive_successes": MIDFIELD_OPPONENT_SUCCESSIVE_ACTIONS,
    "minimum_opponent_direct_progress_m": MIN_OPPONENT_DIRECT_PROGRESS_M,
}

FAILED_RESULTS = {"fail", "owngoal"}
SHOT_TYPES = {"shot", "shot_freekick", "shot_penalty"}
DEAD_BALL_RESTART_TYPES = {
    "throw_in",
    "freekick_short",
    "freekick_crossed",
    "corner_short",
    "corner_crossed",
    "goalkick",
    "foul",
}
TRANSITION_CONTEXT_WINDOW_S = 12.0
CONTROLLED_REGAIN_TYPES = {
    "pass",
    "cross",
    "dribble",
    "take_on",
    "carry",
    "goalkick",
    "freekick_short",
    "freekick_crossed",
    "throw_in",
    "corner_short",
    "corner_crossed",
    "keeper_pick_up",
    "keeper_claim",
}


def _is_success(action: pd.Series) -> bool:
    return str(action.get("result_name", "")) == "success"


def _is_controlled_regain(action: pd.Series) -> bool:
    """Whether a Barcelona action evidences retained, controlled possession."""
    return (
        _is_success(action)
        and str(action.get("type_name", "")) in CONTROLLED_REGAIN_TYPES
    )


def _after_sequence(seq: pd.Series, match_actions: pd.DataFrame) -> pd.DataFrame:
    return match_actions[
        (match_actions["period_id"] == seq["period_id"])
        & (match_actions["row"] > int(seq["last_action_row"]))
    ].sort_values("row")


def _opponent_control_evidence(
    after: pd.DataFrame, turnover_row: int, turnover_time: float
) -> tuple[bool, bool, int, bool, bool, bool]:
    """Return regain, opponent success/run, direct transition and first-action threat.

    The first opponent action that acquires the ball is included in the window
    and in the consecutive-success count. Only a successful Barcelona action
    that evidences controlled possession counts as a regain; unsuccessful
    actions and opponent failures break the consecutive-success run.
    """
    later = after[
        (after["row"] >= turnover_row)
        & (after["time_seconds"] <= turnover_time + MIDFIELD_REGAIN_WINDOW_S)
    ].sort_values("row")
    regain = False
    consecutive = 0
    max_consecutive = 0
    opponent_success = False
    direct_transition = False
    direct_transition_open = True
    first_opponent_seen = False
    immediate_threat = False

    for _, action in later.iterrows():
        elapsed = float(action["time_seconds"]) - turnover_time
        if elapsed < 0:
            continue
        is_barca = bool(action["is_barca"])

        if is_barca:
            if _is_controlled_regain(action):
                regain = True
                break
            consecutive = 0
            continue

        first_opponent_action = not first_opponent_seen
        first_opponent_seen = True
        action_type = str(action.get("type_name", ""))
        if first_opponent_action and action_type not in DEAD_BALL_RESTART_TYPES:
            # A single immediate penetration into Barcelona's defensive third
            # or a shot is enough danger to qualify as a midfield transition.
            if action_type in SHOT_TYPES:
                immediate_threat = True
            elif (
                _is_success(action)
                and float(action.get("start_x", np.nan)) > DEFENSIVE_THIRD_MAX_X
                and float(action.get("end_x", np.nan)) <= DEFENSIVE_THIRD_MAX_X
            ):
                immediate_threat = True

        if _is_success(action):
            opponent_success = True
            consecutive += 1
            max_consecutive = max(max_consecutive, consecutive)
            if direct_transition_open and action_type in DEAD_BALL_RESTART_TYPES:
                direct_transition_open = False
            if direct_transition_open:
                start_x = float(action.get("start_x", np.nan))
                end_x = float(action.get("end_x", np.nan))
                moved_toward_barcelona = (
                    start_x - end_x >= MIN_OPPONENT_DIRECT_PROGRESS_M
                )
                entered_defensive_third = (
                    start_x > DEFENSIVE_THIRD_MAX_X
                    and end_x <= DEFENSIVE_THIRD_MAX_X
                )
                direct_transition = direct_transition or (
                    moved_toward_barcelona or entered_defensive_third
                )
        else:
            consecutive = 0
            if action_type in DEAD_BALL_RESTART_TYPES:
                direct_transition_open = False

    return (
        regain,
        max_consecutive >= MIDFIELD_OPPONENT_SUCCESSIVE_ACTIONS,
        max_consecutive,
        opponent_success,
        direct_transition,
        immediate_threat,
    )


def _label_one(seq: pd.Series, match_actions: pd.DataFrame) -> dict:
    after = _after_sequence(seq, match_actions)
    last_action = match_actions[
        match_actions["row"] == int(seq["last_action_row"])
    ].iloc[0]

    # A failed final Barcelona action is itself direct evidence of a loss.
    final_action_failed = (
        bool(last_action["is_barca"])
        and str(last_action.get("result_name", "")) in FAILED_RESULTS
    )
    own_goal = str(last_action.get("result_name", "")) == "owngoal"
    build_up_completed = str(seq.get("end_reason", "")) in {
        "shot",
        "attacking_zone_entry",
    }

    # Otherwise possession must pass immediately to the opponent. An own-team
    # action after the segment proves that this segment did not lose the ball.
    first_opponent = None
    if len(after) and not bool(after.iloc[0]["is_barca"]):
        first_opponent = after.iloc[0]

    # A foul as the first opposing action is a stoppage, not reliable evidence
    # that Barcelona lost possession. It can also follow an apparent failed
    # action, so give the foul event precedence for this boundary decision.
    opponent_foul_stoppage = bool(
        first_opponent is not None
        and str(first_opponent.get("type_name", "")) == "foul"
    )

    lost_possession = (
        final_action_failed or first_opponent is not None
    ) and not opponent_foul_stoppage
    if opponent_foul_stoppage:
        turnover_x = np.nan
        turnover_time = np.nan
        turnover_row = -1
    elif final_action_failed:
        turnover_x = float(last_action["end_x"])
        turnover_time = float(last_action["time_seconds"])
        turnover_row = int(last_action["row"])
    elif first_opponent is not None:
        turnover_x = float(first_opponent["start_x"])
        turnover_time = float(first_opponent["time_seconds"])
        turnover_row = int(first_opponent["row"])
    else:
        turnover_x = np.nan
        turnover_time = np.nan
        turnover_row = -1

    defensive_third_loss = bool(
        lost_possession
        and not np.isnan(turnover_x)
        and turnover_x <= DEFENSIVE_THIRD_MAX_X
    )
    own_midfield_loss = bool(
        lost_possession
        and not np.isnan(turnover_x)
        and DEFENSIVE_THIRD_MAX_X < turnover_x <= OWN_HALF_MAX_X
    )

    # These observations remain available to tactical predicates and reports,
    # but do not participate in the negative-label decision.
    context = (
        after[
            (after["row"] > turnover_row)
            & (after["time_seconds"] <= turnover_time + TRANSITION_CONTEXT_WINDOW_S)
            & (~after["is_barca"])
        ]
        if lost_possession
        else after.iloc[0:0]
    )
    opponent_shot_after = bool(context["type_name"].isin(SHOT_TYPES).any())
    opponent_entered_def_third = bool(
        (
            (context["start_x"] <= DEFENSIVE_THIRD_MAX_X)
            | (context["end_x"] <= DEFENSIVE_THIRD_MAX_X)
        ).any()
    )

    if lost_possession:
        (regained_within_5s, two_opponent_successes, max_opponent_run,
         opponent_success_after, opponent_direct_transition,
         opponent_immediate_threat) = (
            _opponent_control_evidence(
                after, turnover_row, turnover_time
            )
        )
    else:
        (regained_within_5s, two_opponent_successes, max_opponent_run,
         opponent_success_after, opponent_direct_transition,
         opponent_immediate_threat) = False, False, 0, False, False, False

    defensive_third_negative = bool(
        defensive_third_loss
        and not build_up_completed
        and (own_goal or (final_action_failed and opponent_success_after and not regained_within_5s))
    )
    midfield_negative = bool(
        own_midfield_loss
        and not build_up_completed
        and not regained_within_5s
        and (two_opponent_successes or opponent_immediate_threat)
    )
    advanced_opponent_middle_loss = bool(
        lost_possession
        and not build_up_completed
        and OWN_HALF_MAX_X < turnover_x < BUILD_UP_ZONE_ENTRY_X
    )
    advanced_opponent_middle_negative = bool(
        advanced_opponent_middle_loss
        and opponent_direct_transition
        and not regained_within_5s
    )
    is_negative = (
        defensive_third_negative
        or midfield_negative
        or advanced_opponent_middle_negative
    )

    # An inaccurate pass launched from the advanced attacking zone is
    # ambiguous as a build-up failure: the recorded endpoint is not a reliable
    # proxy for where possession was actually lost. Abstain instead of adding
    # it to the control class.
    advanced_failed_pass = bool(
        final_action_failed
        and str(last_action.get("type_name", "")) == "pass"
        and pd.notna(last_action.get("end_x"))
        and float(last_action.get("end_x")) >= BUILD_UP_ZONE_ENTRY_X
    )
    inconclusive = (
        opponent_foul_stoppage or advanced_failed_pass
    ) and not build_up_completed

    if build_up_completed:
        reason = (
            "build_up_completed_shot"
            if str(seq.get("end_reason", "")) == "shot"
            else "build_up_completed_attacking_zone_entry"
        )
    elif opponent_foul_stoppage:
        reason = "first_opponent_action_foul"
    elif advanced_failed_pass:
        reason = "advanced_failed_pass_endpoint_uncertain"
    elif defensive_third_loss and own_goal:
        reason = "defensive_third_own_goal"
    elif defensive_third_negative:
        reason = "defensive_third_turnover"
    elif midfield_negative:
        reason = (
            "own_half_midfield_immediate_threat"
            if opponent_immediate_threat and not two_opponent_successes
            else "own_half_midfield_unrecovered_control"
        )
    elif advanced_opponent_middle_negative:
        reason = "advanced_opponent_middle_direct_transition"
    elif defensive_third_loss:
        reason = (
            "defensive_third_regained_within_5s"
            if regained_within_5s
            else "defensive_third_without_opponent_success_within_5s"
        )
    elif own_midfield_loss and regained_within_5s:
        reason = "own_half_midfield_regained_within_5s"
    elif own_midfield_loss:
        reason = "own_half_midfield_without_two_opponent_successes"
    elif advanced_opponent_middle_loss and regained_within_5s:
        reason = "advanced_opponent_middle_regained_within_5s"
    elif advanced_opponent_middle_loss:
        reason = "advanced_opponent_middle_without_direct_transition"
    else:
        reason = "no_qualifying_turnover"

    return {
        "sequence_id": seq["sequence_id"],
        "lost_possession": bool(lost_possession),
        "turnover_x": turnover_x,
        "turnover_time": turnover_time,
        "turnover_row": turnover_row,
        "turnover_zone": (
            "defensive_third" if defensive_third_loss else
            "own_half_midfield" if own_midfield_loss else
            "advanced_opponent_middle" if advanced_opponent_middle_loss else
            "outside_target_zones" if lost_possession else "none"
        ),
        "final_action_failed": bool(final_action_failed),
        "build_up_completed": bool(build_up_completed),
        "defensive_third_negative": defensive_third_negative,
        "opponent_success_after": opponent_success_after,
        "opponent_direct_transition": opponent_direct_transition,
        "opponent_immediate_threat": opponent_immediate_threat,
        "opponent_shot_after": opponent_shot_after,
        "opponent_entered_def_third": opponent_entered_def_third,
        "regained_within_5s": bool(regained_within_5s),
        "two_consecutive_opponent_successes": bool(two_opponent_successes),
        "max_consecutive_opponent_successes": int(max_opponent_run),
        "negative_reason": reason,
        "label": (
            "inconclusive" if inconclusive else
            "negative" if is_negative else
            "non_negative"
        ),
    }


def label_sequences(force: bool = False) -> pd.DataFrame:
    cache_current = (
        LABEL_CACHE_VERSION_PATH.exists()
        and LABEL_CACHE_VERSION_PATH.read_text(encoding="utf-8").strip()
        == LABEL_CACHE_VERSION
    )
    if LABELED_PATH.exists() and not force and cache_current:
        return pd.read_parquet(LABELED_PATH)

    sequences, _ = build_sequences()
    merged = build_merged_all()
    merged = merged.sort_values(
        ["match_id", "period_id", "time_seconds", "action_id"]
    )
    merged["row"] = merged.groupby("match_id").cumcount()
    by_match = {mid: grp for mid, grp in merged.groupby("match_id")}

    labels = pd.DataFrame(
        [
            _label_one(seq, by_match[seq["match_id"]])
            for _, seq in sequences.iterrows()
        ]
    )
    out = sequences.merge(labels, on="sequence_id", how="left")

    from tactical_ilp.features.geometry import lane_of, third_of

    out["zone"] = [
        f"{third_of(x)}|{lane_of(y)}" for x, y in zip(out.start_x, out.start_y)
    ]
    out.to_parquet(LABELED_PATH, index=False)
    LABEL_CACHE_VERSION_PATH.write_text(LABEL_CACHE_VERSION + "\n", encoding="utf-8")
    return out


if __name__ == "__main__":
    df = label_sequences(force=True)
    print(f"sequences: {len(df)}")
    print("\nlabel balance:")
    print(df.label.value_counts().to_string())
    print(df.label.value_counts(normalize=True).round(4).to_string())
    print("\nturnover zones:")
    print(pd.crosstab(df.turnover_zone, df.label).to_string())
    print("\nnegative reasons:")
    print(df.loc[df.label == "negative", "negative_reason"].value_counts().to_string())
    print("\nlabel x end_reason:")
    print(pd.crosstab(df.end_reason, df.label).to_string())
