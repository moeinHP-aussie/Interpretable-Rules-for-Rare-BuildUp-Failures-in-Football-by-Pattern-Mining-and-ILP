% AUTO-GENERATED, fold-specific sequential-pattern features.
% max_gap=2 intervening actions; suffix=1 action(s) excluded.
% Pattern selection used only training matches; facts below are projected to all rows.

seq_pattern_01(s_3764661_0030).
seq_pattern_01(s_3773474_0027).
seq_pattern_01(s_3773474_0034).
seq_pattern_01(s_3773497_0009).
seq_pattern_01(s_3773523_0002).
seq_pattern_01(s_3773526_0029).
seq_pattern_01(s_3773547_0024).
seq_pattern_01(s_3773547_0072).
seq_pattern_01(s_3773571_0009).
seq_pattern_01(s_3773593_0014).
seq_pattern_01(s_3773597_0004).
seq_pattern_01(s_3773597_0008).
seq_pattern_01(s_3773597_0016).
seq_pattern_01(s_3773660_0041).
seq_pattern_01(s_3773672_0015).
seq_pattern_02(s_3764661_0030).
seq_pattern_02(s_3773386_0031).
seq_pattern_02(s_3773474_0017).
seq_pattern_02(s_3773474_0027).
seq_pattern_02(s_3773526_0040).
seq_pattern_02(s_3773571_0013).
seq_pattern_02(s_3773585_0030).
seq_pattern_02(s_3773597_0022).
seq_pattern_02(s_3773597_0035).
seq_pattern_02(s_3773661_0045).
seq_pattern_02(s_3773665_0006).
seq_pattern_03(s_3773457_0000).
seq_pattern_03(s_3773457_0021).
seq_pattern_03(s_3773526_0000).
seq_pattern_03(s_3773547_0024).
seq_pattern_03(s_3773547_0045).
seq_pattern_03(s_3773547_0072).
seq_pattern_03(s_3773552_0011).
seq_pattern_03(s_3773571_0053).
seq_pattern_03(s_3773571_0063).
seq_pattern_03(s_3773585_0010).
seq_pattern_03(s_3773586_0029).
seq_pattern_03(s_3773586_0049).
seq_pattern_03(s_3773660_0041).
