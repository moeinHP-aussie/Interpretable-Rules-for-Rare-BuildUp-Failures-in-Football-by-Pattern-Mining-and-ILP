%% ===================================================================
%%  AUTO-GENERATED - phase 5 Popper background knowledge wrapper
%%
%%  Loads the phase 3/4 facts and hand-written bk.pl, then defines one
%%  seq_<concept>/1 wrapper per action-level or player-level concept so
%%  Popper only ever reasons over Sequence, never over Action or Player
%%  variables directly (keeps the search space small).
%%
%%  PATHS ARE RELATIVE to this file, resolved at load time via
%%  prolog_load_context/2.  An earlier version baked in absolute paths from
%%  the machine that generated it, which broke the moment the project was
%%  unzipped anywhere else (Colab, Windows, a different user).
%% ===================================================================

%%  SWI-Prolog resolves a relative path in consult/1 against the directory
%%  of the file containing the directive, so these stay correct wherever the
%%  project is unpacked.
:- consult('../facts_all.pl').
:- consult('../facts_tactical.pl').
:- consult('../bk.pl').


seq_line_breaking_pass(S) :-
    in_sequence(A, S),
    line_breaking_pass(A).

seq_diagonal_pass(S) :-
    in_sequence(A, S),
    diagonal_pass(A).

seq_switch_to_right(S) :-
    in_sequence(A, S),
    switch_to_right(A).

seq_switch_to_left(S) :-
    in_sequence(A, S),
    switch_to_left(A).

seq_aerial_pass(S) :-
    in_sequence(A, S),
    aerial_pass(A).

seq_long_pass(S) :-
    in_sequence(A, S),
    long_pass(A).

seq_pass_in_behind(S) :-
    in_sequence(A, S),
    pass_in_behind(A).

seq_line_pass(S) :-
    in_sequence(A, S),
    line_pass(A).

seq_connecting_pass(S) :-
    in_sequence(A, S),
    connecting_pass(A).

seq_dropped_between_lines(S) :-
    in_sequence(A, S),
    dropped_between_lines(A).

seq_first_time_play(S) :-
    in_sequence(A, S),
    first_time_play(A).

seq_dwelt_long(S) :-
    in_sequence(A, S),
    dwelt_long(A).

seq_supported_action(S) :-
    in_sequence(A, S),
    supported_action(A).

seq_dead_end_support(S) :-
    in_sequence(A, S),
    dead_end_support(A).

seq_triangulation_opponent_trapped(S) :-
    in_sequence(A, S),
    triangulation_opponent_trapped(A).

seq_rondo_cage(S) :-
    in_sequence(A, S),
    rondo_cage(A).

seq_press_resistance(S) :-
    in_sequence(A, S),
    press_resistance(A).

seq_counter_pressed(S) :-
    in_sequence(A, S),
    counter_pressed(A).

seq_rest_defence_exposed(S) :-
    in_sequence(A, S),
    rest_defence_exposed(A).

seq_under_pressure(S) :-
    in_sequence(A, S),
    under_pressure(A).

seq_flank_line_carry(S) :-
    in_sequence(A, S),
    flank_line_carry(A).

seq_flank_cut_inside(S) :-
    in_sequence(A, S),
    flank_cut_inside(A).

seq_flank_dribble(S) :-
    in_sequence(A, S),
    flank_dribble(A).

seq_central_long_carry(S) :-
    in_sequence(A, S),
    central_long_carry(A).

seq_central_take_on(S) :-
    in_sequence(A, S),
    central_take_on(A).

seq_central_backward_pass(S) :-
    in_sequence(A, S),
    central_backward_pass(A).

seq_flank_backward_carry(S) :-
    in_sequence(A, S),
    flank_backward_carry(A).

seq_flank_to_center_progression(S) :-
    in_sequence(A, S),
    flank_to_center_progression(A).

seq_central_switch(S) :-
    in_sequence(A, S),
    central_switch(A).

seq_recycle_to_same_flank(S) :-
    in_sequence(A, S),
    recycle_to_same_flank(A).

seq_center_cycling(S) :-
    in_sequence(A, S),
    center_cycling(A).

seq_persistent_half_space_occupier(S) :-
    persistent_half_space_occupier(_, S).

seq_open_support(S) :-
    seq_supported_action(S).

seq_flank_to_center(S) :-
    seq_flank_to_center_progression(S).

seq_no_open_support(S) :-
    in_sequence(A, S),
    no_open_support(A).

:- consult('facts_patterns.pl').
