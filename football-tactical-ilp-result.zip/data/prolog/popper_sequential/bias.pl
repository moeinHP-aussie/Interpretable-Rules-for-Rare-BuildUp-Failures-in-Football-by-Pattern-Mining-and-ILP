%% AUTO-GENERATED: hybrid ordered-pattern and revised tactical vocabulary.
%% Pattern components remain available; tautological pattern/component pairs are pruned.
head_pred(negative_outcome,1).
type(negative_outcome,(sequence,)).
direction(negative_outcome,(in,)).

body_pred(seq_line_breaking_pass,1).
type(seq_line_breaking_pass,(sequence,)).
direction(seq_line_breaking_pass,(in,)).
body_pred(seq_diagonal_pass,1).
type(seq_diagonal_pass,(sequence,)).
direction(seq_diagonal_pass,(in,)).
body_pred(seq_switch_to_right,1).
type(seq_switch_to_right,(sequence,)).
direction(seq_switch_to_right,(in,)).
body_pred(seq_switch_to_left,1).
type(seq_switch_to_left,(sequence,)).
direction(seq_switch_to_left,(in,)).
body_pred(seq_aerial_pass,1).
type(seq_aerial_pass,(sequence,)).
direction(seq_aerial_pass,(in,)).
body_pred(seq_long_pass,1).
type(seq_long_pass,(sequence,)).
direction(seq_long_pass,(in,)).
body_pred(seq_pass_in_behind,1).
type(seq_pass_in_behind,(sequence,)).
direction(seq_pass_in_behind,(in,)).
body_pred(seq_line_pass,1).
type(seq_line_pass,(sequence,)).
direction(seq_line_pass,(in,)).
body_pred(seq_connecting_pass,1).
type(seq_connecting_pass,(sequence,)).
direction(seq_connecting_pass,(in,)).
body_pred(seq_dropped_between_lines,1).
type(seq_dropped_between_lines,(sequence,)).
direction(seq_dropped_between_lines,(in,)).
body_pred(seq_first_time_play,1).
type(seq_first_time_play,(sequence,)).
direction(seq_first_time_play,(in,)).
body_pred(seq_dwelt_long,1).
type(seq_dwelt_long,(sequence,)).
direction(seq_dwelt_long,(in,)).
body_pred(seq_supported_action,1).
type(seq_supported_action,(sequence,)).
direction(seq_supported_action,(in,)).
body_pred(seq_dead_end_support,1).
type(seq_dead_end_support,(sequence,)).
direction(seq_dead_end_support,(in,)).
body_pred(seq_triangulation_opponent_trapped,1).
type(seq_triangulation_opponent_trapped,(sequence,)).
direction(seq_triangulation_opponent_trapped,(in,)).
body_pred(seq_rondo_cage,1).
type(seq_rondo_cage,(sequence,)).
direction(seq_rondo_cage,(in,)).
body_pred(seq_press_resistance,1).
type(seq_press_resistance,(sequence,)).
direction(seq_press_resistance,(in,)).
body_pred(seq_counter_pressed,1).
type(seq_counter_pressed,(sequence,)).
direction(seq_counter_pressed,(in,)).
body_pred(seq_rest_defence_exposed,1).
type(seq_rest_defence_exposed,(sequence,)).
direction(seq_rest_defence_exposed,(in,)).
body_pred(seq_under_pressure,1).
type(seq_under_pressure,(sequence,)).
direction(seq_under_pressure,(in,)).
body_pred(seq_flank_line_carry,1).
type(seq_flank_line_carry,(sequence,)).
direction(seq_flank_line_carry,(in,)).
body_pred(seq_flank_cut_inside,1).
type(seq_flank_cut_inside,(sequence,)).
direction(seq_flank_cut_inside,(in,)).
body_pred(seq_flank_dribble,1).
type(seq_flank_dribble,(sequence,)).
direction(seq_flank_dribble,(in,)).
body_pred(seq_central_long_carry,1).
type(seq_central_long_carry,(sequence,)).
direction(seq_central_long_carry,(in,)).
body_pred(seq_central_take_on,1).
type(seq_central_take_on,(sequence,)).
direction(seq_central_take_on,(in,)).
body_pred(seq_central_backward_pass,1).
type(seq_central_backward_pass,(sequence,)).
direction(seq_central_backward_pass,(in,)).
body_pred(seq_flank_backward_carry,1).
type(seq_flank_backward_carry,(sequence,)).
direction(seq_flank_backward_carry,(in,)).
body_pred(seq_central_switch,1).
type(seq_central_switch,(sequence,)).
direction(seq_central_switch,(in,)).
body_pred(seq_recycle_to_same_flank,1).
type(seq_recycle_to_same_flank,(sequence,)).
direction(seq_recycle_to_same_flank,(in,)).
body_pred(seq_center_cycling,1).
type(seq_center_cycling,(sequence,)).
direction(seq_center_cycling,(in,)).
body_pred(seq_persistent_half_space_occupier,1).
type(seq_persistent_half_space_occupier,(sequence,)).
direction(seq_persistent_half_space_occupier,(in,)).
body_pred(opponent_visible_majority,1).
type(opponent_visible_majority,(sequence,)).
direction(opponent_visible_majority,(in,)).
body_pred(slow_sequence,1).
type(slow_sequence,(sequence,)).
direction(slow_sequence,(in,)).
body_pred(fast_sequence,1).
type(fast_sequence,(sequence,)).
direction(fast_sequence,(in,)).
body_pred(keeper_played_open_play,1).
type(keeper_played_open_play,(sequence,)).
direction(keeper_played_open_play,(in,)).
body_pred(seq_pass_exchange,1).
type(seq_pass_exchange,(sequence,)).
direction(seq_pass_exchange,(in,)).
body_pred(seq_flank_to_center,1).
type(seq_flank_to_center,(sequence,)).
direction(seq_flank_to_center,(in,)).
body_pred(seq_pattern_01,1).
type(seq_pattern_01,(sequence,)).
direction(seq_pattern_01,(in,)).
body_pred(seq_pattern_02,1).
type(seq_pattern_02,(sequence,)).
direction(seq_pattern_02,(in,)).
body_pred(seq_pattern_03,1).
type(seq_pattern_03,(sequence,)).
direction(seq_pattern_03,(in,)).
body_pred(seq_pattern_04,1).
type(seq_pattern_04,(sequence,)).
direction(seq_pattern_04,(in,)).
body_pred(seq_pattern_05,1).
type(seq_pattern_05,(sequence,)).
direction(seq_pattern_05,(in,)).

%% Definite same-clause mutual exclusions.
:- body_literal(C,seq_rondo_cage,1,_), body_literal(C,seq_triangulation_opponent_trapped,1,_).
:- body_literal(C,seq_flank_dribble,1,_), body_literal(C,seq_flank_line_carry,1,_).
:- body_literal(C,seq_flank_dribble,1,_), body_literal(C,seq_flank_cut_inside,1,_).

%% Anti-tautology: do not conjoin a pattern with its own components.
:- body_literal(C,seq_pattern_01,1,_), body_literal(C,seq_diagonal_pass,1,_).
:- body_literal(C,seq_pattern_01,1,_), body_literal(C,seq_flank_dribble,1,_).
:- body_literal(C,seq_pattern_01,1,_), body_literal(C,seq_rest_defence_exposed,1,_).
:- body_literal(C,seq_pattern_02,1,_), body_literal(C,seq_diagonal_pass,1,_).
:- body_literal(C,seq_pattern_02,1,_), body_literal(C,seq_rest_defence_exposed,1,_).
:- body_literal(C,seq_pattern_02,1,_), body_literal(C,seq_supported_action,1,_).
:- body_literal(C,seq_pattern_03,1,_), body_literal(C,seq_dropped_between_lines,1,_).
:- body_literal(C,seq_pattern_03,1,_), body_literal(C,seq_rest_defence_exposed,1,_).
:- body_literal(C,seq_pattern_04,1,_), body_literal(C,seq_rest_defence_exposed,1,_).
:- body_literal(C,seq_pattern_04,1,_), body_literal(C,seq_triangulation_opponent_trapped,1,_).
:- body_literal(C,seq_pattern_05,1,_), body_literal(C,seq_dead_end_support,1,_).
:- body_literal(C,seq_pattern_05,1,_), body_literal(C,seq_rest_defence_exposed,1,_).

max_vars(2).
max_body(3).
max_clauses(4).
