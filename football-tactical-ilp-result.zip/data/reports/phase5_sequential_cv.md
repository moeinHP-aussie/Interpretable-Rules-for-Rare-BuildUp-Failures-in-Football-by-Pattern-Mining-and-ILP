# Hybrid ordered-pattern match-grouped CV

Fold-local ordered combinations of action-level tactical predicates were mined from training matches. Each complete pattern is one atomic Popper feature. Its component action predicates are removed from the standalone vocabulary for this method; other tactical features remain available.

- Folds: 3; seed: `202021`; Popper timeout/fold: 600 s.
- Held-out sequences: 1881; base rate: 0.117.
- Predicted support: 183 (TP=47, FP=136); precision: 0.257; recall: 0.213; lift: 2.186.
- Metrics pool all held-out matches across folds. Pattern mining and selection use training matches only; Popper training uses the project's context-matched sample.
- Pattern events come from the 31 currently active action-level concepts; sequence summaries, player summaries, and absence complements are not treated as ordered events.
- This estimates internal match-grouped performance, not cross-season generalization.

## Fold details

| Fold | Patterns selected | Predicates offered | Popper seconds | Provisional | Hard timeout | Support | Precision | Recall | Lift |
|---:|---:|---:|---:|:---:|:---:|---:|---:|---:|---:|
| 1 | 6 | 43 | 53.4 | False | False | 78 | 0.192 | 0.214 | 1.755 |
| 2 | 4 | 41 | 88.4 | False | False | 58 | 0.345 | 0.230 | 2.802 |
| 3 | 3 | 40 | 89.3 | False | False | 47 | 0.255 | 0.188 | 2.134 |

## Selected fold-local patterns

### Fold 1

- `seq_pattern_01`: `{tactical:rest_defence_exposed@pass@central_channel@middle_third} -> {tactical:dropped_between_lines@dribble@central_channel@middle_third}`; target support 6, control support 2, context-adjusted growth 3.264.
- `seq_pattern_02`: `{tactical:line_pass@throw_in@left_wing@defensive_third} -> {tactical:flank_dribble@dribble@left_wing@defensive_third} -> {tactical:supported_action@pass@left_wing@defensive_third}`; target support 5, control support 2, context-adjusted growth 3.144.
- `seq_pattern_03`: `{tactical:line_pass@throw_in@left_wing@defensive_third} -> {tactical:triangulation_opponent_trapped@dribble@left_wing@defensive_third}`; target support 5, control support 2, context-adjusted growth 3.093.
- `seq_pattern_04`: `{tactical:flank_dribble@dribble@right_wing@defensive_third} -> {tactical:first_time_play@pass@right_wing@defensive_third} -> {tactical:flank_dribble@dribble@right_wing@defensive_third}`; target support 7, control support 7, context-adjusted growth 3.058.
- `seq_pattern_05`: `{tactical:under_pressure@pass@right_wing@defensive_third} -> {tactical:first_time_play@pass@right_wing@defensive_third} -> {tactical:flank_dribble@dribble@right_wing@defensive_third}`; target support 5, control support 3, context-adjusted growth 3.037.
- `seq_pattern_06`: `{tactical:connecting_pass@pass@right_wing@defensive_third} -> {tactical:first_time_play@pass@right_wing@defensive_third} -> {tactical:flank_dribble@dribble@right_wing@defensive_third}`; target support 5, control support 4, context-adjusted growth 3.025.

### Fold 2

- `seq_pattern_01`: `{tactical:rest_defence_exposed@pass@central_channel@defensive_third} -> {tactical:rest_defence_exposed@dribble@left_half_space@defensive_third} -> {tactical:flank_dribble@dribble@left_wing@defensive_third}`; target support 10, control support 7, context-adjusted growth 3.669.
- `seq_pattern_02`: `{tactical:rest_defence_exposed@pass@central_channel@defensive_third} -> {tactical:diagonal_pass@pass@left_half_space@defensive_third} -> {tactical:flank_dribble@dribble@left_wing@defensive_third}`; target support 7, control support 1, context-adjusted growth 3.640.
- `seq_pattern_03`: `{tactical:rest_defence_exposed@pass@central_channel@defensive_third} -> {tactical:diagonal_pass@pass@left_half_space@defensive_third} -> {tactical:supported_action@dribble@left_wing@defensive_third}`; target support 7, control support 1, context-adjusted growth 3.640.
- `seq_pattern_04`: `{tactical:central_long_carry@dribble@left_half_space@defensive_third} -> {tactical:diagonal_pass@pass@left_half_space@defensive_third} -> {tactical:flank_dribble@dribble@left_wing@defensive_third}`; target support 6, control support 0, context-adjusted growth 3.595.

### Fold 3

- `seq_pattern_01`: `{tactical:triangulation_opponent_trapped@pass@central_channel@defensive_third} -> {tactical:rest_defence_exposed@dribble@left_wing@defensive_third}`; target support 7, control support 4, context-adjusted growth 3.770.
- `seq_pattern_02`: `{tactical:dead_end_support@pass@central_channel@defensive_third} -> {tactical:supported_action@pass@left_half_space@defensive_third}`; target support 5, control support 3, context-adjusted growth 3.747.
- `seq_pattern_03`: `{tactical:under_pressure@pass@right_half_space@defensive_third} -> {tactical:central_switch@pass@central_channel@defensive_third} -> {tactical:rest_defence_exposed@dribble@left_wing@defensive_third}`; target support 5, control support 2, context-adjusted growth 3.632.


## Exploratory intermediate Popper candidates

Exploratory only: many incumbent hypotheses were inspected and these same fold holdouts were used to rank them. Metrics are pooled only over folds where that candidate was discovered; do not treat them as an unbiased estimate. Confirm shortlisted candidates on new matches or a nested/fresh evaluation.

| Folds found | Holdout support* | Precision* | Recall* | Lift* | Program |
|---:|---:|---:|---:|---:|---|
| 2/3 | 9 | 0.222 | 0.013 | 1.905 | `seq_pattern_02` |
| 1/3 | 46 | 0.370 | 0.195 | 3.003 | `fast_sequence, seq_connecting_pass` |
| 1/3 | 58 | 0.345 | 0.230 | 2.802 | `seq_pattern_01`<br>`fast_sequence, seq_connecting_pass` |
| 1/3 | 27 | 0.296 | 0.125 | 2.477 | `seq_pattern_03`<br>`seq_pattern_02`<br>`seq_first_time_play, fast_sequence` |
| 1/3 | 47 | 0.255 | 0.188 | 2.134 | `seq_pattern_03`<br>`seq_pattern_02`<br>`seq_first_time_play, fast_sequence, seq_supported_action` |
| 1/3 | 4 | 0.250 | 0.016 | 2.090 | `seq_pattern_01`<br>`seq_pattern_03` |
| 1/3 | 4 | 0.250 | 0.016 | 2.090 | `seq_pattern_03`<br>`seq_pattern_02` |
| 1/3 | 12 | 0.250 | 0.034 | 2.032 | `seq_pattern_01` |
| 1/3 | 73 | 0.205 | 0.214 | 1.876 | `fast_sequence, seq_dead_end_support` |
| 1/3 | 78 | 0.192 | 0.214 | 1.755 | `seq_pattern_01`<br>`seq_pattern_02`<br>`fast_sequence, seq_dead_end_support`<br>`seq_pattern_04, seq_pass_exchange` |
| 1/3 | 5 | 0.000 | 0.000 | 0.000 | `seq_pattern_02`<br>`seq_pattern_01`<br>`seq_pattern_04` |
| 1/3 | 3 | 0.000 | 0.000 | 0.000 | `seq_pattern_03` |

*Candidate scores pool only folds where the candidate was discovered; use as a discovery shortlist, not a performance estimate.

### Individual clauses found inside intermediate hypotheses

| Folds found | Holdout support* | Precision* | Recall* | Lift* | Clause |
|---:|---:|---:|---:|---:|---|
| 3/3 | 10 | 0.300 | 0.014 | 2.553 | `seq_pattern_02` |
| 3/3 | 16 | 0.250 | 0.018 | 2.128 | `seq_pattern_01` |
| 1/3 | 46 | 0.370 | 0.195 | 3.003 | `fast_sequence, seq_connecting_pass` |
| 1/3 | 23 | 0.304 | 0.109 | 2.544 | `seq_first_time_play, fast_sequence` |
| 1/3 | 43 | 0.256 | 0.172 | 2.138 | `seq_first_time_play, fast_sequence, seq_supported_action` |
| 1/3 | 73 | 0.205 | 0.214 | 1.876 | `fast_sequence, seq_dead_end_support` |
| 1/3 | 3 | 0.000 | 0.000 | 0.000 | `seq_pattern_03` |
| 1/3 | 1 | 0.000 | 0.000 | 0.000 | `seq_pattern_04, seq_pass_exchange` |
| 1/3 | 1 | 0.000 | 0.000 | 0.000 | `seq_pattern_04` |
