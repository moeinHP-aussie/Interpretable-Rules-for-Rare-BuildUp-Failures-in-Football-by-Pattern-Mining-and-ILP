# تحلیل توصیفی اکشنِ مرتبط با لو دادن توپ

این گزارش پس از کشف قانون‌ها ساخته می‌شود و هیچ ویژگیِ اکشنِ لو دادن توپ را به ورودی Popper اضافه نمی‌کند. هر قانون فقط روی سکانس‌های منفیِ فولدِ نگه‌داشته‌شدهٔ خودش اعمال شده است. در باخت مستقیم، اکشن ناموفقِ خودی شمرده می‌شود؛ اگر ابتدا حریف مالکیت را گرفته باشد، آخرین اکشن خودی پیش از اکشنِ دریافت/مالکیت حریف شمرده می‌شود.

دستهٔ نوع اکشن برای هر سکانس فقط یک‌بار شمرده می‌شود. برچسب‌های پاس (جهت، طول، قطری‌بودن، تلاش خط‌شکنی و پاس خط‌شکن موفق) هم‌پوشان‌اند و جمع آن‌ها می‌تواند از تعداد پاس‌ها بیشتر شود. تلاش خط‌شکنی از هندسهٔ اکشن و خط تخمینی در فریم ۳۶۰ می‌آید؛ فقط تلاش موفق با نتیجهٔ موفق پاس در برچسب successful_line_break_proxy می‌آید.

| فولد / قانون | قانون کشف‌شده | پوشش منفی | اکشن مرتبط ناموجود | اکشن خودیِ مرتبط (انحصاری) | رخداد ثبت‌شدهٔ turnover | برچسب‌های توصیفی پاس (هم‌پوشان) |
|---|---|---:|---:|---|---|---|
| full_tactical / 1 / 1 | `seq_dead_end_support, fast_sequence` | 8 | 0 | dribble: 3; pass: 3; take_on: 2 | failed_own_action:pass: 3; failed_own_action:take_on: 2; opponent_acquisition:tackle: 3 | direction:forward: 2; direction:sideways: 1; length:short: 3; result:fail: 5; result:success: 3 |
| full_tactical / 2 / 1 | `seq_connecting_pass, fast_sequence` | 11 | 0 | dribble: 1; pass: 8; take_on: 2 | failed_own_action:pass: 8; failed_own_action:take_on: 2; opponent_acquisition:tackle: 1 | diagonal: 2; direction:backward: 1; direction:forward: 7; length:long: 4; length:medium: 2; length:short: 2; result:fail: 10; result:success: 1 |
| full_tactical / 3 / 1 | `seq_first_time_play, fast_sequence, seq_supported_action` | 5 | 0 | bad_touch: 1; pass: 3; take_on: 1 | failed_own_action:bad_touch: 1; failed_own_action:pass: 3; failed_own_action:take_on: 1 | diagonal: 1; direction:forward: 3; length:long: 2; length:short: 1; result:fail: 5 |
| hybrid_sequential / 1 / 1 | `seq_pattern_01` | 0 | 0 | — | — | — |
| hybrid_sequential / 1 / 2 | `seq_pattern_02` | 0 | 0 | — | — | — |
| hybrid_sequential / 1 / 3 | `fast_sequence, seq_dead_end_support` | 8 | 0 | dribble: 3; pass: 3; take_on: 2 | failed_own_action:pass: 3; failed_own_action:take_on: 2; opponent_acquisition:tackle: 3 | direction:forward: 2; direction:sideways: 1; length:short: 3; result:fail: 5; result:success: 3 |
| hybrid_sequential / 1 / 4 | `seq_pattern_04, seq_pass_exchange` | 0 | 0 | — | — | — |
| hybrid_sequential / 2 / 1 | `seq_pattern_01` | 3 | 0 | pass: 2; take_on: 1 | failed_own_action:pass: 2; failed_own_action:take_on: 1 | direction:forward: 2; length:long: 1; length:short: 1; result:fail: 3 |
| hybrid_sequential / 2 / 2 | `fast_sequence, seq_connecting_pass` | 11 | 0 | dribble: 1; pass: 8; take_on: 2 | failed_own_action:pass: 8; failed_own_action:take_on: 2; opponent_acquisition:tackle: 1 | diagonal: 2; direction:backward: 1; direction:forward: 7; length:long: 4; length:medium: 2; length:short: 2; result:fail: 10; result:success: 1 |
| hybrid_sequential / 3 / 1 | `seq_pattern_03` | 0 | 0 | — | — | — |
| hybrid_sequential / 3 / 2 | `seq_pattern_02` | 1 | 0 | pass: 1 | failed_own_action:pass: 1 | direction:forward: 1; length:short: 1; result:fail: 1 |
| hybrid_sequential / 3 / 3 | `seq_first_time_play, fast_sequence, seq_supported_action` | 5 | 0 | bad_touch: 1; pass: 3; take_on: 1 | failed_own_action:bad_touch: 1; failed_own_action:pass: 3; failed_own_action:take_on: 1 | diagonal: 1; direction:forward: 3; length:long: 2; length:short: 1; result:fail: 5 |

## محدودیت تفسیر

این یک توصیف از آخرین اکشن خودیِ مرتبط با turnover در سکانس‌های برچسب‌خوردهٔ منفی است؛ نه برآورد علّی و نه اثبات اینکه قانون یا اکشن باعث ازدست‌رفتن توپ شده است. تعریف مرز سکانس، اتصال اکشن حریف به رخداد باخت و ثبت ناقص رویدادها در StatsBomb بر نتیجه اثر می‌گذارند. قانون‌های فولدهای مختلف نیز ممکن است یک سکانس یا مفهوم را به شکل متفاوتی پوشش دهند.
