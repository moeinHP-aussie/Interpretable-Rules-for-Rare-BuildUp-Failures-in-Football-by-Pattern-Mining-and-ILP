# مقایسهٔ دو بازوی فاز ۵

| بازو | نتیجه | منبع |
|---|---|---|
| `full_tactical` | No stable tactical program found (MDL prune / NO SOLUTION) | `phase5_cross_validation.json` |
| `hybrid_sequential` | 4-clause sequential program (OOF Precision: 26%, OOF Lift: 2.19x) | `phase5_sequential_cv.json` |

