# Neuro-Symbolic Tactical Analysis — FC Barcelona Build-up (MVP)

کشف الگوهای رفتاری تکرارشونده و ناخودآگاه در فاز بازیسازی (Build-up) با
ترکیب یک لایه استخراج ویژگی قاعده‌محور و یک موتور **Inductive Logic
Programming** (Popper).

* **دیتاست:** StatsBomb Open Data — La Liga 2020/21، FC Barcelona
  (`competition_id=11`, `season_id=90`)، ۳۵ بازی، همگی با داده ۳۶۰
* **زنجیره:** StatsBomb → SPADL → سکانس Build-up → Prolog Facts → Popper → گزارش مربی
* **وضعیت:** فازهای ۰ تا ۵ کامل. فاز ۵ (اجرای واقعی Popper) روی Colab اجرا و
  بازبینی شد — در بازبینی **سه ایراد روش‌شناختی جدی** پیدا و اصلاح شد (نشت
  هدف، یک body predicate کاملاً مرده، و نبود Hold-out). جزئیات کامل در
  `docs/phase5_review_findings.md`. پس از اصلاح، یک قانون واقعی و
  قابل‌تعمیم روی داده‌ی دیده‌نشده پیدا شد (lift = ۱.۶۳). **۲۰۱ تست سبز.**

> داده از StatsBomb Open Data است. هنگام انتشار هر نتیجه‌ای، منبع را ذکر کنید.

---

## اجرای سریع

```bash
uv sync --extra dev
uv run python scripts/run_phase0_check.py     # چک محیط
uv run python scripts/run_phase1.py           # دانلود + SPADL + 360  (اجرای اول: ۱۰-۲۵ دقیقه)
uv run python scripts/run_phase2.py           # سکانس + برچسب + نمونه‌گیری
uv run python scripts/run_phase3.py           # تولید Prolog facts
uv run python scripts/run_phase4_precheck.py  # تخمین حجم fact پیش از فاز ۴
uv run python scripts/run_phase4.py           # قوانین تاکتیکی bk.pl
uv run python scripts/run_phase5.py           # فایل‌های ورودی Popper (bias.pl, exs.pl, exs_holdout.pl)
uv run pytest -m "not network"                # ۲۰۱ تست
```

اجرای واقعی Popper (نیاز به SWI-Prolog ≥ 9.1.12؛ روی Colab آماده است):

```bash
uv run --project /path/to/Popper popper.py data/prolog/popper --noisy --timeout 240
uv run python scripts/run_phase5_eval.py --rule "seq_dropped_between_lines,not_seq_dwelt_long,seq_dead_end_support"
```

> **نکته:** پوشه `data/raw/` (کش خام دانلود StatsBomb، ~۷۰ مگابایت) عمداً از
> این پکیج حذف شده چون کاملاً با `run_phase1.py` بازتولید می‌شود. تا وقتی
> این کش نسازید، ۶ تست وابسته به آن (نه هیچ‌کدام از تست‌های فاز ۲ یا ۳)
> به‌جای Fail خوردن، `SKIPPED` نشان داده می‌شوند — این طبیعی است.

**ویندوز:** راهنمای کامل گام‌به‌گام در [`docs/SETUP_WINDOWS.md`](docs/SETUP_WINDOWS.md).

**اگر اینترنت/حجم دیسک محدود دارید:** به‌جای نصب لوکال، از
[`football_tactical_ilp_colab_setup.ipynb`](football_tactical_ilp_colab_setup.ipynb)
روی Google Colab استفاده کنید — هیچ نصبی روی سیستم خودتان انجام نمی‌شود.
راهنما: [`docs/COLAB_GUIDE.md`](docs/COLAB_GUIDE.md). **تست‌شده روی Colab ✅**

> **چرا این گزینه لازم شد؟** Popper به `janus_swi` نیاز دارد، و `janus_swi`
> روی PyPI برای ویندوز فقط تا Python 3.13 wheel آماده دارد، در حالی که Popper
> صراحتاً Python ≥ 3.14 می‌خواهد. نتیجه: روی ویندوز باید از سورس build شود که
> به یک کامپایلر C (Visual Studio Build Tools) نیاز دارد. روی Colab (لینوکس)
> این کامپایلر از قبل نصب است.

---

## پیش‌نیازها

| ابزار | نسخه | چرا |
|---|---|---|
| Python | ۳.۱۱ یا ۳.۱۲ | `socceraction` روی ۳.۱۳+ کار نمی‌کند |
| uv | هر نسخه اخیر | مدیریت پکیج و محیط |
| SWI-Prolog | **≥ ۹.۱.۱۲** | `janus_swi` (وابسته Popper) نسخه پایین‌تر را رد می‌کند |
| Popper | 5.x | موتور ILP — در محیط پایتون ۳.۱۴ **مجزای خودش** اجرا می‌شود |

---

## خروجی اصلی

### نتیجه فاز ۵ — یک قانون تاکتیکی واقعی، تست‌شده روی داده دیده‌نشده

```prolog
negative_outcome(S) :-
    seq_dropped_between_lines(S),   % حامل توپ بین دو خط حریف افتاده
    not_seq_dwelt_long(S),          % توپ را سریع واگذار کرده (معطل نکرده)
    seq_dead_end_support(S).        % گیرنده گزینه پیشرو نداشته
```

| مجموعه | نرخ پایه | دقت | بازیابی | **lift** |
|---|---|---|---|---|
| train (۲۶ بازی) | ۰.۳۲ | ۰.۶۷ | ۰.۳۵ | ۲.۰۸ |
| **holdout (۹ بازی، هرگز دیده‌نشده)** | ۰.۳۶ | ۰.۵۸ | ۰.۳۳ | **۱.۶۳** |

یعنی این الگو احتمال پیامد منفی را حدود ۱.۶ برابر افزایش می‌دهد — و این روی
بازی‌هایی که مدل هرگز آموزش ندیده هم برقرار می‌ماند. جزئیات کامل و مسیر
رسیدن به این قانون (شامل سه ایراد جدی که در بازبینی پیدا و اصلاح شد) در
[`docs/phase5_review_findings.md`](docs/phase5_review_findings.md).

### فایل‌های داده تولیدشده

```
data/prolog/facts_all.pl               96,609 fact هندسی/زمینه‌ای (فاز ۳)
data/prolog/facts_tactical.pl          25,988 fact تاکتیکی (فاز ۴)
data/prolog/bk.pl                      قوانین دست‌نویس Prolog (فاز ۴)
data/prolog/popper/
    bias.pl                            ۳۴ body predicate (شامل ۵ مکمل نفی‌شده)
    bk.pl                              لفاف consult نسبی + wrapper سکانسی
    exs.pl                             ۱۰۰ مثال مثبت + ۲۰۹ منفی (train، هم‌زمینه)
    exs_holdout.pl                     ۴۳ مثبت + ۷۷ منفی (۹ بازی کنارگذاشته‌شده)
```

نمونه واقعی از factهای فاز ۳ (سکانس `s_3773377_0002`، برچسب منفی — عیناً از
`facts_all.pl`):

```prolog
sequence(s_3773377_0002).
sequence_label(s_3773377_0002,negative).
sequence_length(s_3773377_0002,5).

actor(a_3773377_00326,p_5203).
action_type(a_3773377_00326,dribble).
at_third(a_3773377_00326,defensive_third).
under_pressure(a_3773377_00326).
pressure_level(a_3773377_00326,light_pressure).
pass_direction(a_3773377_00326,backward).

passes_to(p_30486,p_43728,s_3773377_0002).
passes_to(p_43728,p_5211,s_3773377_0002).
passes_to(p_5211,p_5203,s_3773377_0002).
```

**مهم:** هر predicate در `facts_all.pl` و `facts_tactical.pl` یک **Fact ثابت
از پیش محاسبه‌شده** است، نه یک rule زنده Prolog — هندسه در پایتون محاسبه و
اینجا فریز می‌شود. قوانین زنده Prolog فقط در `bk.pl` (فاز ۴) هستند.

---

## چارچوب مرجع

کل پروژه در یک چارچوب واحد کار می‌کند:

```
x ∈ [0, 105]   x=0 دروازه بارسا،  x=105 دروازه حریف   (بارسا همیشه به +x حمله می‌کند)
y ∈ [0, 68]    y=0 خط طولی سمت راست از دید جهت حمله بارسا
```

اکشن‌های حریف هم به همین چارچوب آینه می‌شوند.

---

## مستندات

| سند | محتوا |
|---|---|
| [`report.md`](report.md) | گزارش کامل کارهای انجام‌شده، تصمیم‌ها، مشکلات و انحراف‌ها |
| [`docs/SETUP_WINDOWS.md`](docs/SETUP_WINDOWS.md) | نصب و تست روی ویندوز |
| [`docs/COLAB_GUIDE.md`](docs/COLAB_GUIDE.md) | نصب و اجرا روی Google Colab (بدون نیاز به نصب لوکال) |
| [`docs/negative_outcome_definition.md`](docs/negative_outcome_definition.md) | تعریف عملیاتی «پیامد منفی» (تسک ۲.۲) |
| [`docs/negative_sampling_strategy.md`](docs/negative_sampling_strategy.md) | استراتژی نمونه‌گیری منفی (تسک ۲.۴) |
| [`docs/tactical_concepts_glossary.md`](docs/tactical_concepts_glossary.md) | واژه‌نامه جامع ۷۱ مفهوم تاکتیکی (نسخه ۳، تأییدشده) |
| [`docs/phase4_precheck_findings.md`](docs/phase4_precheck_findings.md) | تخمین حجم fact پیش از نوشتن Prolog فاز ۴ |
| [`docs/phase4_concept_disposition.md`](docs/phase4_concept_disposition.md) | تصمیم نهایی برای هرکدام از ۷۱ مفهوم (ساخته شد / رد شد / چرا) |
| [`docs/phase5_review_findings.md`](docs/phase5_review_findings.md) | **بازبینی فاز ۵ — سه ایراد جدی پیدا و اصلاح شد (نشت هدف، predicate مرده، نبود hold-out)** |
