"""
Phase 4 — dump the tactical concepts as ground Prolog facts.

This sits next to :mod:`tactical_ilp.prolog.prolog_facts` (phase 3) and follows
exactly the same contract: **everything written here is a pre-computed ground
fact**, never a live rule.  The rules live in ``bk.pl``.

Predicates produced
-------------------
concept 3.6a  forms_triangle/1, n_triangles/2, triangle_shape/2
concept 3.6b  traps_opponent/1, caged_opponent/1
concept 1.1   breaks_defensive_line/1, breaks_midfield_line/1
concept 1.5   beyond_defensive_line/1
concept 6.1   hesitation/1
concept 6.2   tempo/2
concept 6.3   one_touch/1
concept 6.4   dwell_time/2  (discretised, not raw seconds)
concept 3.4   frequently_involved/2
concept 1.2   diagonal_pass_shape/1
concept 1.3   switch_shape/1

Concept 0.1 (line clustering) is used by 1.1/1.5 but is deliberately **not**
dumped -- it is an internal helper of this stage, see the architectural note in
``features/geometry.py``.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from tactical_ilp.config import (
    HALF_SPACE_MIN_TOUCHES,
    PASSING_OPTIONS_FEW_MAX,
    PASSING_OPTIONS_MANY_MIN,
    PROLOG_DIR,
)
from tactical_ilp.data.freeze_frames import build_all as build_merged_all
from tactical_ilp.features.frames import actor_point, frame_points, opponents, teammates
from tactical_ilp.features.geometry import (
    defensive_line_x,
    is_diagonal_pass,
    is_switch_of_play,
    lane_of,
    midfield_line_x,
    pressure_level,
)
from tactical_ilp.features.tactical import (
    frequently_involved,
    is_hesitation,
    is_one_touch,
    line_summary,
    open_supporters,
    tempo_bucket,
    triangulation_summary,
)
from tactical_ilp.sequences.negative_sampling import build_context
from tactical_ilp.sequences.sequence_builder import build_all as build_sequences

PASS_LIKE = {
    "pass",
    "cross",
    "freekick_short",
    "goalkick",
    "throw_in",
    "corner_short",
}

PHASE4_FACTS_PATH = PROLOG_DIR / "facts_tactical.pl"
PHASE4_MANIFEST_PATH = PROLOG_DIR / "facts_tactical_manifest.json"

HEADER = """\
%% ===================================================================
%%  AUTO-GENERATED - DO NOT EDIT BY HAND
%%  Phase 4 - tactical concept facts
%%
%%  !! PRE-COMPUTED GROUND FACTS, not Prolog rules.
%%  !! Produced by tactical_ilp.features.tactical from StatsBomb 360
%%  !! freeze frames.  The tactical *rules* live in bk.pl.
%%
%%  Data limit that shapes every predicate here: non-actor players in a
%%  360 frame have NO player_id - only (x, y, teammate, keeper).  So all
%%  opponent-related concepts are positional proxies, never identities.
%%
%%  Reference frame: Barcelona always attacks towards +x.
%% ===================================================================

"""


def _action_atom(match_id: int, action_id: int) -> str:
    return f"a_{int(match_id)}_{int(action_id):05d}"


def _player_atom(player_id) -> str:
    return f"p_{int(player_id)}"


def _shape_bucket(area: float) -> str:
    """Discrete triangle size -- never dump the raw float (Popper cannot
    generalise over ~30k distinct constants)."""
    if area < 20.0:
        return "tight"
    if area < 50.0:
        return "medium"
    return "wide"


def _dwell_bucket(seconds: float | None) -> str | None:
    """Concept 6.4 -- time on the ball, discretised."""
    if seconds is None:
        return None
    try:
        s = float(seconds)
    except (TypeError, ValueError):
        return None
    if s != s or s < 0:
        return None
    if s <= 1.0:
        return "instant"
    if s <= 2.5:
        return "normal"
    return "long"


class FactWriter:
    """Same grouping writer as phase 3, kept local to avoid a circular import."""

    def __init__(self) -> None:
        self.groups: dict[str, list[str]] = {}
        self.order: list[str] = []

    def add(self, predicate: str, *args) -> None:
        if predicate not in self.groups:
            self.groups[predicate] = []
            self.order.append(predicate)
        body = ",".join(str(a) for a in args)
        self.groups[predicate].append(f"{predicate}({body})." if args else f"{predicate}.")

    def counts(self) -> dict[str, int]:
        return {k: len(v) for k, v in self.groups.items()}

    def write(self, path: Path, title: str = "") -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fh:
            fh.write(HEADER)
            if title:
                fh.write(f"%% {title}\n\n")
            for pred in self.order:
                lines = sorted(set(self.groups[pred]))
                arity = lines[0].count("(") and lines[0][:-1].split("(", 1)[1].count(",") + 1
                fh.write(f"%% ---- {pred}/{arity}  ({len(lines)} facts)\n")
                fh.write("\n".join(lines))
                fh.write("\n\n")
        return path


def generate_tactical_facts(
    match_ids: list[int] | None = None, out_path: Path | None = None
):
    """Build the phase-4 fact file for the given matches (all by default)."""
    context = build_context()
    _, members = build_sequences()
    merged = build_merged_all()

    if match_ids is not None:
        keep = {int(m) for m in match_ids}
        context = context[context.match_id.isin(keep)]
        members = members[members.match_id.isin(keep)]
        merged = merged[merged.match_id.isin(keep)]

    seq_ids = set(context.sequence_id)
    members = members[members.sequence_id.isin(seq_ids)]

    cols = [
        "player_id",
        "type_name",
        "result_name",
        "start_x",
        "start_y",
        "end_x",
        "end_y",
        "time_seconds",
        "original_event_id",
        "is_barca",
        "under_pressure",
        "counterpress",
        "ff_opponents_3m",
        "ff_opponents_5m",
        "has_freeze_frame",
    ]
    acts = merged.set_index(["match_id", "action_id"])
    mem = members.join(acts[cols], on=["match_id", "action_id"])
    mem = mem.sort_values(["sequence_id", "order_in_sequence"])

    # dwell time = gap to the next action of the same sequence (concept 6.1/6.3)
    mem["dwell_s"] = mem.groupby("sequence_id")["time_seconds"].diff().shift(-1)

    w = FactWriter()

    # ---------------- per-action concepts ---------------------------------
    for r in mem.itertuples():
        aa = _action_atom(r.match_id, r.action_id)
        pressure = pressure_level(
            r.ff_opponents_3m, r.ff_opponents_5m, bool(r.under_pressure)
        )

        # --- concept 6: rhythm / timing / decision making -----------------
        if is_hesitation(r.dwell_s, pressure):
            w.add("hesitation", aa)
        if is_one_touch(r.dwell_s):
            w.add("one_touch", aa)
        bucket = _dwell_bucket(r.dwell_s)
        if bucket:
            w.add("dwell_time", aa, bucket)

        # --- concept 1.2 / 1.3: two-axis pass shapes ----------------------
        if r.type_name in PASS_LIKE:
            if is_diagonal_pass(r.start_x, r.start_y, r.end_x, r.end_y):
                w.add("diagonal_pass_shape", aa)
            if is_switch_of_play(r.start_x, r.start_y, r.end_x, r.end_y):
                w.add("switch_shape", aa)

        # concept 8.3 — counter-press: StatsBomb's own flag, just dumped as a
        # fact.  Already computed upstream, never exposed before phase 4.
        if bool(getattr(r, "counterpress", False)):
            w.add("counterpress_action", aa)

        # concept 7.1 / 7.2 — successful defensive actions that start a
        # build-up sequence (tackle, interception).  These already exist as
        # action_type/2 in facts_all.pl; this predicate just names the
        # tactical concept explicitly rather than leaving it as a raw type.
        if r.type_name == "tackle" and r.result_name == "success":
            w.add("successful_tackle", aa)
        if r.type_name == "interception" and r.result_name == "success":
            w.add("successful_interception", aa)

        # concept 3.5 — layoff: a one-touch pass backwards or sideways by a
        # forward.  Approximated from role + touch time + direction, not
        # actual body orientation (which the data does not carry).
        if (
            r.type_name == "pass"
            and is_one_touch(r.dwell_s)
            and r.end_x is not None
            and r.start_x is not None
            and float(r.end_x) <= float(r.start_x) + 2.0
        ):
            w.add("layoff_candidate", aa)

        # --- frame-based concepts ----------------------------------------
        if not bool(r.has_freeze_frame) or not isinstance(r.original_event_id, str):
            continue
        points = frame_points(r.match_id, r.original_event_id, bool(r.is_barca))
        if not points:
            continue

        # concept 4.1 / 4.5 — support: open passing lanes, not distance.
        n_open = open_supporters(points)
        if n_open >= 1:
            w.add("has_open_support", aa)
        if n_open <= PASSING_OPTIONS_FEW_MAX:
            w.add("passing_options", aa, "few")
        elif n_open >= PASSING_OPTIONS_MANY_MIN:
            w.add("passing_options", aa, "many")
        else:
            w.add("passing_options", aa, "some")

        # concept 3.6a / 3.6b — triangulation
        tri = triangulation_summary(points)
        if tri["n_triangles"] > 0:
            w.add("forms_triangle", aa)
            w.add("n_triangles", aa, min(int(tri["n_triangles"]), 5))
            if tri["n_trapping"] > 0:
                w.add("traps_opponent", aa)
            if tri["multi_trap"]:
                w.add("caged_opponent", aa)

        # concepts 1.1 / 1.5 — opponent lines (built on the 0.1 helper)
        ln = line_summary(points, r.start_x, r.end_x)
        if ln["has_line"]:
            if ln["breaks_defensive_line"]:
                w.add("breaks_defensive_line", aa)
            if ln["breaks_midfield_line"]:
                w.add("breaks_midfield_line", aa)
            if ln["beyond_defensive_line"]:
                w.add("beyond_defensive_line", aa)

        # concept 9.1 / 9.1b — numeric superiority vs the defenders between
        # the ball and their goal.  A frame-coverage proxy: only opponents
        # actually visible in the 360 frame are counted, which the glossary
        # itself flags as a caveat (the frame does not always show all 22).
        carrier = actor_point(points)
        if carrier is not None:
            mates = teammates(points)
            opps = opponents(points)
            if bool(r.is_barca):
                mates_ahead = [m for m in mates if m.x >= carrier.x]
                defenders_between = [o for o in opps if o.x > carrier.x]
            else:
                mates_ahead = [m for m in mates if m.x <= carrier.x]
                defenders_between = [o for o in opps if o.x < carrier.x]
            attackers = len(mates_ahead) + 1
            if attackers > len(defenders_between):
                w.add("numeric_superiority", aa)

        # concept 2.3 — drop between the (opponent) lines: the actor himself
        # is positioned between the opponent defensive and midfield lines.
        # Also built on the 0.1 helper; only possible for the acting player
        # because only the actor carries a player_id in the frame.
        if bool(r.is_barca):
            opps_xs = [o.x for o in opponents(points, include_keeper=False)]
            carrier = actor_point(points)
            dline = defensive_line_x(opps_xs)
            mline = midfield_line_x(opps_xs)
            if carrier is not None and dline is not None and mline is not None:
                if dline < carrier.x < mline:
                    w.add("drop_between_lines", aa)

    # ---------------- per-sequence concepts -------------------------------
    grp = mem.groupby("sequence_id")
    for sid, g in grp:
        t0, t1 = g.time_seconds.min(), g.time_seconds.max()
        duration = (t1 - t0) if pd.notna(t1) and pd.notna(t0) else None
        bucket = tempo_bucket(len(g), duration)
        if bucket:
            w.add("tempo", sid, bucket)

        # concept 3.3 — rapid combination: at least 3 short passes among
        # different players inside a short overall time window.
        passes = g[g.type_name == "pass"]
        short_len = (
            ((passes["end_x"] - passes["start_x"]) ** 2
             + (passes["end_y"] - passes["start_y"]) ** 2) ** 0.5
        ) <= 15.0
        n_players = g.dropna(subset=["player_id"]).player_id.nunique()
        if (
            int(short_len.sum()) >= 3
            and n_players >= 3
            and duration is not None
            and duration <= 6.0
        ):
            w.add("rapid_combination", sid)

        # concept 3.4 — repeated involvement, boolean not raw count
        touches = g.dropna(subset=["player_id"]).groupby("player_id").size()
        for pid, n in touches.items():
            if frequently_involved(n):
                w.add("frequently_involved", _player_atom(pid), sid)

        # concept 5.1 — persistent half-space occupation.
        hs = g.dropna(subset=["player_id"]).copy()
        hs["lane"] = hs["start_y"].apply(lane_of)
        hs["is_half_space"] = hs["lane"].isin(["left_half_space", "right_half_space"])
        hs_counts = hs.groupby("player_id")["is_half_space"].sum()
        for pid, n in hs_counts.items():
            if n >= HALF_SPACE_MIN_TOUCHES:
                w.add("half_space_occupier", _player_atom(pid), sid)

    path = out_path or PHASE4_FACTS_PATH
    title = (
        f"{len(context)} sequences, {len(mem)} actions, "
        f"{context.match_id.nunique()} matches"
    )
    w.write(path, title=title)
    return path, w.counts(), context


# --------------------------------------------------------------------------
if __name__ == "__main__":
    path, counts, ctx = generate_tactical_facts()
    total = sum(counts.values())
    print(f"{path.name}: {total} facts, {len(ctx)} sequences")
    for k, v in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {k:<26} {v:>7}")
    PHASE4_MANIFEST_PATH.write_text(
        json.dumps(
            {
                "file": path.name,
                "n_sequences": int(len(ctx)),
                "n_matches": int(ctx.match_id.nunique()),
                "predicate_counts": counts,
                "total_facts": int(total),
            },
            indent=2,
        ),
        encoding="utf-8",
    )
