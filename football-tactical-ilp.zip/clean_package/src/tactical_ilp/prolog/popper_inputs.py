"""
Phase 5 — build the Popper input files (exs.pl, bk.pl, bias.pl).

Popper's task, in this project: learn a rule for

    negative_outcome(Sequence)

that separates the 143 "negative" build-up sequences (possession lost
dangerously) from the 923 "non_negative" ones, using the tactical concepts
from facts_all.pl + facts_tactical.pl + bk.pl as background knowledge.

Why sequence-level, not action-level
-------------------------------------
Every ground-truth label in this project (sequence_label/2) is per-sequence,
so the head predicate must take a sequence, not an action.  Concepts that are
naturally per-action (hesitation, triangulation, ...) are lifted to
"occurred somewhere in this sequence" with in_sequence/2, which is exactly
what several bk.pl rules already do (e.g. hesitant_negative_sequence/1).

Files produced (in data/prolog/popper/)
----------------------------------------
exs.pl    -- pos(negative_outcome(S)) / neg(negative_outcome(S))
bias.pl   -- head_pred/body_pred/type/direction declarations
bk.pl     -- a single consult of facts_all.pl + facts_tactical.pl + the
             hand-written bk.pl, all wrapped as body predicates Popper can
             call directly (Popper wants one bk.pl file, so this generates a
             thin wrapper rather than copying 120k lines).
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from tactical_ilp.config import PROLOG_DIR

POPPER_DIR = PROLOG_DIR / "popper"

# ---------------------------------------------------------------------------
# body predicates offered to Popper, grouped by arity.
#
# DESIGN CONSTRAINT (phase 4 pre-check + glossary v5): every body predicate
# here is boolean or small-domain.  None of them exposes a raw numeric value.
# Predicates that are naturally per-action are wrapped with an
# "occurred in this sequence" existential (see WRAPPED_ACTION_PREDS) rather
# than handed to Popper directly, so Popper never has to reach through
# in_sequence/2 itself -- that would add a variable and blow up the search
# space exactly as the phase-3 report warned about chain/4.
# ---------------------------------------------------------------------------

# sequence-level predicates already defined in bk.pl / facts_all.pl -- usable
# as-is, arity 1 (Sequence).
SEQUENCE_PREDS_1 = [
    "fast_sequence",
    "slow_sequence",
    # FIX: tempo_break/1 takes a Sequence, not an Action.  It used to sit in
    # WRAPPED_ACTION_PREDS, which generated
    #     seq_tempo_break(S) :- in_sequence(A, S), tempo_break(A).
    # i.e. it called tempo_break/1 on an ACTION id.  tempo/2 is keyed by
    # sequence, so that call could never match and seq_tempo_break/1 had
    # exactly 0 solutions -- a silently dead body predicate.
    "tempo_break",
]

# Predicates whose definition (directly or transitively) depends on
# sequence_label/2 -- i.e. on the very label Popper is asked to predict.
# Emitting any of these as a body_pred is target leakage.  Kept as an
# explicit blocklist so the failure mode is named rather than rediscovered.
LEAKY_PREDICATES = {
    "hesitant_negative_sequence",
    "negative_sequence",
    "positive_sequence",
}

# action-level predicates from bk.pl that we lift to "some action in this
# sequence satisfies P" via a generated wrapper predicate seq_P/1.
WRAPPED_ACTION_PREDS = [
    "line_breaking_pass",
    "midfield_line_breaking_pass",
    "diagonal_pass",
    "line_pass",
    "switch_of_play",
    "pass_in_behind",
    "connecting_pass",
    "dropped_between_lines",
    "layoff",
    "triangulation",
    "triangle_trap",
    "rondo_cage",
    "pressured_cage",
    "supported_action",
    "dead_end_support",
    "few_passing_options",
    "many_passing_options",
    "hesitated",
    "costly_hesitation",
    "first_time_play",
    "quick_line_break",
    "dwelt_long",
    "pressured_dwell",
    "regains_possession",
    "counter_pressed",
    "press_resistance",
    "counter_attack_potential",
    "keeper_build_up_start",
    "numeric_superiority",
]

# player x sequence predicates, lifted to "some player satisfies P in this
# sequence" -- e.g. persistent_half_space_occupier(Player, Seq).
WRAPPED_PLAYER_SEQ_PREDS = [
    "persistent_half_space_occupier",
    "give_and_continue",
]

# Concepts that are PROTECTIVE rather than predictive of a bad outcome.
# Popper cannot express negation in this bias, so each of these also gets an
# explicit not_<pred>/1 complement in the generated bk.pl.  Chosen from the
# measured lift table (base rate 0.134) in docs/phase5_review_findings.md:
# every entry has lift <= 0.70, i.e. its ABSENCE is the informative signal.
COMPLEMENT_PREDS = [
    "slow_sequence",          # lift 0.55
    "seq_switch_of_play",     # lift 0.54
    "seq_dwelt_long",         # lift 0.67
    "seq_hesitated",          # lift 0.70
    "seq_diagonal_pass",      # lift 0.70
]

BK_WRAPPER_HEADER = """\
%% ===================================================================
%%  AUTO-GENERATED - phase 5 Popper background knowledge wrapper
%%
%%  Loads the phase 3/4 facts and hand-written bk.pl, then defines one
%%  seq_<concept>/1 wrapper per action-level or player-level concept so
%%  Popper only ever reasons over Sequence, never over Action or Player
%%  variables directly (keeps the search space small).
%%
%%  PATHS ARE RELATIVE to this file, resolved at load time via
%%  prolog_load_context/2.  An earlier version baked in absolute paths from
%%  the machine that generated it, which broke the moment the project was
%%  unzipped anywhere else (Colab, Windows, a different user).
%% ===================================================================

%%  SWI-Prolog resolves a relative path in consult/1 against the directory
%%  of the file containing the directive, so these stay correct wherever the
%%  project is unpacked.
:- consult('../facts_all.pl').
:- consult('../facts_tactical.pl').
:- consult('../bk.pl').

"""


def _wrapper_action(pred: str) -> str:
    return f"seq_{pred}(S) :-\n    in_sequence(A, S),\n    {pred}(A).\n"


def _wrapper_player_seq(pred: str) -> str:
    return f"seq_{pred}(S) :-\n    {pred}(_, S).\n"


def build_bk_wrapper(out_path: Path) -> Path:
    """Write the Popper bk.pl wrapper.

    Uses relative consults (see BK_WRAPPER_HEADER) so the generated file
    stays valid after the project is moved, zipped, or unpacked on Colab.
    """
    lines = [BK_WRAPPER_HEADER]
    for pred in WRAPPED_ACTION_PREDS:
        lines.append(_wrapper_action(pred))
    for pred in WRAPPED_PLAYER_SEQ_PREDS:
        lines.append(_wrapper_player_seq(pred))

    # complement predicates: several concepts are PROTECTIVE (they correlate
    # with sequences ending well, not badly).  Popper's hypothesis space here
    # has no negation, so without an explicit complement it simply cannot
    # express "this sequence was NOT slow".  Measured lifts vs the 13.4% base
    # rate: slow_sequence 0.55, switch_of_play 0.54, dwelt_long 0.67,
    # hesitated 0.70, diagonal_pass 0.70 -- all strongly protective and all
    # invisible to Popper until now.
    for pred in COMPLEMENT_PREDS:
        lines.append(f"not_{pred}(S) :-\n    sequence(S),\n    \\+ {pred}(S).\n")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def build_bias(out_path: Path, max_vars: int = 6, max_body: int = 4) -> Path:
    all_body_preds = (
        [f"seq_{p}" for p in WRAPPED_ACTION_PREDS]
        + [f"seq_{p}" for p in WRAPPED_PLAYER_SEQ_PREDS]
        + SEQUENCE_PREDS_1
        + [f"not_{p}" for p in COMPLEMENT_PREDS]
    )

    # LEAKAGE GUARD: refuse to emit any predicate that depends on the target
    # label.  This is a hard failure, not a warning -- a leaking body_pred
    # silently produces a "perfect" but meaningless hypothesis.
    leaking = sorted(set(all_body_preds) & LEAKY_PREDICATES)
    if leaking:
        raise ValueError(
            "target leakage: these body predicates depend on sequence_label/2 "
            f"and must not be given to Popper: {leaking}"
        )

    lines = [
        "%% ===================================================================",
        "%%  AUTO-GENERATED - phase 5 Popper bias file",
        "%%",
        "%%  head: negative_outcome(Sequence) -- learn what marks a build-up",
        "%%  sequence as ending badly, from the tactical concepts as body preds.",
        "%%",
        "%%  DESIGN CONSTRAINT (phase 4 pre-check): start with a SMALL max_body",
        "%%  and max_vars, and only widen after confirming runtime is acceptable",
        "%%  on the sample dataset -- see docs/phase4_precheck_findings.md",
        "%%  and docs/phase5_review_findings.md.",
        "%% ===================================================================",
        "",
        "head_pred(negative_outcome,1).",
        "type(negative_outcome,(sequence,)).",
        "direction(negative_outcome,(in,)).",
        "",
    ]
    for pred in all_body_preds:
        lines.append(f"body_pred({pred},1).")
        lines.append(f"type({pred},(sequence,)).")
        lines.append(f"direction({pred},(in,)).")
    lines.append("")
    lines.append(f"max_vars({max_vars}).")
    lines.append(f"max_body({max_body}).")
    lines.append("max_clauses(3).")
    lines.append("")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path


def build_examples(
    out_path: Path,
    use_matched_negatives: bool = True,
    holdout_frac: float = 0.25,
    seed: int = 202021,
) -> tuple[Path, int, int, dict]:
    """Write exs.pl, and a held-out evaluation set alongside it.

    Two corrections over the first version:

    1. ``use_matched_negatives`` (default True) draws negatives from
       ``ilp_examples.parquet`` -- the CONTEXT-MATCHED sample built in phase
       2.4 and documented in docs/negative_sampling_strategy.md.  The first
       version read labeled_sequences.parquet and used all 923 negatives,
       silently discarding that whole piece of work.  Matched sampling is the
       project's own defence against Popper learning *context* (deep, under
       pressure) instead of *outcome*.

    2. A held-out split.  Popper reports precision/recall on the examples it
       was given, so training on everything makes "Precision 1.00" mean
       nothing.  Sequences are split by MATCH (never within a match) so a
       sequence and its near-duplicates from the same game cannot straddle
       the split.
    """
    import random

    processed = PROLOG_DIR.parent / "processed"
    labeled = pd.read_parquet(processed / "labeled_sequences.parquet")

    if use_matched_negatives:
        matched = pd.read_parquet(processed / "ilp_examples.parquet")
        keep = set(matched["sequence_id"])
        ex = labeled[labeled.sequence_id.isin(keep)].copy()
    else:
        ex = labeled.copy()

    # split by match so no match appears in both train and holdout
    matches = sorted(ex["match_id"].unique())
    rng = random.Random(seed)
    rng.shuffle(matches)
    n_hold = max(1, round(len(matches) * holdout_frac))
    holdout_matches = set(matches[:n_hold])

    train = ex[~ex.match_id.isin(holdout_matches)]
    hold = ex[ex.match_id.isin(holdout_matches)]

    def _emit(df: pd.DataFrame) -> str:
        lines = []
        for sid in sorted(df[df.label == "negative"]["sequence_id"]):
            lines.append(f"pos(negative_outcome({sid})).")
        for sid in sorted(df[df.label == "non_negative"]["sequence_id"]):
            lines.append(f"neg(negative_outcome({sid})).")
        return "\n".join(lines) + "\n"

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(_emit(train), encoding="utf-8")
    (out_path.parent / "exs_holdout.pl").write_text(_emit(hold), encoding="utf-8")

    n_pos = int((train.label == "negative").sum())
    n_neg = int((train.label == "non_negative").sum())
    split = {
        "matched_negatives": use_matched_negatives,
        "train_pos": n_pos,
        "train_neg": n_neg,
        "holdout_pos": int((hold.label == "negative").sum()),
        "holdout_neg": int((hold.label == "non_negative").sum()),
        "holdout_matches": sorted(holdout_matches),
        "n_train_matches": len(matches) - n_hold,
    }
    return out_path, n_pos, n_neg, split


def generate_popper_inputs() -> dict:
    bk_path = build_bk_wrapper(POPPER_DIR / "bk.pl")
    bias_path = build_bias(POPPER_DIR / "bias.pl")
    exs_path, n_pos, n_neg, split = build_examples(POPPER_DIR / "exs.pl")
    return {
        "dir": POPPER_DIR,
        "bk": bk_path,
        "bias": bias_path,
        "exs": exs_path,
        "n_pos": n_pos,
        "n_neg": n_neg,
        "split": split,
        "n_body_preds": len(WRAPPED_ACTION_PREDS) + len(WRAPPED_PLAYER_SEQ_PREDS) + len(SEQUENCE_PREDS_1),
    }


if __name__ == "__main__":
    info = generate_popper_inputs()
    print(f"Popper input dir: {info['dir']}")
    print(f"  exs.pl : {info['n_pos']} pos, {info['n_neg']} neg")
    print(f"  bias.pl: {info['n_body_preds']} body predicates")
    print()
    print("NOTE: each seq_<concept>/1 wrapper is a per-action existential, so")
    print("aggregate_all(count, seq_X(S), N) counts raw solutions (one per")
    print("qualifying action), not distinct sequences. Popper itself only ever")
    print("asks seq_X(S) for one fixed S at a time (true/false), so this does")
    print("not affect learning -- it only matters when reporting coverage by")
    print("hand.  Use distinct/2 (e.g. aggregate_all(count, distinct(S, seq_X(S)), N))")
    print("to report the number of distinct sequences instead.")
    print()
    print("run with:")
    print(f"  cd {info['dir']} && python /path/to/Popper/popper.py .")
