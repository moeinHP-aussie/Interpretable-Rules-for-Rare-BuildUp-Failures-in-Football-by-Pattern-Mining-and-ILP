"""
Central configuration for the neuro-symbolic tactical analysis project.

All paths are resolved relative to the project root so the code behaves
identically on Windows, Linux and macOS.
"""

from __future__ import annotations

import os
from pathlib import Path

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parents[2]

DATA_DIR = Path(os.environ.get("TACTICAL_ILP_DATA", PROJECT_ROOT / "data"))
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
PROLOG_DIR = DATA_DIR / "prolog"
REPORTS_DIR = DATA_DIR / "reports"
DOCS_DIR = PROJECT_ROOT / "docs"

for _d in (RAW_DIR, PROCESSED_DIR, PROLOG_DIR, REPORTS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------
# Dataset identity (technical document, decision #4)
# --------------------------------------------------------------------------
COMPETITION_ID = 11          # La Liga
SEASON_ID = 90               # 2020/2021
TEAM_NAME = "Barcelona"
TEAM_ID = 217                # StatsBomb team_id for FC Barcelona

# --------------------------------------------------------------------------
# Pitch geometry (SPADL standard: 105 x 68, attacking direction = +x)
# --------------------------------------------------------------------------
PITCH_LENGTH = 105.0
PITCH_WIDTH = 68.0

# 5 vertical lanes. y = 0 is the RIGHT touchline from the attacking team's
# point of view (because the team attacks towards +x).
LANE_EDGES = (0.0, 13.6, 27.2, 40.8, 54.4, 68.0)
LANE_NAMES = (
    "right_wing",
    "right_half_space",
    "central_channel",
    "left_half_space",
    "left_wing",
)

# Horizontal thirds
DEFENSIVE_THIRD_MAX_X = PITCH_LENGTH / 3.0          # 35.0
MIDDLE_THIRD_MAX_X = 2.0 * PITCH_LENGTH / 3.0       # 70.0

# Zone 14: the central zone immediately in front of the penalty area.
# Pitch split into 6 x 3 = 18 zones; zone 14 is x in [70, 87.5), y in [22.67, 45.33)
ZONE14_X = (70.0, 87.5)
ZONE14_Y = (PITCH_WIDTH / 3.0, 2.0 * PITCH_WIDTH / 3.0)

# --------------------------------------------------------------------------
# Phase 2 — build-up sequence definition
# --------------------------------------------------------------------------
# A build-up sequence starts when Barcelona takes controlled possession in its
# own defensive third and ends when the ball leaves the defensive third,
# possession is lost, or play stops.
BUILD_UP_START_MAX_X = DEFENSIVE_THIRD_MAX_X   # 35.0 m
BUILD_UP_EXIT_X = DEFENSIVE_THIRD_MAX_X        # crossing this line = build-up completed
MIN_SEQUENCE_LENGTH = 2
MAX_SEQUENCE_LENGTH = 25

# --------------------------------------------------------------------------
# Phase 2 — operational definition of a NEGATIVE OUTCOME
# (see docs/negative_outcome_definition.md — these constants ARE the definition)
# --------------------------------------------------------------------------
NEG_TURNOVER_WINDOW_S = 8.0     # ball lost within N seconds of the sequence end
# Redefined after phase-3 empirical review (see report.md): Barcelona's own
# possessions start at a median x of ~39.6 against low-block opponents typical
# of La Liga 2020/21, so the original 52.5 (halfway line) threshold flagged
# many turnovers that were nowhere near real danger as "own half, therefore
# risky". Tightened to sit just above our own defensive third.
NEG_DANGER_ZONE_MAX_X = 40.0    # turnover inside/just past our defensive third
NEG_OPP_SHOT_WINDOW_S = 12.0    # opponent shot within N seconds of the turnover
NEG_OPP_ENTRY_WINDOW_S = 12.0   # opponent reaches our final third within N seconds

# --------------------------------------------------------------------------
# Phase 3 — pressure model
# --------------------------------------------------------------------------
PRESSURE_RADIUS_M = 5.0          # opponents inside this radius count as pressure
TIGHT_PRESSURE_RADIUS_M = 3.0
PRESSURE_MIN_OPPONENTS = 1

# --------------------------------------------------------------------------
# Phase 1 — players reference
# --------------------------------------------------------------------------
MIN_APPEARANCES_FOR_REFERENCE = 5   # a player must appear in >= N matches

# --------------------------------------------------------------------------
# Phase 2.4 — negative sampling
# --------------------------------------------------------------------------
NEG_SAMPLES_PER_POSITIVE = 2
NEG_SAMPLING_RANDOM_SEED = 20_2021

# --------------------------------------------------------------------------
# Phase 4 — tactical concepts (see docs/tactical_concepts_glossary.md)
# --------------------------------------------------------------------------
# Concept 3.6a: only triangles formed by teammates *near the ball* count.  The
# radius is what keeps the concept affordable: enumerating triangles over all
# visible teammates costs ~37x the whole current fact base.
#
# CALIBRATED ON REAL DATA (scripts/run_phase4_calibration.py, 4 matches):
# the originally proposed 5 m radius turned out to be far too tight -- in 88%
# of actions no teammate at all is within 5 m, so the concept produced only
# 163 triangles and would have been empty in practice.  10 m matches the real
# short-passing distance of build-up play: ~62% of actions have a teammate in
# range, giving ~30k facts (0.3x the current fact base).
TRIANGLE_RADIUS_M = 10.0

# A triangle is only tactically meaningful if it encloses real space.  Degenerate
# shapes (three players almost in a line) are rejected by a minimum area, huge
# ones by a maximum area.  Calibrated from the observed area distribution
# (median 16 m^2, p99 43 m^2): min=8 drops the flattest ~24%, max=150 is a
# generous ceiling that only removes outliers.
TRIANGLE_MIN_AREA_M2 = 8.0
TRIANGLE_MAX_AREA_M2 = 150.0

# Concept 0.1: how many of the deepest opponents are treated as "the defensive
# line" and the next band as "the midfield line".  Positional approximation
# only -- 360 frames carry no player_id for non-actors, so a true role lookup
# is impossible (see the glossary, §2.3پ).
DEFENSIVE_LINE_SIZE = 4
MIDFIELD_LINE_SIZE = 3

# Minimum number of opponents that must be visible in a frame before the line
# clustering is trusted at all.
MIN_OPPONENTS_FOR_LINE = 6


def cache_path(kind: str, match_id: int | str, suffix: str = "parquet") -> Path:
    """Canonical cache file path, e.g. data/raw/events_3773386.parquet"""
    return RAW_DIR / f"{kind}_{match_id}.{suffix}"

# Concept 6.2 (tempo): actions per second inside a sequence, split at the
# empirical 33rd/67th percentiles of the real distribution (0.73 / 1.07).
TEMPO_SLOW_MAX = 0.73
TEMPO_FAST_MIN = 1.07

# Concept 6.1 (hesitation): a dwell time is "long" when it exceeds
# mean + 1 sd *of its own pressure level*.  Measured on the real data -- the
# levels differ a lot (heavy 1.05 s vs none 1.70 s on average), so a single
# global threshold would hide hesitation under pressure entirely.
HESITATION_THRESHOLD_S = {
    "heavy_pressure": 2.14,
    "light_pressure": 2.65,
    "no_pressure": 2.87,
    "unknown": 3.70,
}

# Concept 3.4: a player counts as "frequently involved" in a sequence when they
# touch the ball at least this many times.
FREQUENT_INVOLVEMENT_MIN = 3

# Concept 1.2 (diagonal pass): both axes must move meaningfully.  Calibrated
# on Barcelona's 24.8k passes -- median |dx| 6.9 m, |dy| 8.7 m; an 8 m floor on
# both axes keeps 22% of passes, inside the 5-40% acceptance band the glossary
# set for this concept.
DIAGONAL_MIN_DX_M = 8.0
DIAGONAL_MIN_DY_M = 8.0

# Concept 1.3 (switch of play): a lane change is not enough on its own (59% of
# passes change lane).  Requiring 25 m of lateral travel as well isolates the
# real switches: 5.6% of passes.
SWITCH_MIN_DY_M = 25.0

# Concept 4.1 (support): a teammate counts as supporting when no opponent
# stands within this many metres of the straight line to the ball carrier.
# 2 m approximates a defender's effective interception reach.
SUPPORT_CORRIDOR_M = 2.0

# Concept 4.5 (passing options): calibrated bucket edges for "few / some /
# many" open supporters, from the real distribution (median 3, p75 5, p90 6).
PASSING_OPTIONS_FEW_MAX = 1
PASSING_OPTIONS_MANY_MIN = 5

# Concept 5.1 (half-space occupation): a player counts as persistently
# occupying a half-space when they touch the ball from a half-space lane at
# least this many times inside one sequence.  Calibrated on the real
# distribution: median is 0, p75 is 1, so >=2 already picks out a minority
# with a genuinely repeated pattern rather than a single incidental touch.
HALF_SPACE_MIN_TOUCHES = 2
