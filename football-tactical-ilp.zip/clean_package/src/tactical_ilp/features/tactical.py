"""
Phase 4 — tactical concept extraction.

Turns the concept glossary (``docs/tactical_concepts_glossary.md``) into
computable functions.  Everything here produces **ground facts**; the genuine
Prolog *rules* live in ``bk.pl`` and are written by hand.

What is implemented, and what deliberately is not, is documented in
``docs/phase4_concept_disposition.md``.  The short version: a concept is
implemented when the 360 frame plus SPADL can answer it without inventing
data.  The hard limit throughout is that **non-actor players in a 360 frame
have no player_id** -- only anonymous ``(x, y, teammate, keeper)`` points --
so every concept about "which opponent" is positional, never identity-based.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass

import pandas as pd

from tactical_ilp.config import (
    FREQUENT_INVOLVEMENT_MIN,
    HESITATION_THRESHOLD_S,
    SUPPORT_CORRIDOR_M,
    TEMPO_FAST_MIN,
    TEMPO_SLOW_MAX,
    TRIANGLE_RADIUS_M,
)
from tactical_ilp.features.frames import (
    Point,
    actor_point,
    frame_points,
    near,
    opponents,
    teammates,
)
from tactical_ilp.features.geometry import (
    beyond_line,
    crosses_line,
    defensive_line_x,
    distance_point_to_segment,
    is_meaningful_triangle,
    midfield_line_x,
    point_in_triangle,
    pressure_level,
    triangle_area,
)


# ==========================================================================
# concept 4.1 / 4.5 — support (open passing lane), not distance
# ==========================================================================
def open_supporters(
    points: list[Point], corridor: float = SUPPORT_CORRIDOR_M
) -> int:
    """Concept 4.1/4.5 — how many teammates have an unobstructed passing lane.

    User's corrected definition: a supporter is defined by an OPEN passing
    lane to the ball carrier, not by distance.  A teammate only counts if no
    opponent stands within ``corridor`` metres of the straight line between
    them and the carrier.  This replaces the earlier (wrong) definition that
    derived "support" from passes_to/3, which only reflected who happened to
    receive the ball, not real geometric support.
    """
    carrier = actor_point(points)
    if carrier is None:
        return 0
    mates = teammates(points)
    opps = opponents(points)
    count = 0
    for m in mates:
        blocked = any(
            distance_point_to_segment(o.x, o.y, carrier.x, carrier.y, m.x, m.y)
            < corridor
            for o in opps
        )
        if not blocked:
            count += 1
    return count


# ==========================================================================
# concept 3.6 — triangulation around the ball carrier
# ==========================================================================
@dataclass(frozen=True)
class TriangleObservation:
    """One triangle found around a ball carrier at one action."""

    area: float
    traps_opponent: bool
    n_trapped: int


def triangles_at_action(
    points: list[Point], radius: float = TRIANGLE_RADIUS_M
) -> list[TriangleObservation]:
    """Concept 3.6a/3.6b — triangles the carrier forms with nearby teammates.

    The carrier is always one vertex: the glossary asks specifically for the
    small shapes *around the ball*, not for formation-wide geometry.  The
    radius restriction is what keeps this affordable (see config).

    3.6a (the event) and 3.6b (the consequence) stay separable: every triangle
    is reported with its ``traps_opponent`` flag rather than only the trapping
    ones, so Popper can learn the relation between them instead of having it
    baked into the definition.
    """
    carrier = actor_point(points)
    if carrier is None:
        return []
    mates = near(teammates(points), carrier, radius)
    if len(mates) < 2:
        return []

    opps = opponents(points)
    out: list[TriangleObservation] = []
    for p, q in itertools.combinations(mates, 2):
        if not is_meaningful_triangle(carrier.x, carrier.y, p.x, p.y, q.x, q.y):
            continue
        trapped = sum(
            1
            for o in opps
            if point_in_triangle(o.x, o.y, carrier.x, carrier.y, p.x, p.y, q.x, q.y)
        )
        out.append(
            TriangleObservation(
                area=triangle_area(carrier.x, carrier.y, p.x, p.y, q.x, q.y),
                traps_opponent=trapped > 0,
                n_trapped=trapped,
            )
        )
    return out


def triangulation_summary(points: list[Point]) -> dict:
    """Per-action summary of concept 3.6, ready to be dumped as facts."""
    tris = triangles_at_action(points)
    trapping = [t for t in tris if t.traps_opponent]
    return {
        "n_triangles": len(tris),
        "n_trapping": len(trapping),
        "max_trapped": max((t.n_trapped for t in tris), default=0),
        # "several overlapping triangles" from the glossary: a single triangle
        # is often accidental, two or more trapping ones are a real cage.
        "multi_trap": len(trapping) >= 2,
    }


# ==========================================================================
# concept 0.1 / 1.1 / 1.5 — opponent lines (positional proxy)
# ==========================================================================
def line_summary(points: list[Point], start_x: float, end_x: float) -> dict:
    """Concepts 1.1 and 1.5, both built on the 0.1 clustering helper.

    0.1 itself is *not* exported as a fact -- see the architectural note in
    geometry.py.  Only the tactical conclusions are.
    """
    opps = opponents(points, include_keeper=False)
    xs = [o.x for o in opps]
    dline = defensive_line_x(xs)
    mline = midfield_line_x(xs)
    return {
        "has_line": dline is not None,
        "breaks_defensive_line": crosses_line(start_x, end_x, dline),
        "breaks_midfield_line": crosses_line(start_x, end_x, mline),
        "beyond_defensive_line": beyond_line(end_x, dline),
        "defensive_line_x": dline,
    }


# ==========================================================================
# concept 6 — rhythm, timing, decision making
# ==========================================================================
def tempo_bucket(n_actions: int, duration_s: float) -> str | None:
    """Concept 6.2 — sequence tempo, discretised.

    Kept as a bucket rather than a raw float on purpose: a float would give
    Popper ~1000 distinct constants it cannot generalise over (glossary v3
    decision, confirmed by the phase 4 pre-check).
    """
    if duration_s is None or duration_s <= 0 or n_actions is None:
        return None
    rate = float(n_actions) / float(duration_s)
    if rate <= TEMPO_SLOW_MAX:
        return "slow"
    if rate >= TEMPO_FAST_MIN:
        return "fast"
    return "medium"


def is_hesitation(dwell_s: float | None, pressure: str) -> bool:
    """Concept 6.1 — did the player dwell unusually long on the ball?

    Compared against the mean+1sd of *its own pressure level*, not a global
    mean.  Measured on the real data the levels differ a lot (1.05 s under
    heavy pressure vs 1.70 s unpressured), so a global threshold would make
    hesitation-under-pressure almost undetectable.

    Note this is the *event*, deliberately separate from its consequence, so
    that Popper can discover "hesitation leads to X" rather than being told.
    """
    if dwell_s is None:
        return False
    try:
        d = float(dwell_s)
    except (TypeError, ValueError):
        return False
    if d != d or d < 0:  # NaN guard
        return False
    threshold = HESITATION_THRESHOLD_S.get(pressure, HESITATION_THRESHOLD_S["unknown"])
    return d > threshold


def is_one_touch(dwell_s: float | None) -> bool:
    """Concept 6.3 — first-time play: the ball leaves almost immediately."""
    if dwell_s is None:
        return False
    try:
        d = float(dwell_s)
    except (TypeError, ValueError):
        return False
    return 0 <= d <= 1.0


def frequently_involved(touch_count: int) -> bool:
    """Concept 3.4 — repeated involvement, as a boolean rather than a count."""
    return int(touch_count) >= FREQUENT_INVOLVEMENT_MIN


__all__ = [
    "TriangleObservation",
    "triangles_at_action",
    "triangulation_summary",
    "open_supporters",
    "line_summary",
    "tempo_bucket",
    "is_hesitation",
    "is_one_touch",
    "frequently_involved",
]
