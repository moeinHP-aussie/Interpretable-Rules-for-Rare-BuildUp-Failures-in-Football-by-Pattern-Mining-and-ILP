"""
Task 3.1 — Basic geometric predicates (the "neural layer" of the MVP).

Technical document §2.2 replaces a real neural encoder with a rule-based
feature extractor for the MVP.  This module is that extractor: pure, side-effect
free Python functions that turn SPADL coordinates plus a 360 freeze frame into
**discrete symbols**.  Phase 3.2/3.3 dumps their output as ground Prolog facts.

Reference frame (fixed for the whole project)
---------------------------------------------
    x in [0, 105]   0 = Barcelona's own goal line, 105 = opponent goal line
    y in [0, 68]    0 = right touchline seen from Barcelona's attacking direction

Vertical lanes (5-lane model)
    right_wing | right_half_space | central_channel | left_half_space | left_wing
     0 - 13.6      13.6 - 27.2        27.2 - 40.8       40.8 - 54.4     54.4 - 68
"""

from __future__ import annotations

import math

from tactical_ilp.config import (
    DEFENSIVE_LINE_SIZE,
    DIAGONAL_MIN_DX_M,
    DIAGONAL_MIN_DY_M,
    DEFENSIVE_THIRD_MAX_X,
    LANE_EDGES,
    LANE_NAMES,
    MIDDLE_THIRD_MAX_X,
    MIDFIELD_LINE_SIZE,
    MIN_OPPONENTS_FOR_LINE,
    PITCH_LENGTH,
    PITCH_WIDTH,
    PRESSURE_MIN_OPPONENTS,
    PRESSURE_RADIUS_M,
    SWITCH_MIN_DY_M,
    TIGHT_PRESSURE_RADIUS_M,
    TRIANGLE_MAX_AREA_M2,
    TRIANGLE_MIN_AREA_M2,
    ZONE14_X,
    ZONE14_Y,
)

# --------------------------------------------------------------------------
# lanes / thirds / zones
# --------------------------------------------------------------------------


def lane_of(y: float) -> str:
    """Vertical lane containing ``y``."""
    y = min(max(float(y), 0.0), PITCH_WIDTH)
    for i in range(len(LANE_NAMES)):
        lo, hi = LANE_EDGES[i], LANE_EDGES[i + 1]
        if lo <= y < hi or (i == len(LANE_NAMES) - 1 and y == hi):
            return LANE_NAMES[i]
    return LANE_NAMES[-1]


def occupies_half_space(x: float, y: float) -> str:
    """
    Lane occupied by a player/ball at ``(x, y)``.

    Named after the tactical concept but returns the full lane vocabulary so a
    single predicate covers wings, half-spaces and the central channel.
    ``x`` is accepted for signature stability (lanes are x-independent) and to
    keep the Prolog-side predicate a proper 2-argument geometric function.
    """
    return lane_of(y)


def is_half_space(x: float, y: float) -> bool:
    return occupies_half_space(x, y) in ("right_half_space", "left_half_space")


def third_of(x: float) -> str:
    """Horizontal third from Barcelona's point of view."""
    x = float(x)
    if x <= DEFENSIVE_THIRD_MAX_X:
        return "defensive_third"
    if x <= MIDDLE_THIRD_MAX_X:
        return "middle_third"
    return "final_third"


def is_zone14(x: float, y: float) -> bool:
    """Central zone immediately in front of the opponent penalty area."""
    return (ZONE14_X[0] <= float(x) < ZONE14_X[1]) and (
        ZONE14_Y[0] <= float(y) < ZONE14_Y[1]
    )


def pitch_zone(x: float, y: float) -> str:
    """Compact symbol combining third and lane, e.g. 'defensive_third|left_wing'."""
    return f"{third_of(x)}|{lane_of(y)}"


# --------------------------------------------------------------------------
# pressure
# --------------------------------------------------------------------------


def under_pressure(
    opponents_within_5m: float | None = None,
    statsbomb_flag: bool = False,
    min_opponents: int = PRESSURE_MIN_OPPONENTS,
) -> bool:
    """
    Pressure model.

    Primary signal is the 360 freeze frame (how many opponents stand within
    ``PRESSURE_RADIUS_M`` of the ball).  When no freeze frame exists we fall
    back to StatsBomb's own ``under_pressure`` flag, so the predicate is total.
    """
    if opponents_within_5m is not None and not _isnan(opponents_within_5m):
        return int(opponents_within_5m) >= min_opponents
    return bool(statsbomb_flag)


def pressure_level(
    opponents_within_3m: float | None,
    opponents_within_5m: float | None,
    statsbomb_flag: bool = False,
) -> str:
    """Discrete pressure symbol: no_pressure | light_pressure | heavy_pressure."""
    if opponents_within_3m is not None and not _isnan(opponents_within_3m):
        n3 = int(opponents_within_3m)
        n5 = int(opponents_within_5m or 0)
        if n3 >= 2:
            return "heavy_pressure"
        if n3 >= 1 or n5 >= 2:
            return "light_pressure"
        return "no_pressure"
    return "light_pressure" if statsbomb_flag else "no_pressure"


# --------------------------------------------------------------------------
# passes / carries
# --------------------------------------------------------------------------


def pass_direction(
    start_x: float, start_y: float, end_x: float, end_y: float
) -> str:
    """forward | sideways | backward, using a +/-30 degree band around the y axis."""
    dx = float(end_x) - float(start_x)
    dy = float(end_y) - float(start_y)
    if abs(dx) < 1e-9 and abs(dy) < 1e-9:
        return "sideways"
    angle = math.degrees(math.atan2(dx, abs(dy) if dy else 1e-9))
    if dx > 0 and (abs(dy) <= 1e-9 or abs(dx) >= abs(dy) * 0.5774):
        return "forward"
    if dx < 0 and (abs(dy) <= 1e-9 or abs(dx) >= abs(dy) * 0.5774):
        return "backward"
    return "sideways"


def pass_length_class(
    start_x: float, start_y: float, end_x: float, end_y: float
) -> str:
    """short (<10 m) | medium (10-25 m) | long (>25 m)."""
    d = math.hypot(float(end_x) - float(start_x), float(end_y) - float(start_y))
    if d < 10.0:
        return "short"
    if d <= 25.0:
        return "medium"
    return "long"


def is_progressive(
    start_x: float, start_y: float, end_x: float, end_y: float
) -> bool:
    """
    Zone-scaled progressive-action rule (redefined after phase-3 empirical
    review — see report.md section "بازتعریف is_progressive").

    The original flat 25%-reduction rule marked only 5.6% of defensive-third
    actions as progressive, because deep build-up naturally consists of many
    short, safe passes whose absolute distance-to-goal reduction is small even
    when they meaningfully advance the move. A single global threshold treats
    that as "mostly non-progressive", which does not match footballing
    intuition and starves Popper of positive evidence for progression-related
    rules in exactly the zone (defensive third) the whole project cares about.

    Threshold now scales with the third the action starts in:
        defensive third (x<=35)  : >= 10% reduction  (empirically ~25% of actions)
        middle third   (35<x<=70): >= 25% reduction  (original rule)
        final third    (x>70)    : >= 10 m absolute forward gain (original rule)
    """
    goal = (PITCH_LENGTH, PITCH_WIDTH / 2.0)
    d0 = math.hypot(goal[0] - float(start_x), goal[1] - float(start_y))
    d1 = math.hypot(goal[0] - float(end_x), goal[1] - float(end_y))
    reduction = 1.0 - (d1 / d0) if d0 > 1e-9 else 0.0

    if float(start_x) <= DEFENSIVE_THIRD_MAX_X:
        return reduction >= 0.10
    elif float(start_x) <= MIDDLE_THIRD_MAX_X:
        return reduction >= 0.25
    else:
        return (float(end_x) - float(start_x)) >= 10.0


def distance_to_own_goal(x: float, y: float) -> float:
    return math.hypot(float(x), float(y) - PITCH_WIDTH / 2.0)


def distance_point_to_segment(
    px: float, py: float, ax: float, ay: float, bx: float, by: float
) -> float:
    """Perpendicular distance from P to the segment AB (concept 4.1).

    Used to test whether an opponent stands "on" the passing lane between the
    ball carrier and a teammate, clamped to the segment itself so a defender
    far past either endpoint does not count as blocking.
    """
    dx, dy = float(bx) - float(ax), float(by) - float(ay)
    if dx == 0.0 and dy == 0.0:
        return math.hypot(float(px) - float(ax), float(py) - float(ay))
    t = ((float(px) - float(ax)) * dx + (float(py) - float(ay)) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    cx, cy = float(ax) + t * dx, float(ay) + t * dy
    return math.hypot(float(px) - cx, float(py) - cy)


# --------------------------------------------------------------------------
# Phase 4 — two-axis pass shapes (concepts 1.2 and 1.3)
# --------------------------------------------------------------------------
# pass_direction/2 (phase 3) collapses a pass into forward|sideways|backward,
# which cannot express "moves on both axes at once".  These two functions look
# at the raw vector instead.  Thresholds are calibrated, not guessed -- see the
# comments in config.py.
def is_diagonal_pass(
    start_x: float,
    start_y: float,
    end_x: float,
    end_y: float,
    min_dx: float = DIAGONAL_MIN_DX_M,
    min_dy: float = DIAGONAL_MIN_DY_M,
) -> bool:
    """Concept 1.2 — meaningful movement on BOTH axes."""
    if any(_isnan(v) for v in (start_x, start_y, end_x, end_y)):
        return False
    dx = abs(float(end_x) - float(start_x))
    dy = abs(float(end_y) - float(start_y))
    return dx >= min_dx and dy >= min_dy


def is_switch_of_play(
    start_x: float,
    start_y: float,
    end_x: float,
    end_y: float,
    min_dy: float = SWITCH_MIN_DY_M,
) -> bool:
    """Concept 1.3 — a genuine switch: lane change PLUS real lateral travel.

    A lane change alone is far too common (59% of Barcelona's passes) because
    the lanes are only 13.6 m wide.
    """
    if any(_isnan(v) for v in (start_x, start_y, end_x, end_y)):
        return False
    if abs(float(end_y) - float(start_y)) < min_dy:
        return False
    return lane_of(start_y) != lane_of(end_y)


# --------------------------------------------------------------------------
# Phase 4 — triangle geometry (concept 3.6)
# --------------------------------------------------------------------------
def triangle_area(
    ax: float, ay: float, bx: float, by: float, cx: float, cy: float
) -> float:
    """Area of the triangle ABC in square metres (shoelace formula)."""
    return abs(
        (float(bx) - float(ax)) * (float(cy) - float(ay))
        - (float(cx) - float(ax)) * (float(by) - float(ay))
    ) / 2.0


def is_meaningful_triangle(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    min_area: float = TRIANGLE_MIN_AREA_M2,
    max_area: float = TRIANGLE_MAX_AREA_M2,
) -> bool:
    """Does ABC enclose enough space to be a tactical shape rather than a line?

    Concept 3.6a.  Three players standing almost in a row technically form a
    triangle but offer no passing geometry, so a minimum area filters them out;
    a maximum area keeps the concept local to the ball.
    """
    area = triangle_area(ax, ay, bx, by, cx, cy)
    return min_area <= area <= max_area


def point_in_triangle(
    px: float,
    py: float,
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
) -> bool:
    """Is P strictly inside triangle ABC?  (concept 3.6b)

    Uses the sign-of-cross-product test.  Points exactly on an edge count as
    outside: a defender standing on the passing line is not *trapped*, they are
    intercepting it.
    """

    def cross(x1: float, y1: float, x2: float, y2: float, x3: float, y3: float) -> float:
        return (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1)

    d1 = cross(ax, ay, bx, by, px, py)
    d2 = cross(bx, by, cx, cy, px, py)
    d3 = cross(cx, cy, ax, ay, px, py)
    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (has_neg and has_pos) and not (d1 == 0 or d2 == 0 or d3 == 0)


# --------------------------------------------------------------------------
# Phase 4 — defensive / midfield line clustering (concept 0.1)
# --------------------------------------------------------------------------
# ARCHITECTURAL NOTE (glossary v5, explicit decision):
# This is an *internal helper of the fact-extraction stage*, never a predicate
# in bias.pl.  Dependent concepts (1.1, 1.5, 7.5, 7.6b) call it while facts are
# being written and dump only their own result.  Popper must never learn rules
# over the raw x-rank approximation itself.
def defensive_line_x(
    opponent_xs: list[float],
    line_size: int = DEFENSIVE_LINE_SIZE,
    min_opponents: int = MIN_OPPONENTS_FOR_LINE,
) -> float | None:
    """Mean x of the ``line_size`` deepest opponents, or None if too few.

    "Deepest" means closest to the goal the opposition is defending, which in
    this project's reference frame is always the smallest x when Barcelona
    attacks.  This is a positional proxy: 360 frames carry no player_id for
    non-actors, so we cannot verify that these really are the centre-backs.
    """
    xs = sorted(float(x) for x in opponent_xs if not _isnan(x))
    if len(xs) < min_opponents:
        return None
    take = xs[:line_size]
    return sum(take) / len(take)


def midfield_line_x(
    opponent_xs: list[float],
    defensive_size: int = DEFENSIVE_LINE_SIZE,
    midfield_size: int = MIDFIELD_LINE_SIZE,
    min_opponents: int = MIN_OPPONENTS_FOR_LINE,
) -> float | None:
    """Mean x of the band of opponents just ahead of the defensive line."""
    xs = sorted(float(x) for x in opponent_xs if not _isnan(x))
    if len(xs) < min_opponents:
        return None
    band = xs[defensive_size : defensive_size + midfield_size]
    if not band:
        return None
    return sum(band) / len(band)


def crosses_line(start_x: float, end_x: float, line_x: float | None) -> bool:
    """Did the ball travel from behind a line to beyond it?  (concept 1.1)"""
    if line_x is None or _isnan(start_x) or _isnan(end_x):
        return False
    return float(start_x) < float(line_x) < float(end_x)


def beyond_line(end_x: float, line_x: float | None) -> bool:
    """Did the ball end up past the whole defensive line?  (concept 1.5)"""
    if line_x is None or _isnan(end_x):
        return False
    return float(end_x) > float(line_x)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def _isnan(v) -> bool:
    try:
        return math.isnan(float(v))
    except (TypeError, ValueError):
        return True


__all__ = [
    "lane_of",
    "occupies_half_space",
    "is_half_space",
    "third_of",
    "is_zone14",
    "pitch_zone",
    "under_pressure",
    "pressure_level",
    "pass_direction",
    "pass_length_class",
    "is_progressive",
    "distance_to_own_goal",
    "is_diagonal_pass",
    "is_switch_of_play",
    "triangle_area",
    "is_meaningful_triangle",
    "point_in_triangle",
    "defensive_line_x",
    "midfield_line_x",
    "crosses_line",
    "beyond_line",
    "distance_point_to_segment",
    "PRESSURE_RADIUS_M",
    "TIGHT_PRESSURE_RADIUS_M",
]
