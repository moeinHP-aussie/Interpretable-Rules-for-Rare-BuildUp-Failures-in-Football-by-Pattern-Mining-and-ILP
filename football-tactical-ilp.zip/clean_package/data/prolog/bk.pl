%% ===================================================================
%%  bk.pl - BACKGROUND KNOWLEDGE (phase 4)
%%
%%  HAND-WRITTEN Prolog RULES.  Unlike facts_all.pl and facts_tactical.pl
%%  (which are auto-generated ground facts), everything in this file is a
%%  live rule that derives new tactical concepts from those facts.
%%
%%  Load order:
%%      :- consult('facts_all.pl').        % phase 3 facts
%%      :- consult('facts_tactical.pl').   % phase 4 facts
%%      :- consult('bk.pl').               % this file
%%
%%  Naming convention: every rule head here is a concept from
%%  docs/tactical_concepts_glossary.md and carries its section number.
%%
%%  DESIGN CONSTRAINT (phase 4 pre-check + glossary v5):
%%  Rules stay low-arity and avoid introducing new entities.  Predicates
%%  intended for Popper's bias must be boolean or small-domain; raw numeric
%%  values are never exposed as rule arguments.
%% ===================================================================

:- discontiguous progressive_action/1.
:- discontiguous supports/3.


%% ===================================================================
%% 1. PASS SHAPES  (glossary section 1)
%% ===================================================================

%% 1.1 line-breaking pass -- the ball travels from behind an opponent line
%% to beyond it.  The line itself comes from the 0.1 positional proxy and is
%% already resolved in facts_tactical.pl, so this rule only combines it with
%% success and pass-hood.
line_breaking_pass(A) :-
    breaks_defensive_line(A),
    successful(A),
    pass_like(A).

midfield_line_breaking_pass(A) :-
    breaks_midfield_line(A),
    successful(A),
    pass_like(A).

%% 1.2 diagonal pass -- meaningful movement on BOTH axes.
%%
%% NOTE (bug found during phase 4 validation): the first version of this rule
%% matched pass_direction(A, forward_left) and friends.  Those symbols do not
%% exist -- pass_direction/2 only ever takes forward | sideways | backward, so
%% the rule silently returned zero solutions.  The two-axis test now lives in
%% Python (geometry.is_diagonal_pass) and arrives as diagonal_pass_shape/1.
diagonal_pass(A) :-
    diagonal_pass_shape(A),
    pass_like(A).

successful_diagonal_pass(A) :-
    diagonal_pass(A),
    successful(A).

%% 1.3 switch of play -- lane change PLUS real lateral travel (>= 25 m).
%% Same bug as 1.2 in the first version; same fix.  A lane change on its own
%% is not a switch: 59% of Barcelona's passes change lane because the lanes
%% are only 13.6 m wide.
switch_of_play(A) :-
    switch_shape(A),
    pass_like(A),
    successful(A).

%% 1.5 pass in behind -- ball ends beyond the whole defensive line.
%% Deliberately kept separate from 1.1 (glossary v3 decision): breaking
%% THROUGH a line and landing BEHIND all of it are different ideas.
pass_in_behind(A) :-
    beyond_defensive_line(A),
    successful(A),
    pass_like(A).


%% 1.3 line pass -- stays in the same lane, that lane is a wide/half-space
%% corridor (not the central channel), and travels mainly along x.
%% NOTE: glossary numbering reused "1.3" for both this and switch_of_play in
%% earlier drafts; this project keeps "1.3 line pass" and "1.4 switch" as the
%% two distinct concepts the glossary itself separates in its final text.
line_pass(A) :-
    pass_like(A),
    at_lane(A, L),
    wide_lane(L),
    same_lane(A),
    \+ sideways_only(A).

wide_lane(right_wing).
wide_lane(right_half_space).
wide_lane(left_half_space).
wide_lane(left_wing).

same_lane(A) :-
    in_sequence(A, S),
    action_order(A, N),
    N1 is N + 1,
    in_sequence(B, S),
    action_order(B, N1),
    at_lane(A, L),
    at_lane(B, L).

sideways_only(A) :- pass_direction(A, sideways).

%% 1.4 switch of play (renamed from the earlier "1.3" slot -- see note above).
%% NOTE: this predicate name is intentionally identical to the glossary's own
%% 1.3-labelled rule further down in the file history; only one definition of
%% switch_of_play/1 exists in this file (the two-axis one using
%% switch_shape/1), this comment just documents where "1.4" maps in the rules.

%% 1.6 connecting pass -- short, low-risk, not progressive: the opposite of a
%% line-breaking or progressive pass.
connecting_pass(A) :-
    pass_like(A),
    pass_length(A, short),
    \+ progressive(A),
    successful(A).

%% 1.7 cross -- StatsBomb already tags this as its own action type.
%%
%% FINDING (phase 4 validation): this rule has ZERO solutions in the current
%% dataset, and that is expected, not a bug.  action_type/2 in facts_all.pl
%% only ever takes the 14 values that actually appear inside build-up
%% sequences (bad_touch, clearance, dribble, foul, freekick_crossed,
%% freekick_short, goalkick, interception, keeper_claim, keeper_save, pass,
%% tackle, take_on, throw_in) -- "cross" is not among them because a cross by
%% definition happens once the ball has already left the build-up phase
%% (BUILD_UP_EXIT_X in config.py).  The rule is kept because it is correct and
%% harmless, and would start firing if a future phase extends sequences past
%% the build-up boundary.
cross_pass(A) :- action_type(A, cross).

successful_cross(A) :-
    cross_pass(A),
    successful(A).


%% ===================================================================
%% 2. OFF-BALL MOVEMENT AND ATTACKING POSITIONING  (glossary section 2)
%% ===================================================================

%% 2.3 drop between the (opponent) lines -- the Barcelona player carrying the
%% ball is himself positioned between the opponent defensive and midfield
%% lines (0.1 helper, positional proxy for both lines).
%%
%% NOTE on scope: only the actor can be checked this way.  A non-actor
%% teammate in a 360 frame carries no player_id at all (not even "teammate,
%% unnamed" -- see glossary 2.3b), so this rule cannot ask "is our defensive
%% midfielder between the lines", only "is whoever has the ball right now".
dropped_between_lines(A) :-
    drop_between_lines(A),
    actor(A, P),
    plays_for(P, barcelona).


%% ===================================================================
%% 3. COMBINATIONS  (glossary section 3)
%% ===================================================================

%% 3.3 rapid combination -- >= 3 short passes among >= 3 different players
%% inside a 6-second window.  Sequence-level, from facts_tactical.pl.
rapid_combination_sequence(S) :- rapid_combination(S).

%% 3.5 layoff -- one-touch pass that does not go forward, by definition a
%% "give it back / lay it off" action rather than a progressive pass.
%% APPROXIMATION (documented explicitly): the glossary's real definition
%% needs the passer's body orientation and role as a target man, neither of
%% which the data carries.  This proxy only checks touch time and direction.
layoff(A) :-
    layoff_candidate(A),
    \+ progressive(A).
give_and_go(P1, P2, S) :-
    passes_to(P1, P2, S),
    passes_to(P2, P1, S),
    P1 \== P2.

%% 3.2 third-man combination -- already available as chain/4 from phase 3.
third_man(P1, P2, P3, S) :-
    chain(P1, P2, P3, S),
    P1 \== P3.

%% 3.4 give-and-continue -- a player keeps reappearing in the sequence.
%% Boolean by construction (frequently_involved/2), never a raw count.
give_and_continue(P, S) :-
    frequently_involved(P, S),
    involved_in(P, S).

%% 3.6a triangulation -- the carrier and two nearby teammates form a real
%% triangle.  Reported independently of whether it traps anyone, so that the
%% event stays separable from its consequence (glossary 3.6 / 6.1 pattern).
triangulation(A) :-
    forms_triangle(A).

%% 3.6b trapped opponent -- at least one opponent stands inside a triangle.
triangle_trap(A) :-
    traps_opponent(A).

%% several overlapping trapping triangles: a single triangle is often
%% accidental, a cage is deliberate.
rondo_cage(A) :-
    caged_opponent(A).

%% the interesting compound: a cage built while under real pressure
pressured_cage(A) :-
    caged_opponent(A),
    under_pressure(A).


%% ===================================================================
%% 4. SUPPORT AND ATTACKING COVER  (glossary section 4)
%% ===================================================================

%% 4.1 support -- OPEN PASSING LANE, not distance and not passes_to/3.
%%
%% NOTE (explicit correction, glossary v3): an earlier version of this
%% predicate derived "support" from passes_to/3, which only reflects who
%% happened to receive the ball, not real geometric support.  has_open_support/1
%% comes from a proper point-to-segment distance test (features/tactical.py:
%% open_supporters) against every visible opponent.
supported_action(A) :- has_open_support(A).

%% 4.3 dead-end support -- the ball reaches an open supporter, but their own
%% next action is not progressive.  Needs the supporter's OWN next touch, so
%% this is phrased over the sequence rather than a single fact.
dead_end_support(A) :-
    has_open_support(A),
    in_sequence(A, S),
    action_order(A, N),
    N1 is N + 1,
    in_sequence(B, S),
    action_order(B, N1),
    \+ progressive(B).

%% 4.5 passing options -- discretised count of open supporters.
few_passing_options(A) :- passing_options(A, few).
many_passing_options(A) :- passing_options(A, many).


%% ===================================================================
%% 5. SPATIAL STRUCTURE AND PITCH OCCUPATION  (glossary section 5)
%% ===================================================================

%% 5.1 half-space occupation -- a player repeatedly touching the ball from a
%% half-space lane within one sequence (positional proxy, sequence-level).
persistent_half_space_occupier(P, S) :- half_space_occupier(P, S).

%% 5.5 zone 14 occupation.
%%
%% FINDING (phase 4 validation): in_zone14/1 is never actually written to
%% facts_all.pl, and this is a structural fact about the dataset, not a phase
%% 3 bug.  Zone 14 is x in [70, 87.5] (attacking third, central channel), but
%% build-up sequences are defined to run in x < 35 and END once the ball
%% crosses that line (BUILD_UP_EXIT_X in config.py).  Checked directly: 0 of
%% 5329 build-up actions have a start position in zone 14.  The concept is
%% correctly implemented and glossary-accurate; it is simply out of the
%% spatial range this project's sequences ever reach.  Kept here, commented
%% out, so it activates automatically if a future phase extends sequences
%% past the build-up boundary.
% zone14_occupation(A) :- in_zone14(A).


%% ===================================================================
%% 7. DEFENSIVE PHASE  (glossary section 7)
%% ===================================================================
%% NOTE: this section is explicitly scoped to actions that already occur
%% INSIDE a build-up sequence (a tackle or interception that starts the
%% sequence), not a general defensive-phase model.  The glossary itself flags
%% section 7 as written for future phases beyond the current build-up focus.

%% 7.1 / 7.2 successful defensive actions that open a build-up sequence.
%% These already exist as action_type/2 ground facts; naming them explicitly
%% makes the tactical concept queryable on its own rather than hidden inside
%% a generic type check.
regains_possession(A) :- successful_tackle(A).
regains_possession(A) :- successful_interception(A).


%% ===================================================================
%% 8. PRESSING AND COUNTER-PRESSING  (glossary section 8)
%% ===================================================================

%% 8.3 counter-press -- StatsBomb's own flag, dumped as-is.
counter_pressed(A) :- counterpress_action(A).

%% 8.4 press resistance -- a successful action taken under heavy pressure.
%% Outcome-based, exactly as the glossary defines it.
press_resistance(A) :-
    pressure_level(A, heavy_pressure),
    successful(A).


%% ===================================================================
%% 9. TRANSITION  (glossary section 9)
%% ===================================================================

%% 9.1 counter-attack -- numeric superiority in the OPPONENT half.
%% 9.1b counter-attack potential -- the same superiority in OWN half.
%% Both from numeric_superiority/1 (features/tactical.py), split by third.
%% CAVEAT (glossary-flagged): the 360 frame does not always show every
%% outfield player, so this is a coverage-limited proxy, not an exact count.
%%
%% FINDING (phase 4 validation): counter_attack/1 has only 1 solution in this
%% dataset -- not a bug.  Build-up sequences are defined to start in the
%% defensive third and mostly stay there (2181 of 2182 numeric_superiority
%% facts are in the defensive third); reaching the opponent's half at all is
%% rare by construction.  counter_attack_potential/1 is therefore almost
%% exactly numeric_superiority/1 restricted to the defensive third in this
%% dataset, which is a real and correctly-derived finding: this build-up
%% corpus is built to study build-up shape, not finished transitions.
counter_attack(A) :-
    numeric_superiority(A),
    \+ at_third(A, defensive_third).

counter_attack_potential(A) :-
    numeric_superiority(A),
    at_third(A, defensive_third).


%% ===================================================================
%% 12. GOALKEEPER CONCEPTS  (glossary section 12)
%% ===================================================================

%% 12.1 sweeper-keeper / playing out with the keeper -- the keeper actively
%% starts the build-up with their feet rather than clearing long.
keeper_build_up_start(A) :-
    action_order(A, 0),
    keeper_start_type(A).

keeper_start_type(A) :- action_type(A, goalkick).
keeper_start_type(A) :- action_type(A, keeper_claim).


%% ===================================================================
%% 6. RHYTHM, TIMING, DECISION MAKING  (glossary section 6)
%% ===================================================================

%% 6.1 hesitation -- dwell time above the norm FOR ITS OWN PRESSURE LEVEL.
%% The event only; its consequences are left for Popper to discover.
hesitated(A) :-
    hesitation(A).

%% hesitation that actually cost possession -- kept as a SEPARATE predicate
%% rather than folded into the definition above.
%%
%% NOTE (found during phase 4 validation): the obvious version,
%%     costly_hesitation(A) :- hesitation(A), failed(A).
%% is structurally impossible in this dataset and always returns zero.  All
%% 198 failed actions are the LAST action of their sequence (a sequence ends
%% when possession is lost), and dwell time is measured as the gap to the NEXT
%% action -- so a failed action never has a dwell time, and therefore never
%% carries hesitation/1.
%%
%% The meaningful formulation is one step earlier: the player hesitated, and
%% the sequence died on the very next action.
costly_hesitation(A) :-
    hesitation(A),
    in_sequence(A, S),
    action_order(A, N),
    N1 is N + 1,
    in_sequence(B, S),
    action_order(B, N1),
    failed(B).

%% the same idea at sequence level: a sequence that contained hesitation and
%% ended badly
%%
%% !! TARGET LEAKAGE -- ANALYSIS ONLY, NEVER A POPPER BODY PREDICATE !!
%%
%% This rule contains sequence_label(S, negative) in its own body, i.e. it
%% contains the answer Popper is being asked to predict.  Offering it as a
%% body_pred lets Popper "learn"
%%     negative_outcome(S) :- hesitant_negative_sequence(S).
%% which scores precision 1.00 by construction and is worth nothing.
%%
%% Measured on this dataset: 34 positives / 0 negatives -> precision 1.00.
%% When it was (wrongly) exposed in bias.pl, Popper picked it as its FIRST
%% clause and it supplied 34 of the 39 true positives; removing it dropped
%% recall from 0.27 to 0.07.  See docs/phase5_review_findings.md.
%%
%% The predicate itself is still useful for descriptive analysis ("how many
%% bad sequences contained hesitation?"), so it is kept -- but
%% popper_inputs.py now refuses to emit any predicate whose transitive
%% definition touches sequence_label/2 (LEAKY_PREDICATES guard).
hesitant_negative_sequence(S) :-
    sequence_label(S, negative),
    in_sequence(A, S),
    hesitation(A).

%% 6.2 tempo -- sequence-level, discretised.
fast_sequence(S) :- tempo(S, fast).
slow_sequence(S) :- tempo(S, slow).

%% a tempo change is the interesting tactical event: a slow build-up that
%% contains at least one one-touch action is a deliberate acceleration.
tempo_break(S) :-
    slow_sequence(S),
    in_sequence(A, S),
    one_touch(A).

%% 6.3 one-touch play
first_time_play(A) :-
    one_touch(A).

%% 6.3b a one-touch action that also breaks a line: the quick combination
%% that actually hurts.
quick_line_break(A) :-
    one_touch(A),
    breaks_defensive_line(A),
    successful(A).

%% 6.4 time on the ball
dwelt_long(A) :- dwell_time(A, long).
released_instantly(A) :- dwell_time(A, instant).

%% 6.5 playing under time pressure: a long dwell while opponents are close
%% is a different phenomenon from a long dwell in space.
pressured_dwell(A) :-
    dwell_time(A, long),
    pressure_level(A, heavy_pressure).


%% ===================================================================
%% CROSS-CUTTING HELPERS
%% ===================================================================

pass_like(A) :- action_type(A, pass).
pass_like(A) :- action_type(A, cross).
pass_like(A) :- action_type(A, freekick_short).
pass_like(A) :- action_type(A, goalkick).
pass_like(A) :- action_type(A, throw_in).
pass_like(A) :- action_type(A, corner_short).

carry_like(A) :- action_type(A, dribble).

progressive_action(A) :- progressive(A).

%% an action in the defensive third is a build-up action proper
build_up_action(A) :- at_third(A, defensive_third).
build_up_action(A) :- at_third(A, middle_third).

%% 4.1 support -- in this dataset "support" can only mean a completed pass
%% link inside the same sequence (an OPEN passing lane cannot be verified,
%% see glossary 4.1).  Named honestly as pass_support/3 so it is never
%% mistaken for geometric support.
pass_support(P1, P2, S) :-
    passes_to(P1, P2, S).

%% sequence outcome shortcuts used by the ILP examples
negative_sequence(S) :- sequence_label(S, negative).
positive_sequence(S) :- sequence_label(S, non_negative).

%% player-level convenience
plays_role(P, R) :- has_role(P, R).

%% an action performed by a player in a given role
action_by_role(A, R) :-
    actor(A, P),
    has_role(P, R).
