%% ===================================================================
%%  AUTO-GENERATED - phase 5 Popper background knowledge wrapper
%%
%%  Loads the phase 3/4 facts and hand-written bk.pl, then defines one
%%  seq_<concept>/1 wrapper per action-level or player-level concept so
%%  Popper only ever reasons over Sequence, never over Action or Player
%%  variables directly (keeps the search space small).
%%
%%  PATHS ARE RELATIVE to this file, resolved at load time via
%%  prolog_load_context/2.  An earlier version baked in absolute paths from
%%  the machine that generated it, which broke the moment the project was
%%  unzipped anywhere else (Colab, Windows, a different user).
%% ===================================================================

%%  SWI-Prolog resolves a relative path in consult/1 against the directory
%%  of the file containing the directive, so these stay correct wherever the
%%  project is unpacked.
:- consult('../facts_all.pl').
:- consult('../facts_tactical.pl').
:- consult('../bk.pl').


seq_line_breaking_pass(S) :-
    in_sequence(A, S),
    line_breaking_pass(A).

seq_midfield_line_breaking_pass(S) :-
    in_sequence(A, S),
    midfield_line_breaking_pass(A).

seq_diagonal_pass(S) :-
    in_sequence(A, S),
    diagonal_pass(A).

seq_line_pass(S) :-
    in_sequence(A, S),
    line_pass(A).

seq_switch_of_play(S) :-
    in_sequence(A, S),
    switch_of_play(A).

seq_pass_in_behind(S) :-
    in_sequence(A, S),
    pass_in_behind(A).

seq_connecting_pass(S) :-
    in_sequence(A, S),
    connecting_pass(A).

seq_dropped_between_lines(S) :-
    in_sequence(A, S),
    dropped_between_lines(A).

seq_layoff(S) :-
    in_sequence(A, S),
    layoff(A).

seq_triangulation(S) :-
    in_sequence(A, S),
    triangulation(A).

seq_triangle_trap(S) :-
    in_sequence(A, S),
    triangle_trap(A).

seq_rondo_cage(S) :-
    in_sequence(A, S),
    rondo_cage(A).

seq_pressured_cage(S) :-
    in_sequence(A, S),
    pressured_cage(A).

seq_supported_action(S) :-
    in_sequence(A, S),
    supported_action(A).

seq_dead_end_support(S) :-
    in_sequence(A, S),
    dead_end_support(A).

seq_few_passing_options(S) :-
    in_sequence(A, S),
    few_passing_options(A).

seq_many_passing_options(S) :-
    in_sequence(A, S),
    many_passing_options(A).

seq_hesitated(S) :-
    in_sequence(A, S),
    hesitated(A).

seq_costly_hesitation(S) :-
    in_sequence(A, S),
    costly_hesitation(A).

seq_first_time_play(S) :-
    in_sequence(A, S),
    first_time_play(A).

seq_quick_line_break(S) :-
    in_sequence(A, S),
    quick_line_break(A).

seq_dwelt_long(S) :-
    in_sequence(A, S),
    dwelt_long(A).

seq_pressured_dwell(S) :-
    in_sequence(A, S),
    pressured_dwell(A).

seq_regains_possession(S) :-
    in_sequence(A, S),
    regains_possession(A).

seq_counter_pressed(S) :-
    in_sequence(A, S),
    counter_pressed(A).

seq_press_resistance(S) :-
    in_sequence(A, S),
    press_resistance(A).

seq_counter_attack_potential(S) :-
    in_sequence(A, S),
    counter_attack_potential(A).

seq_keeper_build_up_start(S) :-
    in_sequence(A, S),
    keeper_build_up_start(A).

seq_numeric_superiority(S) :-
    in_sequence(A, S),
    numeric_superiority(A).

seq_persistent_half_space_occupier(S) :-
    persistent_half_space_occupier(_, S).

seq_give_and_continue(S) :-
    give_and_continue(_, S).

not_slow_sequence(S) :-
    sequence(S),
    \+ slow_sequence(S).

not_seq_switch_of_play(S) :-
    sequence(S),
    \+ seq_switch_of_play(S).

not_seq_dwelt_long(S) :-
    sequence(S),
    \+ seq_dwelt_long(S).

not_seq_hesitated(S) :-
    sequence(S),
    \+ seq_hesitated(S).

not_seq_diagonal_pass(S) :-
    sequence(S),
    \+ seq_diagonal_pass(S).
