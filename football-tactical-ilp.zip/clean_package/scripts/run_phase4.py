"""
Phase 4 — build the tactical concept facts and validate bk.pl.

    uv run python scripts/run_phase4.py

Phase 3 must have run first (facts_all.pl has to exist).
"""

from __future__ import annotations

import subprocess
import sys
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
warnings.filterwarnings("ignore")

from tactical_ilp.config import PROLOG_DIR                                 # noqa: E402
from tactical_ilp.prolog.tactical_facts import (                           # noqa: E402
    PHASE4_FACTS_PATH,
    PHASE4_MANIFEST_PATH,
    generate_tactical_facts,
)

BK_PATH = PROLOG_DIR / "bk.pl"
FACTS_ALL = PROLOG_DIR / "facts_all.pl"

# every rule in bk.pl, with the glossary section it implements
RULES = [
    ("1.1", "line_breaking_pass(_)"),
    ("1.1b", "midfield_line_breaking_pass(_)"),
    ("1.2", "diagonal_pass(_)"),
    ("1.2b", "successful_diagonal_pass(_)"),
    ("1.3", "line_pass(_)"),
    ("1.4", "switch_of_play(_)"),
    ("1.5", "pass_in_behind(_)"),
    ("1.6", "connecting_pass(_)"),
    ("1.7", "cross_pass(_)"),
    ("2.3", "dropped_between_lines(_)"),
    ("3.1", "give_and_go(_,_,_)"),
    ("3.2", "third_man(_,_,_,_)"),
    ("3.3", "rapid_combination_sequence(_)"),
    ("3.4", "give_and_continue(_,_)"),
    ("3.5", "layoff(_)"),
    ("3.6a", "triangulation(_)"),
    ("3.6b", "triangle_trap(_)"),
    ("3.6b", "rondo_cage(_)"),
    ("3.6b", "pressured_cage(_)"),
    ("4.1", "supported_action(_)"),
    ("4.3", "dead_end_support(_)"),
    ("4.5", "few_passing_options(_)"),
    ("4.5", "many_passing_options(_)"),
    ("5.1", "persistent_half_space_occupier(_,_)"),
    ("6.1", "hesitated(_)"),
    ("6.1b", "costly_hesitation(_)"),
    ("6.1c", "hesitant_negative_sequence(_)"),
    ("6.2", "fast_sequence(_)"),
    ("6.2", "slow_sequence(_)"),
    ("6.2b", "tempo_break(_)"),
    ("6.3", "first_time_play(_)"),
    ("6.3b", "quick_line_break(_)"),
    ("6.4", "dwelt_long(_)"),
    ("6.4b", "released_instantly(_)"),
    ("6.5", "pressured_dwell(_)"),
    ("7.1/7.2", "regains_possession(_)"),
    ("8.3", "counter_pressed(_)"),
    ("8.4", "press_resistance(_)"),
    ("9.1", "counter_attack(_)"),
    ("9.1b", "counter_attack_potential(_)"),
    ("12.1", "keeper_build_up_start(_)"),
    ("4.1", "pass_support(_,_,_)"),
]

# rules that are correct but expected to be rare or single-hit in THIS
# dataset for a documented structural reason (see the comment above each rule
# in bk.pl) -- these do not fail validation even with very few solutions.
KNOWN_SPARSE = {
    "counter_attack(_)",  # build-up sequences almost never reach the final third
}

# rules that are correct but expected to have ZERO solutions in this dataset
# for a documented structural reason -- see the comment above the rule in
# bk.pl.  Kept in the file because they are correct and would fire if a
# future phase changes the sequence boundary.
KNOWN_EMPTY = {
    "cross_pass(_)",  # crosses never occur inside a build-up sequence
}


def banner(text: str) -> None:
    print()
    print("=" * 78)
    print(text)
    print("=" * 78)


def swipl_available() -> bool:
    try:
        return subprocess.run(["swipl", "--version"], capture_output=True).returncode == 0
    except FileNotFoundError:
        return False


def count_rule(goal: str) -> int | None:
    script = (
        f"consult('{FACTS_ALL}'), consult('{PHASE4_FACTS_PATH}'), "
        f"consult('{BK_PATH}'), aggregate_all(count, {goal}, N), write(N), nl, halt."
    )
    out = subprocess.run(["swipl", "-q", "-g", script], capture_output=True, text=True)
    if out.returncode != 0:
        return None
    try:
        return int(out.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return None


def main() -> int:
    if not FACTS_ALL.exists():
        print(f"missing {FACTS_ALL} -- run scripts/run_phase3.py first")
        return 1

    banner("TASK 4.1-4.5 — generate tactical concept facts")
    path, counts, ctx = generate_tactical_facts()
    total = sum(counts.values())
    print(f"{path.name}: {total} facts over {len(ctx)} sequences")
    for k, v in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"  {k:<26} {v:>7}")

    import json

    PHASE4_MANIFEST_PATH.write_text(
        json.dumps(
            {
                "file": path.name,
                "n_sequences": int(len(ctx)),
                "n_matches": int(ctx.match_id.nunique()),
                "predicate_counts": counts,
                "total_facts": int(total),
            },
            indent=2,
        ),
        encoding="utf-8",
    )

    banner("TASK 4.6 — validate bk.pl rules against the facts")
    if not swipl_available():
        print("SWI-Prolog not on PATH — skipping rule validation")
        print("(install swi-prolog to run this step)")
        return 0
    if not BK_PATH.exists():
        print(f"missing {BK_PATH}")
        return 1

    print(f"{'concept':<10} {'rule':<40} {'solutions':>9}")
    print("-" * 60)
    empty = []
    for section, goal in RULES:
        n = count_rule(goal)
        flag = ""
        if n is None:
            flag = "  ERROR"
        elif n == 0:
            if goal in KNOWN_EMPTY:
                flag = "  (expected empty here, see bk.pl)"
            else:
                flag = "  <-- EMPTY"
                empty.append(goal)
        elif n < 5 and goal in KNOWN_SPARSE:
            flag = "  (expected sparse, see bk.pl)"
        print(f"{section:<10} {goal:<40} {str(n):>9}{flag}")

    banner("PHASE 4 DONE")
    if empty:
        print(f"WARNING: {len(empty)} rule(s) returned no solutions: {empty}")
        print("A rule that never fires is either wrong or useless to Popper.")
        return 1
    print("all rules produce solutions")
    print("next: scripts/run_phase5.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
