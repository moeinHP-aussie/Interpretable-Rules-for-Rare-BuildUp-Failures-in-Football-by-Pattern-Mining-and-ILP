"""
Phase 5 — generate Popper's input files and, if Popper is available, run it.

    uv run python scripts/run_phase5.py

Requires phase 4 to have run (facts_tactical.pl and bk.pl must exist).

Popper itself needs a separate Python (>=3.14) environment with janus_swi,
which needs SWI-Prolog >= 9.1.12.  On Colab this is built from source (see
the notebook).  If POPPER_DIR is not set or Popper's dependencies are not
importable, this script still generates exs.pl/bias.pl/bk.pl and prints
instructions instead of failing.
"""

from __future__ import annotations

import os
import subprocess
import sys
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
warnings.filterwarnings("ignore")

from tactical_ilp.config import PROLOG_DIR                       # noqa: E402
from tactical_ilp.prolog.popper_inputs import generate_popper_inputs  # noqa: E402

FACTS_TACTICAL = PROLOG_DIR / "facts_tactical.pl"
HAND_BK = PROLOG_DIR / "bk.pl"


def banner(text: str) -> None:
    print()
    print("=" * 78)
    print(text)
    print("=" * 78)


def swipl_available() -> bool:
    try:
        return subprocess.run(["swipl", "--version"], capture_output=True).returncode == 0
    except FileNotFoundError:
        return False


def swipl_version_ok() -> bool:
    """Popper's janus_swi needs SWI-Prolog >= 9.1.12."""
    try:
        out = subprocess.run(["swipl", "--version"], capture_output=True, text=True)
    except FileNotFoundError:
        return False
    import re

    m = re.search(r"(\d+)\.(\d+)\.(\d+)", out.stdout)
    if not m:
        return False
    major, minor, patch = map(int, m.groups())
    return (major, minor, patch) >= (9, 1, 12)


def validate_generated_files(paths: dict) -> bool:
    """Sanity-check the generated files parse and the wrappers fire, without
    needing Popper itself -- pure SWI-Prolog is enough for this."""
    if not swipl_available():
        print("SWI-Prolog not on PATH -- cannot even syntax-check the output")
        return False

    script = (
        f"consult('{paths['exs']}'), "
        f"aggregate_all(count, pos(_), NP), aggregate_all(count, neg(_), NN), "
        f"consult('{paths['bk']}'), "
        "write(ok(NP,NN)), nl, halt."
    )
    out = subprocess.run(["swipl", "-q", "-g", script], capture_output=True, text=True)
    if out.returncode != 0:
        print("VALIDATION FAILED:")
        print(out.stderr)
        return False
    print(f"exs.pl + bk.pl load cleanly: {out.stdout.strip()}")
    return True


def try_run_popper(popper_dir: Path, task_dir: Path) -> int | None:
    """Best-effort: run Popper if its environment is actually usable here."""
    popper_py = popper_dir / "popper.py"
    if not popper_py.exists():
        print(f"no popper.py at {popper_py} -- skipping actual run")
        return None
    try:
        import janus_swi  # noqa: F401
    except ImportError:
        print("janus_swi not importable in this Python -- skipping actual run")
        print("(needs SWI-Prolog >= 9.1.12; see docs/phase5_review_findings.md)")
        return None

    proc = subprocess.run(
        [sys.executable, str(popper_py), str(task_dir), "--noisy", "--timeout", "240"],
        capture_output=True,
        text=True,
        timeout=1800,
    )
    print(proc.stdout[-4000:])
    if proc.returncode != 0:
        print(proc.stderr[-2000:])
    return proc.returncode


def main() -> int:
    if not FACTS_TACTICAL.exists() or not HAND_BK.exists():
        print("missing phase 4 output -- run scripts/run_phase4.py first")
        return 1

    banner("TASK 5.1 — generate Popper input files (exs.pl, bias.pl, bk.pl)")
    info = generate_popper_inputs()
    print(f"output dir : {info['dir']}")
    print(f"exs.pl     : {info['n_pos']} pos, {info['n_neg']} neg")
    print(f"bias.pl    : {info['n_body_preds']} body predicates, max_body=4, max_vars=6")

    banner("TASK 5.2 — validate the generated files")
    ok = validate_generated_files(info)
    if not ok:
        return 1

    banner("TASK 5.3 — run Popper (best effort)")
    popper_dir = os.environ.get("POPPER_DIR")
    if not popper_dir:
        print("POPPER_DIR not set.")
        print("This environment could not install janus_swi (needs SWI-Prolog")
        print(">= 9.1.12; apt only provides 9.0.4). This is expected and is")
        print("documented in docs/phase5_review_findings.md.")
        print()
        print("On a machine with Popper installed, run (--noisy matters -- see")
        print("docs/phase5_review_findings.md section 5 for why):")
        print(f"  POPPER_DIR=/path/to/Popper python /path/to/Popper/popper.py {info['dir']} --noisy --timeout 240")
        print()
        print("Then score the learned rule on the held-out matches it never saw:")
        print('  uv run python scripts/run_phase5_eval.py --rule "<comma-separated body predicates>"')
        return 0

    rc = try_run_popper(Path(popper_dir), info["dir"])
    banner("PHASE 5 DONE")
    if rc is None:
        print("input files generated and validated; Popper itself not run here")
        return 0
    print()
    print("Now score the learned rule on the held-out matches (exs_holdout.pl):")
    print('  uv run python scripts/run_phase5_eval.py --rule "<comma-separated body predicates from the printed rule>"')
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
